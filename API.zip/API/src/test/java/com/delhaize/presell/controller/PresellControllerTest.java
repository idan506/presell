package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.*;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.PresellDTO;
import com.delhaize.presell.dto.PresellDetailDTO;
import com.delhaize.presell.dto.PresellStoreDetailDTO;
import com.delhaize.presell.dto.StoreDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import com.delhaize.presell.service.PresellService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;

public class PresellControllerTest {
	@InjectMocks
	PresellController presellController;

	@Mock
	PresellService presellService;

	private UserSSOInfo user;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
		user = new UserSSOInfo();
		user.setUserId("userId");
		user.setRole(Secured.UserRole.ADMIN);
		user.setStoreNbr(1234);
	}
	
	@Test
	void appVersion() {
		var rs = presellController.appVersion();
		assertNotNull(rs);
	}

	@Test
	void searchPresell() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		PresellSearchCriteria criteria = new PresellSearchCriteria();
		Page<PresellDTO> pagePresell = null;
		when(presellService.searchPresell(criteria, paginationAndSortDTO)).thenReturn(pagePresell);
		
		var rs = presellController.searchPresell(criteria, paginationAndSortDTO);
		assertNotNull(rs);
	}
	
	/*@Test
	void downloadPresellToXLS() {
		String fileName = String.format("Presell_List_%o.xls", System.currentTimeMillis());
		PresellSearchCriteria criteria = new PresellSearchCriteria();
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test data".getBytes());
		when(presellService.downloadPresellToXLS(criteria, fileName)).thenReturn(anyByteArr);
		var rs = presellController.downloadPresellToXLS(criteria);
		assertNotNull(rs);
	}*/
	
	@Test
	void deletePreselListSuccess() {
		List<Integer> request = new ArrayList<>();
		request.add(1);
		request.add(2);
		request.add(3);

		when(presellService.deletePresellList(request)).thenReturn("success");

		var rs = presellController.deletePreselList(request);

		assertEquals("success", rs.getBody());
	}

	@Test
	void deletePreselListError() {
		when(presellService.deletePresellList(null)).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> presellController.deletePreselList(null));
	}

	@Test
	void sendToAdditionalStoresSuccess() {
		PresellSaveRequestDTO request = buildRequestDTO(SavePresellAction.SEND_TO_STORES,
				Status.SEND_TO_STORES);
		int i = 1;
		when(presellService.sendToAdditionalStores(request)).thenReturn(i);
		var rs = presellController.savePresell(request, user);
		assertNotNull(rs);
	}

//	@Test
//	void sendToAdditionalStoresError() {
//		PresellSaveRequestDTO request = buildRequestDTO(SavePresellAction.SEND_TO_STORES, Status.SEND_TO_STORES.getKey());
//		when(presellService.sendToAdditionalStores(null)).thenThrow(EntityNotFoundException.class);
//		assertThrows(Exception.class, () -> presellController.savePresell(null));
//	}

	@Test
	void savePresellSuccess() {
		PresellSaveRequestDTO request = buildRequestDTO(SavePresellAction.CREATE_AUTO_ORDER,
				Status.SEND_TO_STORES);
		when(presellService.sendToAdditionalStores(request)).thenReturn(1);
		var rs = presellController.savePresell(request, user);
		assertNotNull(rs);
	}

	@Test
	void getPresellDetailsSuccess(){
		int psellIdNbr = 1;
		PresellStoreDetailDTO request = new PresellStoreDetailDTO(1, 1, "A","A", "A", DatetimeUtils.getCurrentSQLDate(),
				"A", DatetimeUtils.getCurrentSQLDate(), "A", "A", "A", "A", DatetimeUtils.getUTCTimestamp(), "A",
				DatetimeUtils.getUTCTimestamp(), "A", 1, 122, "A", null, null, 1, 1, null, null);
		when(presellService.getPresellDetails(psellIdNbr)).thenReturn(request);
		var rs = presellController.getPresellDetails(psellIdNbr);
		assertNotNull(rs);
	}

	@Test
	void getPresellDetailsError() {
		when(presellService.getPresellDetails(null)).thenThrow(EntityNotFoundException.class);
		assertThrows(Exception.class, () -> presellController.getPresellDetails(null));
	}

	@Test
	void downloadItemList() {
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test data".getBytes());
		when(presellService.downloadItemList(anyInt(), anyString())).thenReturn(anyByteArr);
		
		var rs = presellController.downloadItemList(1);
		assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}
	
	private PresellSaveRequestDTO buildRequestDTO(SavePresellAction action, Status status) {
		PresellSaveRequestDTO request = new PresellSaveRequestDTO();
		PresellDetailDTO presell = new PresellDetailDTO();
		List<StoreDTO> store = new ArrayList<>();
		store.add(new StoreDTO(1, "A", "A", 1, "A", "A", DatetimeUtils.getCurrentSQLDate(), DBAction.UPDATE,
				DBStatus.OLD));
		presell.setPsellIdNbr(1);
		presell.setPsellDsc("A");
		presell.setBusUnitId("A");
		presell.setPsellLvlIdNbr(1);
		presell.setAddUserId("rparo");
		presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
		presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
		presell.setPlnDistFlg("Y");
		presell.setPsellStatCd(status);
		presell.setPsellCmtTxt("A");
		presell.setStoreDTOList(store);
		presell.setItemDTOList(null);
		presell.setItemNotFoundList(null);
		presell.setLogs(null);
		presell.setItemCount(0);
		presell.setStoreCount(0);
		presell.setItemList(null);
		presell.setHmStoresForAdd(null);

		request.setUserId("rparo");
		request.setAction(action);
		request.setPresellDetail(presell);

		return request;
	}
}
