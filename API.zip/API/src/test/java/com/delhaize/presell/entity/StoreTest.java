package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class StoreTest {

   @InjectMocks
   Store store;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       store.setStoreSidNbr(1);
       assertNotNull(store.getStoreSidNbr());
       store.setStoreNbr(1);
       assertNotNull(store.getStoreNbr());
       store.setStoreNam("TEST");
       assertNotNull(store.getStoreNam());
       store.setStoreShrtNam("TEST");
       assertNotNull(store.getStoreShrtNam());
       store.setAfflCd("TEST");
       assertNotNull(store.getAfflCd());
       store.setScanEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getScanEffDt());
       store.setScanGrpNbr(1);
       assertNotNull(store.getScanGrpNbr());
       store.setTaxNbr(new java.math.BigDecimal(1));
       assertNotNull(store.getTaxNbr());
       store.setStatCd("TEST");
       assertNotNull(store.getStatCd());
       store.setFmtCd("TEST");
       assertNotNull(store.getFmtCd());
       store.setChksdLblCnt(1);
       assertNotNull(store.getChksdLblCnt());
       store.setSrpEffDowNbr(1);
       assertNotNull(store.getSrpEffDowNbr());
       store.setDeaId("TEST");
       assertNotNull(store.getDeaId());
       store.setDeaXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getDeaXpirDt());
       store.setArLocId("TEST");
       assertNotNull(store.getArLocId());
       store.setPromoCd("TEST");
       assertNotNull(store.getPromoCd());
       store.setBakeClsCd("TEST");
       assertNotNull(store.getBakeClsCd());
       store.setRcvSysCd("TEST");
       assertNotNull(store.getRcvSysCd());
       store.setLqrAgcyNbr(1);
       assertNotNull(store.getLqrAgcyNbr());
       store.setRpmGoalNbr(1);
       assertNotNull(store.getRpmGoalNbr());
       store.setSetupDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getSetupDt());
       store.setGlOpenDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getGlOpenDt());
       store.setPhysClseDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getPhysClseDt());
       store.setFinClseDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getFinClseDt());
       store.setSysXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getSysXpirDt());
       store.setTotLaneNbr(1);
       assertNotNull(store.getTotLaneNbr());
       store.setTotTrmnlNbr(1);
       assertNotNull(store.getTotTrmnlNbr());
       store.setStoreLastCmprDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getStoreLastCmprDt());
       store.setInvSysCd("TEST");
       assertNotNull(store.getInvSysCd());
       store.setInvSysDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getInvSysDt());
       store.setTotSqftNbr(1);
       assertNotNull(store.getTotSqftNbr());
       store.setSellSqftNbr(1);
       assertNotNull(store.getSellSqftNbr());
       store.setTagProcCd("TEST");
       assertNotNull(store.getTagProcCd());
       store.setPharOpenDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getPharOpenDt());
       store.setPharClseDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getPharClseDt());
       store.setPharRmtnStrtDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getPharRmtnStrtDt());
       store.setPharStLicId("TEST");
       assertNotNull(store.getPharStLicId());
       store.setMigrDataSrcCd("TEST");
       assertNotNull(store.getMigrDataSrcCd());
       store.setModUserId("TEST");
       assertNotNull(store.getModUserId());
       store.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(store.getModTs());
       store.setModPgmId("TEST");
       assertNotNull(store.getModPgmId());
       store.setStoreRcvGrpCd("TEST");
       assertNotNull(store.getStoreRcvGrpCd());
       store.setCodEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getCodEffDt());
       store.setPhysOpenDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(store.getPhysOpenDt());
       store.setCnsmrStoreNam("TEST");
       assertNotNull(store.getCnsmrStoreNam());
       store.setCnsmrStoreUrl("TEST");
       assertNotNull(store.getCnsmrStoreUrl());
       store.setTaxCntyId("TEST");
       assertNotNull(store.getTaxCntyId());
       store.setPrcBnnrId("TEST");
       assertNotNull(store.getPrcBnnrId());
       store.setTagDlvCd("TEST");
       assertNotNull(store.getTagDlvCd());
       store.setDcSidNbr(1);
       assertNotNull(store.getDcSidNbr());
       store.setWineLicId("TEST");
       assertNotNull(store.getWineLicId());
       store.setBnnrId(1);
       assertNotNull(store.getBnnrId());
       store.setCorpId(1);
       assertNotNull(store.getCorpId());

       assertNotEquals(store, new Store());
       System.out.println(store.hashCode());
       System.out.println(store.toString());
   }
}
