package com.delhaize.presell.service;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.PresellItem;
import com.delhaize.presell.dto.projection.PresellLogProjection;
import com.delhaize.presell.dto.projection.StoreResultsPresellprojection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;
import com.delhaize.presell.entity.*;
import com.delhaize.presell.repository.*;
import com.delhaize.presell.repository.dao.StoreOrderDAO;
import com.delhaize.presell.service.impl.ItemServiceImpl;
import com.delhaize.presell.service.impl.StoreOrderServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.math.BigDecimal;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

public class StoreOrderServiceImplTest {

	@InjectMocks
	StoreOrderServiceImpl storeOrderServiceImpl;
	@Mock
	StoreOrderDAO storeOrderDAO;
	@Mock
	PresellRepository presellRepository;
	@Mock
	PresellStoreRepository presellStoreRepository;
	@Mock
	ItemServiceImpl itemServiceImpl;
	@Mock
	LvlClassRepository lvlClassRepository;
	@Mock
	StorItemsRepository storItemsRepository;
	@Mock
	BuMstrRepository buMstrRepository;
	@Mock
	ItemsRepository itemsRepository;
	@Mock
	LvlMapngRepository lvlMapngRepository;
	@Mock
	PreselLogRepository preselLogRepository;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void searchStoreOrder() {
		StoreOrderCriteria criteria = new StoreOrderCriteria();
		criteria.setStoreNo("1212");
		criteria.setPlannedDis("Testing");
		criteria.setPresellTitle("testing");
		criteria.setPresellLevelId(111);
		criteria.setUserRole("ADMIN");
		// criteria.setStatus();
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		Page<StoreOrderDTO> data = null;
		Mockito.when(storeOrderDAO.searchStoreOrderWithRoleRT(criteria, pageable)).thenReturn(data);
		var rs = storeOrderServiceImpl.searchStoreOrder(criteria, paginationAndSortDTO);
		assertTrue(true);
	}
	
	@Test
	public void searchStoreOrderWithRoleRT() {
		StoreOrderCriteria criteria = new StoreOrderCriteria();
		criteria.setStoreNo("1212");
		criteria.setPlannedDis("Testing");
		criteria.setPresellTitle("testing");
		criteria.setPresellLevelId(111);
		criteria.setUserRole("RETAIL");
		// criteria.setStatus();
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		Page<StoreOrderDTO> data = null;
		Mockito.when(storeOrderDAO.searchStoreOrderWithRoleRT(criteria, pageable)).thenReturn(data);
		var rs = storeOrderServiceImpl.searchStoreOrder(criteria, paginationAndSortDTO);
		assertTrue(true);
	}

	@Test
	public void getStoreOrderDetails() {
		Integer presellID = 1223;
		String date = "12/02/2021";
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

		PresellItem presellData = new PresellItem() {
			@Override
			public Integer getPsellIdNbr() {
				return 1232;
			}

			@Override
			public Integer getpsellLvlIdNbr() {
				return 2323;
			}

			@Override
			public String getBusUnitId() {
				return "HAS";
			}

			@Override
			public String getPsellDsc() {
				return "testing";
			}

			@Override
			public Date getPsellDueDt() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPlnDistFlg() {
				return "Y";
			}

			@Override
			public Date getRmndrEmailDt() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPsellCmtTxt() {
				return "testing";
			}

			@Override
			public String getPsellStatCd() {
				return "Testing";
			}

			@Override
			public String getAddUserId() {
				return "Testuser";
			}

			@Override
			public Timestamp getAddTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getModUserId() {
				return "Testuser";
			}

			@Override
			public Timestamp getModTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPsellLvlDsc() {
				return "testing";
			}
		};
		List<StoreResultsPresellprojection> storeData = new ArrayList<>();
		storeData.add(new StoreResultsPresellprojection() {
			@Override
			public String getDstrcDsc() {
				return "testing";
			}

			@Override
			public String getStoreNam() {
				return "storename";
			}

			@Override
			public Integer getStoreNbr() {
				return 12323;
			}

			@Override
			public String getStoreStatCd() {
				return "sts";
			}
		});
		String busUnit = "busUnit";
		Secured.UserRole role=Secured.UserRole.ADMIN;
		Integer storenbr=2778;
		Mockito.when(presellRepository.getPresell(presellID)).thenReturn(presellData);
		Mockito.when(presellStoreRepository.getStoreData(presellID)).thenReturn(storeData);
		when(buMstrRepository.getbusUnitDsc("")).thenReturn(busUnit);
		// PresellStoreDetailDTO presellDetails = new PresellStoreDetailDTO();
		Mockito.when(presellRepository.getCurrentDate()).thenReturn(new Timestamp(0));
		var rs = storeOrderServiceImpl.getStoreOrderDetails(presellID,role,storenbr);
		assertNotNull(rs);
	}
	@Test
	public void getStoreOrderDetailsForRetail(){
		Integer presellID = 1223;
		String date = "12/02/2021";
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

		PresellItem presellData = new PresellItem() {
			@Override
			public Integer getPsellIdNbr() {
				return 1232;
			}

			@Override
			public Integer getpsellLvlIdNbr() {
				return 2323;
			}

			@Override
			public String getBusUnitId() {
				return "HAS";
			}

			@Override
			public String getPsellDsc() {
				return "testing";
			}

			@Override
			public Date getPsellDueDt() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPlnDistFlg() {
				return "Y";
			}

			@Override
			public Date getRmndrEmailDt() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPsellCmtTxt() {
				return "testing";
			}

			@Override
			public String getPsellStatCd() {
				return "Testing";
			}

			@Override
			public String getAddUserId() {
				return "Testuser";
			}

			@Override
			public Timestamp getAddTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getModUserId() {
				return "Testuser";
			}

			@Override
			public Timestamp getModTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPsellLvlDsc() {
				return "testing";
			}
		};
		List<StoreResultsPresellprojection> storeData = new ArrayList<>();
		storeData.add(new StoreResultsPresellprojection() {
			@Override
			public String getDstrcDsc() {
				return "testing";
			}

			@Override
			public String getStoreNam() {
				return "storename";
			}

			@Override
			public Integer getStoreNbr() {
				return 12323;
			}

			@Override
			public String getStoreStatCd() {
				return "STS";
			}
		});
		String busUnit = "busUnit";
		Secured.UserRole role=Secured.UserRole.RETAIL;
		Integer storenbr=2778;
		Integer psellIdNbr = 1232;
		Integer psellLevelID=3;
		int clasificationID=2;
		String lvlCd="f";
		Mockito.when(presellRepository.getPresell(presellID)).thenReturn(presellData);
		Mockito.when(presellStoreRepository.getStoreRetailData(presellID,storenbr)).thenReturn(storeData);
		when(buMstrRepository.getbusUnitDsc("")).thenReturn(busUnit);
		// PresellStoreDetailDTO presellDetails = new PresellStoreDetailDTO();
		Mockito.when(presellRepository.getCurrentDate()).thenReturn(new Timestamp(0));
		var rs = storeOrderServiceImpl.getStoreOrderDetails(presellID,role,storenbr);
		assertNotNull(rs);
	}
	@Test
	public void downloadStoreItemDetails() {
		Integer psellIdNbr = 1232;
		Integer storeNbr = 122;
		String fileName = String.format("Presell_Item_%o.xls", System.currentTimeMillis());
		PresellItem presell = new PresellItem() {
			@Override
			public Integer getPsellIdNbr() {
				return 1212;
			}

			@Override
			public Integer getpsellLvlIdNbr() {
				return 233;
			}

			@Override
			public String getBusUnitId() {
				return "HAS";
			}

			@Override
			public String getPsellDsc() {
				return "Testing";
			}

			@Override
			public Date getPsellDueDt() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPlnDistFlg() {
				return "Y";
			}

			@Override
			public Date getRmndrEmailDt() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPsellCmtTxt() {
				return "Testing";
			}

			@Override
			public String getPsellStatCd() {
				return "Testing";
			}

			@Override
			public String getAddUserId() {
				return "TestUser";
			}

			@Override
			public Timestamp getAddTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getModUserId() {
				return "Test_User";
			}

			@Override
			public Timestamp getModTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getPsellLvlDsc() {
				return "Testing";
			}
		};
		SuggOrderQtyDTO suggOrder = new SuggOrderQtyDTO();
		suggOrder.setSuggOrderQty("11");
		suggOrder.setPresellLevelCode("A");
		suggOrder.setPresellLevelID(1);
		List<SuggOrderQtyDTO> listSuggOrder = new ArrayList<>();
		listSuggOrder.add(suggOrder);
		List<ItemsDTO> list = new ArrayList<>();
		ItemsDTO items = new ItemsDTO();
		items.setItemNbr("1232");
		items.setItemCst("Testing");
		items.setItemDsc("Testing_dsc");
		items.setItemCapCst("Testing");
		items.setItemImgUrl("Testing url");
		items.setItemPkQty("Testingpkqty");
		items.setItemSzCd("Testingszdc");
		items.setShipDt(DatetimeUtils.getUTCTimestamp());
		items.setSuggOrderQtyList(listSuggOrder);
		list.add(items);
		List<ClassificationDTO> classification = new ArrayList<>();
		classification.add(new ClassificationDTO(1, "test"));
		StoreOrderItemDTO stoteOderItem = new StoreOrderItemDTO();
		stoteOderItem.setItemList(list);
		Mockito.when(presellRepository.getPresell(psellIdNbr)).thenReturn(presell);
		Mockito.when(itemServiceImpl.getItemOrderDetails(psellIdNbr, storeNbr)).thenReturn(stoteOderItem);
		Mockito.when(lvlClassRepository.getClassifications()).thenReturn(classification);
		var rs = storeOrderServiceImpl.downloadStoreItemDetails(psellIdNbr, storeNbr, fileName);
		assertNotNull(rs);
	}

	@Test
	public void saveEditStoreQuantity() {
		String strStatus = null;
		String strMapping = "StoreSubmit";
		PresellStoreDetailDTO presell = new PresellStoreDetailDTO();
		presell.setPsellStatCd("status");
		presell.setStoreNo(123);
		presell.setPsellDueDt(DatetimeUtils.getUTCTimestamp());
		presell.setPsellIdNbr(1222);
		presell.setStoreStatus("SUB");
		SuggOrderQtyDTO suggOrder = new SuggOrderQtyDTO();
		suggOrder.setSuggOrderQty("11");
		suggOrder.setPresellLevelCode("A");
		suggOrder.setPresellLevelID(1);
		List<SuggOrderQtyDTO> listSuggOrder = new ArrayList<>();
		listSuggOrder.add(suggOrder);
		List<ItemsDTO> list = new ArrayList<>();
		ItemsDTO items = new ItemsDTO();
		items.setItemNbr("1232");
		items.setItemCst("Testing");
		items.setItemOrderQty("5");
		items.setItemDsc("Testing_dsc");
		items.setItemCapCst("Testing");
		items.setItemImgUrl("Testing url");
		items.setItemPkQty("4.00");
		items.setItemSzCd("Testingszdc");
		items.setShipDt(DatetimeUtils.getUTCTimestamp());
		items.setSuggOrderQtyList(listSuggOrder);
		list.add(items);
		presell.setItemList(list);
		SaveEditStoreQtyDTO criteria = new SaveEditStoreQtyDTO();
		criteria.setPresellDetail(presell);
		criteria.setUserId("1323");
		criteria.setUserRole("PRESELL_ADMIN");
		criteria.setAction("StoreSubmit");
		var storItemPk = new StorItemsPK();
		storItemPk.setPsellIdNbr(criteria.getPresellDetail().getPsellIdNbr());
		storItemPk.setStoreNbr(Integer.valueOf(criteria.getPresellDetail().getStoreNo()));
		storItemPk.setItemNbr(new BigDecimal(items.getItemNbr()));
		var storItemEntity = new StorItems();
		storItemEntity.setStorItemsPk(storItemPk);
		storItemEntity.setItemOrderQty(new BigDecimal(items.getItemPkQty()));
		storItemEntity.setAddUserId(criteria.getUserId());
		storItemEntity.setModUserId(criteria.getUserId());
		storItemEntity.setModTs(DatetimeUtils.getUTCTimestamp());
		Optional<StorItems> StoreItemEn = Optional.of(storItemEntity);
		Mockito.when(storItemsRepository.findById(storItemPk)).thenReturn(StoreItemEn);
		Mockito.when(storItemsRepository.saveAndFlush(storItemEntity)).thenReturn(storItemEntity);

		var presellStorePk = new PresellStorePK();
		presellStorePk.setStoreNbr(Integer.valueOf(criteria.getPresellDetail().getStoreNo()));
		presellStorePk.setPsellIdNbr(criteria.getPresellDetail().getPsellIdNbr());
		// listData.add(dataOpt.get());
		var presellStore = new PresellStore();
		presellStore.setStorePk(presellStorePk);
		presellStore.setStoreStatCd(strStatus);
		presellStore.setAddUserId(criteria.getUserId());
		presellStore.setModUserId(criteria.getUserId());
		presellStore.setModTs(DatetimeUtils.getUTCTimestamp());
		Optional<PresellStore> presellStoreOpt = Optional.of(presellStore);
		Mockito.when(presellStoreRepository.findById(presellStorePk)).thenReturn(presellStoreOpt);
		var rs = storeOrderServiceImpl.saveEditStoreQuantity(criteria);
		assertNotNull(rs);
	}

	@Test
	public void saveEditStoreQuantityWithStoreSTS() {
		String strStatus = null;
		String strMapping = "StoreSubmit";
		PresellStoreDetailDTO presell = new PresellStoreDetailDTO();
		presell.setPsellStatCd("status");
		presell.setStoreNo(123);
		presell.setPsellDueDt(DatetimeUtils.getUTCTimestamp());
		presell.setPsellIdNbr(1222);
		presell.setStoreStatus("STS");
		SuggOrderQtyDTO suggOrder = new SuggOrderQtyDTO();
		suggOrder.setSuggOrderQty("11");
		suggOrder.setPresellLevelCode("A");
		suggOrder.setPresellLevelID(1);
		List<SuggOrderQtyDTO> listSuggOrder = new ArrayList<>();
		listSuggOrder.add(suggOrder);
		List<ItemsDTO> list = new ArrayList<>();
		ItemsDTO items = new ItemsDTO();
		items.setItemNbr("1232");
		items.setItemCst("Testing");
		items.setItemOrderQty("5");
		items.setItemDsc("Testing_dsc");
		items.setItemCapCst("Testing");
		items.setItemImgUrl("Testing url");
		items.setItemPkQty("4.00");
		items.setItemSzCd("Testingszdc");
		items.setShipDt(DatetimeUtils.getUTCTimestamp());
		items.setSuggOrderQtyList(listSuggOrder);
		list.add(items);
		presell.setItemList(list);
		SaveEditStoreQtyDTO criteria = new SaveEditStoreQtyDTO();
		criteria.setPresellDetail(presell);
		criteria.setUserId("1323");
		criteria.setUserRole("PRESELL_ADMIN");
		criteria.setAction("save");
		var storItemPk = new StorItemsPK();
		storItemPk.setPsellIdNbr(criteria.getPresellDetail().getPsellIdNbr());
		storItemPk.setStoreNbr(Integer.valueOf(criteria.getPresellDetail().getStoreNo()));
		storItemPk.setItemNbr(new BigDecimal(items.getItemNbr()));
		// var storItemEntity =new StorItems();
		StorItems storItemEntity = null;
		Optional<StorItems> StoreItemEn = null;
		Mockito.when(storItemsRepository.findById(storItemPk)).thenReturn(StoreItemEn);
		// var storItemEntity =new StorItems();
		/*
		 * storItemEntity.setStorItemsPk(storItemPk); storItemEntity.setItemOrderQty(new
		 * BigDecimal(items.getItemPkQty()));
		 * storItemEntity.setAddUserId(criteria.getUserId());
		 * storItemEntity.setModUserId(criteria.getUserId());
		 * storItemEntity.setModTs(DatetimeUtils.getUTCTimestamp());
		 */
		Mockito.when(storItemsRepository.saveAndFlush(storItemEntity)).thenReturn(storItemEntity);

		var presellStorePk = new PresellStorePK();
		presellStorePk.setStoreNbr(Integer.valueOf(criteria.getPresellDetail().getStoreNo()));
		presellStorePk.setPsellIdNbr(criteria.getPresellDetail().getPsellIdNbr());
		// listData.add(dataOpt.get());
		var presellStore = new PresellStore();
		presellStore.setStorePk(presellStorePk);
		presellStore.setStoreStatCd(strStatus);
		presellStore.setAddUserId(criteria.getUserId());
		presellStore.setModUserId(criteria.getUserId());
		presellStore.setModTs(DatetimeUtils.getUTCTimestamp());
		Optional<PresellStore> presellStoreOpt = Optional.of(presellStore);
		Mockito.when(presellStoreRepository.findById(presellStorePk)).thenReturn(presellStoreOpt);
		var rs = storeOrderServiceImpl.saveEditStoreQuantity(criteria);
		assertNotNull(rs);
	}
}
