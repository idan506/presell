package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PresellStoreTest {

   @InjectMocks
   PresellStore presellStore;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       presellStore.setStorePk(new PresellStorePK());
       assertNotNull(presellStore.getStorePk());
       presellStore.setStoreStatCd("TEST");
       assertNotNull(presellStore.getStoreStatCd());
       presellStore.setAddUserId("TEST");
       assertNotNull(presellStore.getAddUserId());
       presellStore.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(presellStore.getAddTs());
       presellStore.setModUserId("TEST");
       assertNotNull(presellStore.getModUserId());
       presellStore.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(presellStore.getModTs());

       assertNotEquals(presellStore, new Store());
       System.out.println(presellStore.hashCode());
       System.out.println(presellStore.toString());
   }
}
