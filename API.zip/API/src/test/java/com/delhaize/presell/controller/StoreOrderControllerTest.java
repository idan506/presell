package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.dto.ItemsDTO;
import com.delhaize.presell.dto.PresellStoreDetailDTO;
import com.delhaize.presell.dto.SaveEditStoreQtyDTO;
import com.delhaize.presell.dto.StoreOrderDTO;
import com.delhaize.presell.dto.SuggOrderQtyDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;
import com.delhaize.presell.service.StoreOrderService;
import com.delhaize.presell.util.DatetimeUtils;

public class StoreOrderControllerTest {
	@InjectMocks
	StoreOrderController storeOrderController;

	@Mock
	StoreOrderService storeOrderService;

	private UserSSOInfo user;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
		user = new UserSSOInfo();
		user.setUserId("userId");
		user.setRole(Secured.UserRole.ADMIN);
		user.setStoreNbr(1234);
	}

	@Test
	void searchStoreOrder() {
		StoreOrderCriteria criteria = new StoreOrderCriteria();
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		Page<StoreOrderDTO> pageReport = null;
		when(storeOrderService.searchStoreOrder(criteria, paginationAndSortDTO)).thenReturn(pageReport);
		var rs = storeOrderController.searchStoreOrder(criteria, paginationAndSortDTO, user);
		assertNotNull(rs);
	}

	@Test
	void getStoreOrderDetailsSuccess() {
		PresellStoreDetailDTO dto = new PresellStoreDetailDTO(1, 1, "A", "A","A", DatetimeUtils.getCurrentSQLDate(), "A",
				DatetimeUtils.getCurrentSQLDate(), "A", "A", "A", "A", DatetimeUtils.getUTCTimestamp(), "A",
				DatetimeUtils.getUTCTimestamp(), "A", 1, 2332, "A", null, null, 0, 0, null, null);
		Secured.UserRole role= user.getRole();
		Integer storeNbr=2990;
		when(storeOrderService.getStoreOrderDetails(1,role,storeNbr)).thenReturn(dto);
		var rs = storeOrderController.getStoreOrderDetails(1,user);
		assertNotNull(rs);
	}

	@Test
	void getStoreOrderDetailsError() {
		Secured.UserRole role= user.getRole();
		Integer store=2990;
		when(storeOrderService.getStoreOrderDetails(any(),any(),any())).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> storeOrderController.getStoreOrderDetails(null,user));
	}

	@Test
	void downloadStoreItemDetailsSuccess() {
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test".getBytes());
		when(storeOrderService.downloadStoreItemDetails(anyInt(), anyInt(), anyString())).thenReturn(anyByteArr);
		var rs = storeOrderController.downloadStoreItemDetails(1, 1);
		assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}

	@Test
	void downloadStoreItemDetailsError() {
		when(storeOrderService.downloadStoreItemDetails(anyInt(), anyInt(), anyString()))
				.thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> storeOrderController.downloadStoreItemDetails(null, null));

	}

	@Test
	void saveEditStoreQuantitySuccess() {
		PresellStoreDetailDTO presell = new PresellStoreDetailDTO();
		presell.setPsellStatCd("status");
		presell.setStoreNo(1232);
		presell.setPsellDueDt(DatetimeUtils.getUTCTimestamp());
		presell.setPsellIdNbr(1222);
		presell.setStoreStatus("SUB");
		SuggOrderQtyDTO suggOrder = new SuggOrderQtyDTO();
		suggOrder.setSuggOrderQty("11");
		suggOrder.setPresellLevelCode("A");
		suggOrder.setPresellLevelID(1);
		List<SuggOrderQtyDTO> listSuggOrder = new ArrayList<>();
		listSuggOrder.add(suggOrder);
		List<ItemsDTO> list = new ArrayList<>();
		ItemsDTO items = new ItemsDTO();
		items.setItemNbr("1232");
		items.setItemCst("Testing");
		items.setItemDsc("Testing_dsc");
		items.setItemCapCst("Testing");
		items.setItemImgUrl("Testing url");
		items.setItemPkQty("4.00");
		items.setItemSzCd("Testingszdc");
		items.setShipDt(DatetimeUtils.getUTCTimestamp());
		items.setSuggOrderQtyList(listSuggOrder);
		list.add(items);
		presell.setItemList(list);
		SaveEditStoreQtyDTO criteria = new SaveEditStoreQtyDTO();
		criteria.setPresellDetail(presell);
		criteria.setUserId("1323");
		criteria.setUserRole("PRESELL_ADMIN");
		when(storeOrderService.saveEditStoreQuantity(criteria)).thenReturn(1);
		var rs = storeOrderController.saveEditStoreQuantity(criteria, user);
		assertNotNull(rs);
	}

	@Test
	void saveEditStoreQuantityError() {
		when(storeOrderService.saveEditStoreQuantity(null)).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> storeOrderController.saveEditStoreQuantity(null, user));
	}
}
