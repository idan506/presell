package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PuLocXrfPKTest {

   @InjectMocks
   PuLocXrfPK puLocXrfPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       puLocXrfPk.setItemSetNbr(1);
       assertNotNull(puLocXrfPk.getItemSetNbr());
       puLocXrfPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(puLocXrfPk.getItemNbr());
       puLocXrfPk.setVendSetNbr(1);
       assertNotNull(puLocXrfPk.getVendSetNbr());
       puLocXrfPk.setVendId("TEST");
       assertNotNull(puLocXrfPk.getVendId());
       puLocXrfPk.setLocSidNbr(1);
       assertNotNull(puLocXrfPk.getLocSidNbr());
   }
}
