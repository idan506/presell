package com.delhaize.presell.dto;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.util.DatetimeUtils;

public class StoresDTOTest {
	@InjectMocks
	StoresDTO storesDTO;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void noArgsConstructor() {
		StoresDTO storesDTO = new StoresDTO();
		storesDTO.setStoreNbr(1);
		assertNotNull(storesDTO.getStoreNbr());
		storesDTO.setStoreNam("AAA");
		assertNotNull(storesDTO.getStoreNam());
		storesDTO.setGeoRegnCd("AAA");
		assertNotNull(storesDTO.getGeoRegnCd());
		storesDTO.setLocSidNbr(1);
		assertNotNull(storesDTO.getLocSidNbr());
		storesDTO.setDivDsc("AAA");
		assertNotNull(storesDTO.getDivDsc());
		storesDTO.setDstrcDsc("AAA");
		assertNotNull(storesDTO.getDstrcDsc());
		storesDTO.setSchdArrvDt(DatetimeUtils.getCurrentSQLDate());
		assertNotNull(storesDTO.getSchdArrvDt());
	}

}
