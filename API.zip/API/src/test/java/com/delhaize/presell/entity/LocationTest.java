package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LocationTest {

   @InjectMocks
   Location location;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       location.setLocSidNbr(1);
       assertNotNull(location.getLocSidNbr());
       location.setBusUnitId("TEST");
       assertNotNull(location.getBusUnitId());
       location.setLocOrgSidNbr(1);
       assertNotNull(location.getLocOrgSidNbr());
       location.setGeoRegnCd("TEST");
       assertNotNull(location.getGeoRegnCd());
       location.setLocTypId("TEST");
       assertNotNull(location.getLocTypId());
       location.setCoLocId("TEST");
       assertNotNull(location.getCoLocId());
       location.setGlnNbr(new java.math.BigDecimal(1));
       assertNotNull(location.getGlnNbr());
       location.setModUserId("TEST");
       assertNotNull(location.getModUserId());
       location.setModPgmId("TEST");
       assertNotNull(location.getModPgmId());
       location.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(location.getModTs());

       assertNotEquals(location, new Location());
       System.out.println(location.hashCode());
       System.out.println(location.toString());
   }
}
