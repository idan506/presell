package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BuMstrTest {

   @InjectMocks
   BuMstr buMstr;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       buMstr.setBusUnitId("TEST");
       assertNotNull(buMstr.getBusUnitId());
       buMstr.setBusUnitDsc("TEST");
       assertNotNull(buMstr.getBusUnitDsc());
       buMstr.setParntBusUnitId("TEST");
       assertNotNull(buMstr.getParntBusUnitId());
       buMstr.setParntBusUnitFlg("TEST");
       assertNotNull(buMstr.getParntBusUnitFlg());
       buMstr.setAddUserId("TEST");
       assertNotNull(buMstr.getAddUserId());
       buMstr.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(buMstr.getAddTs());
       buMstr.setModUserId("TEST");
       assertNotNull(buMstr.getModUserId());
       buMstr.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(buMstr.getModTs());
       buMstr.setBusUnitNbr(1);
       assertNotNull(buMstr.getBusUnitNbr());

       assertNotEquals(buMstr, new BuMstr());
       System.out.println(buMstr.hashCode());
       System.out.println(buMstr.toString());
   }
}
