package com.delhaize.presell.service;

import com.delhaize.presell.dto.ClassificationDTO;
import com.delhaize.presell.dto.request.PresellClassificationRequestDTO;
import com.delhaize.presell.entity.LvlClass;
import com.delhaize.presell.repository.LvlClassRepository;
import com.delhaize.presell.service.impl.PresellClassificationServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

public class PresellClassificationServiceImplTest {
    @InjectMocks
    PresellClassificationServiceImpl presellClassificationServiceImpl;

    @Mock
    LvlClassRepository lvlClassRepository;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getClassification() {
        List<ClassificationDTO> data = new ArrayList<>();
        when(lvlClassRepository.getClassifications()).thenReturn(data);
        var actualResult = presellClassificationServiceImpl.getClassification();
        assertNotNull(actualResult);
    }

    @Test
    public void deleteClassification() {
        PresellClassificationRequestDTO request = new PresellClassificationRequestDTO();
        List<ClassificationDTO> classifications = new ArrayList<ClassificationDTO>();
        classifications.add(new ClassificationDTO(13, "AB", DatetimeUtils.getUTCTimestamp()));
        request.setClassifications(classifications);
        request.setUserId("rparo");

        Timestamp maxModDB = new Timestamp(DatetimeUtils.getUTCTimestamp().getTime() - 60*60*1000);
        when(lvlClassRepository.getMaxModTs()).thenReturn(maxModDB);

        LvlClass result = new LvlClass(13, "AB", "N", "rparo", DatetimeUtils.getUTCTimestamp(), "rparo",
                DatetimeUtils.getUTCTimestamp());
        Optional<LvlClass> data = Optional.of(result);
        when(lvlClassRepository.findById(request.getClassifications().get(0).getClassificationId())).thenReturn(data);

        var entity = data.get();
        when(lvlClassRepository.save(entity)).thenReturn(entity);

        var rs = presellClassificationServiceImpl.deleteClassification(request);
        assertNotNull(rs);
    }

    @Test
    public void updateClassification() {
        // prepare data
        PresellClassificationRequestDTO request = new PresellClassificationRequestDTO();
        List<ClassificationDTO> classifications = new ArrayList<ClassificationDTO>();
        classifications.add(new ClassificationDTO(13, "ABCCCCC", DatetimeUtils.getUTCTimestamp()));

        request.setClassifications(classifications);
        request.setUserId("rparo");

        Timestamp maxModDB = new Timestamp(DatetimeUtils.getUTCTimestamp().getTime() - 60*60*1000);
        when(lvlClassRepository.getMaxModTs()).thenReturn(maxModDB);

        LvlClass result = new LvlClass(13, "AB", "N", "rparo", DatetimeUtils.getUTCTimestamp(), "rparo",
                DatetimeUtils.getUTCTimestamp());
        Optional<LvlClass> data = Optional.of(result);
        when(lvlClassRepository.findById(request.getClassifications().get(0).getClassificationId())).thenReturn(data);
        var entity = data.get();
        when(lvlClassRepository.save(entity)).thenReturn(entity);
        var rs = presellClassificationServiceImpl.insertOrUpdateClassification(request);
        assertNotNull(rs);
    }

    @Test
    public void insertClassification() {
        // prepare data
        PresellClassificationRequestDTO request = new PresellClassificationRequestDTO();
        List<ClassificationDTO> classifications = new ArrayList<ClassificationDTO>();
        classifications.add(new ClassificationDTO(0, "DDD", DatetimeUtils.getUTCTimestamp()));

        request.setClassifications(classifications);
        request.setUserId("rparo");

        Timestamp maxModDB = DatetimeUtils.getUTCTimestamp();
        when(lvlClassRepository.getMaxModTs()).thenReturn(maxModDB);

        var lvlClass = new LvlClass();
        int psellClsId = 0;
        when(lvlClassRepository.getMaxId() + 1).thenReturn(psellClsId);
        lvlClass.setPsellClsIdNbr(psellClsId);
        lvlClass.setLgclDelFlg("N");
        lvlClass.setPsellLvlClsCd(request.getClassifications().get(0).getClassificationDsc());
        lvlClass.setAddUserId(request.getUserId());
        lvlClass.setModUserId(request.getUserId());
        var rs = presellClassificationServiceImpl.insertOrUpdateClassification(request);
        assertNotNull(rs);
    }
}
