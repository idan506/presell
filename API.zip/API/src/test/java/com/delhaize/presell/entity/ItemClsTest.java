package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ItemClsTest {

   @InjectMocks
   ItemCls itemCls;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       itemCls.setItemClsPk(new ItemClsPK());
       assertNotNull(itemCls.getItemClsPk());
       itemCls.setMdseDeptNbr(1);
       assertNotNull(itemCls.getMdseDeptNbr());
       itemCls.setMdseSubDeptNbr(1);
       assertNotNull(itemCls.getMdseSubDeptNbr());
       itemCls.setMjrCatgId("TEST");
       assertNotNull(itemCls.getMjrCatgId());
       itemCls.setIntmdCatgId("TEST");
       assertNotNull(itemCls.getIntmdCatgId());
       itemCls.setMnrCatgId("TEST");
       assertNotNull(itemCls.getMnrCatgId());
       itemCls.setModUserId("TEST");
       assertNotNull(itemCls.getModUserId());
       itemCls.setModPgmId("TEST");
       assertNotNull(itemCls.getModPgmId());
       itemCls.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(itemCls.getModTs());

       assertNotEquals(itemCls, new ItemCls());
       System.out.println(itemCls.hashCode());
       System.out.println(itemCls.toString());
   }
}
