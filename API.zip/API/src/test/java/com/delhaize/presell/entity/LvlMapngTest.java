package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LvlMapngTest {

   @InjectMocks
   LvlMapng lvlMapng;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       lvlMapng.setLvlMapngPk(new LvlMapngPK());
       assertNotNull(lvlMapng.getLvlMapngPk());
       lvlMapng.setPsellClsIdNbr(1);
       assertNotNull(lvlMapng.getPsellClsIdNbr());
       lvlMapng.setAddUserId("TEST");
       assertNotNull(lvlMapng.getAddUserId());
       lvlMapng.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(lvlMapng.getAddTs());
       lvlMapng.setModUserId("TEST");
       assertNotNull(lvlMapng.getModUserId());
       lvlMapng.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(lvlMapng.getModTs());

       assertNotEquals(lvlMapng, new LvlMapng());
       System.out.println(lvlMapng.hashCode());
       System.out.println(lvlMapng.toString());
   }
}
