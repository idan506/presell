package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ItemsPKTest {

   @InjectMocks
   ItemsPK itemsPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       itemsPk.setPsellIdNbr(1);
       assertNotNull(itemsPk.getPsellIdNbr());
       itemsPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(itemsPk.getItemNbr());
       itemsPk.setShipDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(itemsPk.getShipDt());
   }
}
