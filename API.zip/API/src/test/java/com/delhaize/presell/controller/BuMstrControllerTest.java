package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.service.BuMstrService;
import com.delhaize.web.exception.EntityNotFoundException;

public class BuMstrControllerTest {
	@InjectMocks
	BuMstrController buMstrController;
	
	@Mock
	BuMstrService buMstrService;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void getBusUnitSuccess() {
		List<BusUnitDTO> listBusUnit = new ArrayList<>();
		listBusUnit.add(new BusUnitDTO("A", "A"));
		when(buMstrService.getBusUnit()).thenReturn(listBusUnit);
		var rs = buMstrController.getBusUnit();
		assertEquals(1, rs.getBody().size());
	}
	

}
