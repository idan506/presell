package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class StorItemsPKTest {

   @InjectMocks
   StorItemsPK storItemsPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       storItemsPk.setPsellIdNbr(1);
       assertNotNull(storItemsPk.getPsellIdNbr());
       storItemsPk.setStoreNbr(1);
       assertNotNull(storItemsPk.getStoreNbr());
       storItemsPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(storItemsPk.getItemNbr());
       storItemsPk.setShipDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(storItemsPk.getShipDt());
   }
}
