package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DuDcXrefPKTest {

   @InjectMocks
   DuDcXrefPK duDcXrefPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       duDcXrefPk.setItemSetNbr(1);
       assertNotNull(duDcXrefPk.getItemSetNbr());
       duDcXrefPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(duDcXrefPk.getItemNbr());
       duDcXrefPk.setDistItemSeqNbr(1);
       assertNotNull(duDcXrefPk.getDistItemSeqNbr());
       duDcXrefPk.setDcSidNbr(1);
       assertNotNull(duDcXrefPk.getDcSidNbr());
   }
}
