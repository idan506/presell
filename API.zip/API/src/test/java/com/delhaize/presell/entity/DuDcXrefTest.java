package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DuDcXrefTest {

   @InjectMocks
   DuDcXref duDcXref;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       duDcXref.setDuDcXrefPk(new DuDcXrefPK());
       assertNotNull(duDcXref.getDuDcXrefPk());
       duDcXref.setDcitmStatCd("TEST");
       assertNotNull(duDcXref.getDcitmStatCd());
       duDcXref.setDcitmDcntuDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(duDcXref.getDcitmDcntuDt());
       duDcXref.setSlctSlotId("TEST");
       assertNotNull(duDcXref.getSlctSlotId());
       duDcXref.setDcPlltTiCnt(1);
       assertNotNull(duDcXref.getDcPlltTiCnt());
       duDcXref.setDcPlltHiCnt(1);
       assertNotNull(duDcXref.getDcPlltHiCnt());
       duDcXref.setAutoOrderCd("TEST");
       assertNotNull(duDcXref.getAutoOrderCd());
       duDcXref.setXdockCd("TEST");
       assertNotNull(duDcXref.getXdockCd());
       duDcXref.setDcitmSlctMthdCd("TEST");
       assertNotNull(duDcXref.getDcitmSlctMthdCd());
       duDcXref.setWhseOrderTypCd("TEST");
       assertNotNull(duDcXref.getWhseOrderTypCd());
       duDcXref.setCyclCntCd("TEST");
       assertNotNull(duDcXref.getCyclCntCd());
       duDcXref.setMaxStoreOrdQty(1);
       assertNotNull(duDcXref.getMaxStoreOrdQty());
       duDcXref.setOrderTypId("TEST");
       assertNotNull(duDcXref.getOrderTypId());
       duDcXref.setMstrRptVendId("TEST");
       assertNotNull(duDcXref.getMstrRptVendId());
       duDcXref.setInfVendId("TEST");
       assertNotNull(duDcXref.getInfVendId());
       duDcXref.setInfProfTagId("TEST");
       assertNotNull(duDcXref.getInfProfTagId());
       duDcXref.setInfOrderMlt(1);
       assertNotNull(duDcXref.getInfOrderMlt());
       duDcXref.setCmprItemNbr(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getCmprItemNbr());
       duDcXref.setAvgWkSlsAmt(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getAvgWkSlsAmt());
       duDcXref.setDcSvcLvlCd("TEST");
       assertNotNull(duDcXref.getDcSvcLvlCd());
       duDcXref.setInfOrdStratDur(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getInfOrdStratDur());
       duDcXref.setInfLdtmDaysDur(1);
       assertNotNull(duDcXref.getInfLdtmDaysDur());
       duDcXref.setSnlEmerCtrlCd("TEST");
       assertNotNull(duDcXref.getSnlEmerCtrlCd());
       duDcXref.setInfMinOrderQty(1);
       assertNotNull(duDcXref.getInfMinOrderQty());
       duDcXref.setMaxPfcstOrdQty(1);
       assertNotNull(duDcXref.getMaxPfcstOrdQty());
       duDcXref.setSftyStkQty(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getSftyStkQty());
       duDcXref.setSftyStkTypCd("TEST");
       assertNotNull(duDcXref.getSftyStkTypCd());
       duDcXref.setFbuyWkCnt(1);
       assertNotNull(duDcXref.getFbuyWkCnt());
       duDcXref.setSelWhseId(1);
       assertNotNull(duDcXref.getSelWhseId());
       duDcXref.setSubsItemNbr(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getSubsItemNbr());
       duDcXref.setRplcItemNbr(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getRplcItemNbr());
       duDcXref.setBillDeptId("TEST");
       assertNotNull(duDcXref.getBillDeptId());
       duDcXref.setDcitmFrceOutQty(1);
       assertNotNull(duDcXref.getDcitmFrceOutQty());
       duDcXref.setMinWhseShlfDur(1);
       assertNotNull(duDcXref.getMinWhseShlfDur());
       duDcXref.setInvGrpCd("TEST");
       assertNotNull(duDcXref.getInvGrpCd());
       duDcXref.setDcitmEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(duDcXref.getDcitmEffDt());
       duDcXref.setDcitmCrtDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(duDcXref.getDcitmCrtDt());
       duDcXref.setCatchWgtCd("TEST");
       assertNotNull(duDcXref.getCatchWgtCd());
       duDcXref.setAsscRoSidNbr(1);
       assertNotNull(duDcXref.getAsscRoSidNbr());
       duDcXref.setPendDcntuStatCd("TEST");
       assertNotNull(duDcXref.getPendDcntuStatCd());
       duDcXref.setPendDcntuStatDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(duDcXref.getPendDcntuStatDt());
       duDcXref.setRndByQty(1);
       assertNotNull(duDcXref.getRndByQty());
       duDcXref.setRndByPct(1);
       assertNotNull(duDcXref.getRndByPct());
       duDcXref.setRndToQty(1);
       assertNotNull(duDcXref.getRndToQty());
       duDcXref.setRndToPlltQty(1);
       assertNotNull(duDcXref.getRndToPlltQty());
       duDcXref.setRndFlg("TEST");
       assertNotNull(duDcXref.getRndFlg());
       duDcXref.setSvcLvlTgtTypCd("TEST");
       assertNotNull(duDcXref.getSvcLvlTgtTypCd());
       duDcXref.setInitNsnlDmndQty(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getInitNsnlDmndQty());
       duDcXref.setModUserId("TEST");
       assertNotNull(duDcXref.getModUserId());
       duDcXref.setModPgmId("TEST");
       assertNotNull(duDcXref.getModPgmId());
       duDcXref.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(duDcXref.getModTs());
       duDcXref.setMcDcSidNbr(1);
       assertNotNull(duDcXref.getMcDcSidNbr());
       duDcXref.setMcVendId("TEST");
       assertNotNull(duDcXref.getMcVendId());
       duDcXref.setMcInfOrderMlt(1);
       assertNotNull(duDcXref.getMcInfOrderMlt());
       duDcXref.setRdcMinOrderQty(1);
       assertNotNull(duDcXref.getRdcMinOrderQty());
       duDcXref.setRdcSftyStkQty(new java.math.BigDecimal(1));
       assertNotNull(duDcXref.getRdcSftyStkQty());
       duDcXref.setRdcSftystkTypCd("TEST");
       assertNotNull(duDcXref.getRdcSftystkTypCd());
       duDcXref.setOrdMinOrderQty(1);
       assertNotNull(duDcXref.getOrdMinOrderQty());
       duDcXref.setProdTypCd("TEST");
       assertNotNull(duDcXref.getProdTypCd());
       duDcXref.setWhOrdTypCd("TEST");
       assertNotNull(duDcXref.getWhOrdTypCd());

       assertNotEquals(duDcXref, new DuDcXref());
       System.out.println(duDcXref.hashCode());
       System.out.println(duDcXref.toString());
   }
}
