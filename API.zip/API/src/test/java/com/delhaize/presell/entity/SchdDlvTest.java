package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SchdDlvTest {

   @InjectMocks
   SchdDlv schdDlv;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       schdDlv.setSchdDlvPk(new SchdDlvPK());
       assertNotNull(schdDlv.getSchdDlvPk());
       schdDlv.setBtchLoadId("TEST");
       assertNotNull(schdDlv.getBtchLoadId());
       schdDlv.setSchdArrvDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(schdDlv.getSchdArrvDt());
       schdDlv.setSchdArrvTm(new java.sql.Time(System.currentTimeMillis()));
       assertNotNull(schdDlv.getSchdArrvTm());
       schdDlv.setBtchId("TEST");
       assertNotNull(schdDlv.getBtchId());
       schdDlv.setSchdTrnmtDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(schdDlv.getSchdTrnmtDt());
       schdDlv.setSchdTrnmtTm(new java.sql.Time(System.currentTimeMillis()));
       assertNotNull(schdDlv.getSchdTrnmtTm());
       schdDlv.setMsgCd("TEST");
       assertNotNull(schdDlv.getMsgCd());
       schdDlv.setMlbagFlg("TEST");
       assertNotNull(schdDlv.getMlbagFlg());
       schdDlv.setTempSchdFlg("TEST");
       assertNotNull(schdDlv.getTempSchdFlg());
       schdDlv.setSchdDeprtDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(schdDlv.getSchdDeprtDt());
       schdDlv.setSchdDeprtTm(new java.sql.Time(System.currentTimeMillis()));
       assertNotNull(schdDlv.getSchdDeprtTm());
       schdDlv.setAddUserId("TEST");
       assertNotNull(schdDlv.getAddUserId());
       schdDlv.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(schdDlv.getAddTs());
       schdDlv.setModUserId("TEST");
       assertNotNull(schdDlv.getModUserId());
       schdDlv.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(schdDlv.getModTs());

       assertNotEquals(schdDlv, new SchdDlv());
       System.out.println(schdDlv.hashCode());
       System.out.println(schdDlv.toString());
   }
}
