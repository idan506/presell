package com.delhaize.presell.repository.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import com.delhaize.presell.dto.request.StoreSearchCriteria;

public class StoreDAOImplTest {
	@InjectMocks
	StoreDAOImpl storeDAOImpl;
	
	@Mock
	EntityManager entityManager;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void searchStoreWithDistrict() {
		
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrBusinessUnit("A");
		String[] district = {"A", "B"};
		criteria.setStrDistrict(district);

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeDAOImpl.searchStore(criteria);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreWithDivision() {
		
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrBusinessUnit("A");
		String[] division = {"A", "B"};
		criteria.setStrDivision(division);

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeDAOImpl.searchStore(criteria);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreWithLocation() {
		
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrBusinessUnit("A");
		String[] location = {"A", "B"};
		criteria.setStrStoreLoc(location);

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeDAOImpl.searchStore(criteria);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreByStoreNo() {
		
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrBusinessUnit("A");
		criteria.setStrStoreNo("1");

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeDAOImpl.searchStore(criteria);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreByStoreNosAlreadyAdded() {
		
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrBusinessUnit("A");
		criteria.setStrStoreNosAlreadyAdded("1");

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeDAOImpl.searchStore(criteria);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreWithNullPageable() {
		
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrBusinessUnit("A");
		criteria.setStrStoreNosAlreadyAdded("1");

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeDAOImpl.searchStore(criteria);
		assertNotNull(rs);
	}
	
}
