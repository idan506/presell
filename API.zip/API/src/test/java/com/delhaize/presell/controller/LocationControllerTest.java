package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.projection.LocOrgProjection;
import com.delhaize.presell.dto.projection.StateProjection;
import com.delhaize.presell.service.LocationService;
import com.delhaize.web.exception.EntityNotFoundException;

public class LocationControllerTest {
	@InjectMocks
	LocationController locationController;
	
	@Mock
	LocationService locationService;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void getDivisionsSuccess() {
		List<LocOrgProjection> listDivisions = new ArrayList<>();
		listDivisions.add(new LocOrgProjection() {
			
			@Override
			public Integer getLocOrgSidNbr() {
				return 1;
			}
			
			@Override
			public String getLocOrgDsc() {
				return "A";
			}
		});
		
		when(locationService.getDivisions()).thenReturn(listDivisions);
		var rs = locationController.getDivisions();
		assertEquals(1, rs.getBody().size());
	}
	@Disabled
	@Test
	void getDivisionsNotFound() {
		when(locationService.getDivisions()).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> locationController.getDivisions());
	}
	
	@Test
	void getDistrictsSuccess() {
		List<LocOrgProjection> listDistricts = new ArrayList<>();
		listDistricts.add(new LocOrgProjection() {
			
			@Override
			public Integer getLocOrgSidNbr() {
				return 1;
			}
			
			@Override
			public String getLocOrgDsc() {
				return "A";
			}
		});
		
		when(locationService.getDistricts()).thenReturn(listDistricts);
		var rs = locationController.getDistricts();
		assertEquals(1, rs.getBody().size());
	}
	@Disabled
	@Test
	void getDistrictsNotFound() {
		when(locationService.getDistricts()).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> locationController.getDistricts());
	}
	
	@Test
	void getStatesSuccess() {
		List<StateProjection> listStates = new ArrayList<>();
		listStates.add(new StateProjection() {
			
			@Override
			public String getState() {
				return "A";
			}
		});
		
		when(locationService.getStates()).thenReturn(listStates);
		var rs = locationController.getStates();
		assertEquals(1, rs.getBody().size());
	}
	@Disabled
	@Test
	void getStatesNotFound() {
		when(locationService.getStates()).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> locationController.getStates());
	}
	
}
