package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PreselLogPKTest {

   @InjectMocks
   PreselLogPK preselLogPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       preselLogPk.setPsellIdNbr(1);
       assertNotNull(preselLogPk.getPsellIdNbr());
       preselLogPk.setAudLogTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(preselLogPk.getAudLogTs());
       preselLogPk.setStoreNbr(1);
       assertNotNull(preselLogPk.getStoreNbr());
       preselLogPk.setAddUserId("TEST");
       assertNotNull(preselLogPk.getAddUserId());
   }
}
