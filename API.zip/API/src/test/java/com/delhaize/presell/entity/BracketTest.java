package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BracketTest {

   @InjectMocks
   Bracket bracket;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       bracket.setBrktSidNbr(1);
       assertNotNull(bracket.getBrktSidNbr());
       bracket.setVendSetNbr(1);
       assertNotNull(bracket.getVendSetNbr());
       bracket.setVendId("TEST");
       assertNotNull(bracket.getVendId());
       bracket.setVendShpntSeqNbr(1);
       assertNotNull(bracket.getVendShpntSeqNbr());
       bracket.setLocSidNbr(1);
       assertNotNull(bracket.getLocSidNbr());
       bracket.setBrktEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(bracket.getBrktEffDt());
       bracket.setBrktRateTypCd("TEST");
       assertNotNull(bracket.getBrktRateTypCd());
       bracket.setVendBrktId("TEST");
       assertNotNull(bracket.getVendBrktId());
       bracket.setBrktMinOrderQty(1);
       assertNotNull(bracket.getBrktMinOrderQty());
       bracket.setBrktMaxOrderQty(1);
       assertNotNull(bracket.getBrktMaxOrderQty());
       bracket.setFullTrkFlg("TEST");
       assertNotNull(bracket.getFullTrkFlg());
       bracket.setEstPerfLvlFlg("TEST");
       assertNotNull(bracket.getEstPerfLvlFlg());
       bracket.setFobCd("TEST");
       assertNotNull(bracket.getFobCd());
       bracket.setBrktNbr(1);
       assertNotNull(bracket.getBrktNbr());
       bracket.setModUserId("TEST");
       assertNotNull(bracket.getModUserId());
       bracket.setModPgmId("TEST");
       assertNotNull(bracket.getModPgmId());
       bracket.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(bracket.getModTs());

       assertNotEquals(bracket, new Bracket());
       System.out.println(bracket.hashCode());
       System.out.println(bracket.toString());
   }
}
