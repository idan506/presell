package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.ClassificationDTO;
import com.delhaize.presell.dto.request.PresellClassificationRequestDTO;
import com.delhaize.presell.service.PresellClassificationService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;

public class PresellClassificationControllerTest {
	@InjectMocks
	PresellClassificationController presellClassificationController;
	
	@Mock
	PresellClassificationService classificationService;

	private UserSSOInfo user;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
		user = new UserSSOInfo();
		user.setUserId("userId");
		user.setRole(Secured.UserRole.ADMIN);
		user.setStoreNbr(1234);
	}
	
	@Test
	void getClassificationSuccess() {
		List<ClassificationDTO> listClassifications = new ArrayList<>();
		listClassifications.add(new ClassificationDTO(1, "A", DatetimeUtils.getUTCTimestamp()));
		
		when(classificationService.getClassification()).thenReturn(listClassifications);
		var rs = presellClassificationController.getClassification();
		assertEquals(1, rs.getBody().size());
	}
	@Disabled
	@Test
	void getClassificationNotFound() {
		when(classificationService.getClassification()).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> presellClassificationController.getClassification());
	}
	
	@Test
	void deleteClassificationSuccess() {
		List<ClassificationDTO> classifications = new ArrayList<>();
		classifications.add(new ClassificationDTO(1, "A", DatetimeUtils.getUTCTimestamp()));
		PresellClassificationRequestDTO request = new PresellClassificationRequestDTO();
		request.setUserId("rparo");
		request.setClassifications(classifications);
		
		when(classificationService.deleteClassification(request)).thenReturn(1);
		var rs = presellClassificationController.deleteClassification(request, user);
		assertEquals(1, rs.getBody());
		
	}
	
	@Test
	void deleteClassificationError() {
		when(classificationService.deleteClassification(null)).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> presellClassificationController.deleteClassification(null, user));
	}
	
	@Test
	void insertOrUpdatePresellLevelSuccess() {
		List<ClassificationDTO> classifications = new ArrayList<>();
		classifications.add(new ClassificationDTO(1, "A", DatetimeUtils.getUTCTimestamp()));
		PresellClassificationRequestDTO request = new PresellClassificationRequestDTO();
		request.setUserId("rparo");
		request.setClassifications(classifications);
		
		when(classificationService.insertOrUpdateClassification(request)).thenReturn(1);
		var rs = presellClassificationController.insertOrUpdatePresellLevel(request, user);
		assertEquals(1, rs.getBody());
	}
	
	@Test
	void insertOrUpdatePresellLevelError() {
		when(classificationService.insertOrUpdateClassification(null)).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> presellClassificationController.insertOrUpdatePresellLevel(null, user));
	}
}
