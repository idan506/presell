package com.delhaize.presell.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class APIDocConfigTest {

    @InjectMocks
    APIDocConfig apiDocConfig;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testConfig() {
        assertNotNull(apiDocConfig.customOpenAPI("1.0.0", "app dsc", "presell"));
    }

}
