package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class StrFlagsPKTest {

   @InjectMocks
   StrFlagsPK strFlagsPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       strFlagsPk.setStoreSidNbr(1);
       assertNotNull(strFlagsPk.getStoreSidNbr());
       strFlagsPk.setFlgNam("TEST");
       assertNotNull(strFlagsPk.getFlgNam());
   }
}
