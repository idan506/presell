package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LvlMapngPKTest {

   @InjectMocks
   LvlMapngPK lvlMapngPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       lvlMapngPk.setStoreNbr(1);
       assertNotNull(lvlMapngPk.getStoreNbr());
       lvlMapngPk.setPsellLvlIdNbr(1);
       assertNotNull(lvlMapngPk.getPsellLvlIdNbr());
   }
}
