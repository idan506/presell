package com.delhaize.presell.repository.template;

import com.delhaize.presell.entity.StorItems;
import com.delhaize.presell.entity.StorItemsPK;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class ItemBatchJDBCTemplateTest {

    private ItemBatchJDBCTemplate itemBatchJDBCTemplate;
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    void initSetup() {
        this.jdbcTemplate = mock(JdbcTemplate.class);
        this.itemBatchJDBCTemplate = new ItemBatchJDBCTemplate(jdbcTemplate);
    }

    @Test
    void testInserItems() throws SQLException {
        StorItems storItems = new StorItems();
        var storItemsPk = new StorItemsPK();
        storItemsPk.setPsellIdNbr(1);
        storItemsPk.setStoreNbr(1);
        storItemsPk.setItemNbr(new java.math.BigDecimal(1));
        storItemsPk.setShipDt(new java.sql.Date(System.currentTimeMillis()));
        storItems.setStorItemsPk(storItemsPk);
        storItems.setItemOrderQty(new java.math.BigDecimal(1));
        storItems.setAddUserId("TEST");
        storItems.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
        storItems.setModUserId("TEST");
        storItems.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
        var setter = new ItemBatchJDBCTemplate.ItemBatchInsertPreparedStatementSetter(List.of(storItems));
        setter.setValues(mock(PreparedStatement.class), 0);
        assertEquals(1, setter.getBatchSize());

        when(jdbcTemplate.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class))).thenReturn(new int[]{});
        assertDoesNotThrow(() -> itemBatchJDBCTemplate.batchInsert(List.of(storItems)));
    }
}
