package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LocOrgTest {

   @InjectMocks
   LocOrg locOrg;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       locOrg.setLocOrgSidNbr(1);
       assertNotNull(locOrg.getLocOrgSidNbr());
       locOrg.setLocOrgTypId("TEST");
       assertNotNull(locOrg.getLocOrgTypId());
       locOrg.setParntHierSidNbr(1);
       assertNotNull(locOrg.getParntHierSidNbr());
       locOrg.setLocOrgDsc("TEST");
       assertNotNull(locOrg.getLocOrgDsc());
       locOrg.setHierNbr(1);
       assertNotNull(locOrg.getHierNbr());
       locOrg.setModUserId("TEST");
       assertNotNull(locOrg.getModUserId());
       locOrg.setModPgmId("TEST");
       assertNotNull(locOrg.getModPgmId());
       locOrg.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(locOrg.getModTs());

       assertNotEquals(locOrg, new LocOrg());
       System.out.println(locOrg.hashCode());
       System.out.println(locOrg.toString());
   }
}
