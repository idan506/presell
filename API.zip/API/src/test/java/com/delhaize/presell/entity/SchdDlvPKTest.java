package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class SchdDlvPKTest {

   @InjectMocks
   SchdDlvPK schdDlvPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       schdDlvPk.setStoreNbr(1);
       assertNotNull(schdDlvPk.getStoreNbr());
       schdDlvPk.setBusUnitId("TEST");
       assertNotNull(schdDlvPk.getBusUnitId());
       schdDlvPk.setLoadNbr(1);
       assertNotNull(schdDlvPk.getLoadNbr());
       schdDlvPk.setSchdBtchProcDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(schdDlvPk.getSchdBtchProcDt());
       schdDlvPk.setProdTypCd("TEST");
       assertNotNull(schdDlvPk.getProdTypCd());
   }
}
