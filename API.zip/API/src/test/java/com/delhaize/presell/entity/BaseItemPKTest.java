package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BaseItemPKTest {

   @InjectMocks
   BaseItemPK baseItemPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       baseItemPk.setItemSetNbr(1);
       assertNotNull(baseItemPk.getItemSetNbr());
       baseItemPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(baseItemPk.getItemNbr());
   }
}
