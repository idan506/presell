package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.dto.MissingOrderDTO;
import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.StoreItemProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import com.delhaize.presell.service.PresellReportService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;

public class PresellReportControllerTest {
	@InjectMocks
	PresellReportController presellReportController;

	@Mock
	PresellReportService presellReportService;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void searchPresellReport() {
		PresellReportSearchCriteria criteria = new PresellReportSearchCriteria(null, null, null, null, null, null, null,
				null, null);

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		Page<PresellReportDTO> pageReport = null;
		when(presellReportService.searchPresellReport(criteria, paginationAndSortDTO)).thenReturn(pageReport);
		var rs = presellReportController.searchPresellReport(criteria, paginationAndSortDTO);
		assertNotNull(rs);
	}

	@Test
	void getPresellReportDetailsSuccess() {
		PresellReportDTO dto = new PresellReportDTO(1, "A", "A", "A", "A", DatetimeUtils.getCurrentSQLDate(), "A", "A", "A");
		when(presellReportService.getPresellReportDetails(1)).thenReturn(dto);
		var rs = presellReportController.getPresellReportDetails(1);
		assertNotNull(rs);
	}
	
	@Test
	void getPresellReportDetailsError() {
		when(presellReportService.getPresellReportDetails(null)).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> presellReportController.getPresellReportDetails(null));
	}
	
	@Test
	void getListItemReportSuccess() {
		List<ItemProjection> items = new ArrayList<>();
		items.add(new ItemProjection() {

			@Override
			public BigDecimal getSuggOrderQty() {
				return null;
			}

			@Override
			public Date getShipDt() {
				return null;
			}

			@Override
			public BigDecimal getRtlPrc() {
				return null;
			}

			@Override
			public String getPsellLvlClsCd() {
				return null;
			}

			@Override
			public String getPsellItemCmtTxt() {
				return null;
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return null;
			}

			@Override
			public Integer getPsellClsIdNbr() {
				return null;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return null;
			}

			@Override
			public String getItemSzCd() {
				return null;
			}

			@Override
			public Integer getItemPkQty() {
				return null;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return null;
			}

			@Override
			public BigDecimal getItemNbr() {
				return null;
			}

			@Override
			public String getItemImgUrl() {
				return null;
			}

			@Override
			public String getItemDsc() {
				return null;
			}

			@Override
			public BigDecimal getItemCapCst() {
				return null;
			}
		});
		when(presellReportService.getListItemReport(1)).thenReturn(items);
		var rs = presellReportController.getListItemReport(1);
		assertNotNull(rs);
	}
	@Disabled
	@Test
	void getListItemReportError() {
		when(presellReportService.getListItemReport(null)).thenReturn(anyList());
		assertThrows(EntityNotFoundException.class, () -> presellReportController.getListItemReport(null));
	}
	
	@Test
	void getListStoreItemReportSuccess() {
		List<StoreItemProjection> storeItems = new ArrayList<>();
		storeItems.add(new StoreItemProjection() {

			@Override
			public Integer getStoreNbr() {
				return null;
			}

			@Override
			public Date getShipDt() {
				return null;
			}

			@Override
			public BigDecimal getRtlPrc() {
				return null;
			}

			@Override
			public String getPsellLvlClsCd() {
				return null;
			}

			@Override
			public String getPsellItemCmtTxt() {
				return null;
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return null;
			}

			@Override
			public String getLocOrgDsc() {
				return null;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return null;
			}

			@Override
			public String getItemSzCd() {
				return null;
			}

			@Override
			public Integer getItemPkQty() {
				return null;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return null;
			}

			@Override
			public BigDecimal getItemNbr() {
				return null;
			}

			@Override
			public String getItemImgUrl() {
				return null;
			}

			@Override
			public String getItemDsc() {
				return null;
			}

			@Override
			public BigDecimal getItemCapCst() {
				return null;
			}
		});
		when(presellReportService.getListStoreItemReport(1)).thenReturn(storeItems);
		var rs = presellReportController.getListStoreItemReport(1);
		assertNotNull(rs);
	}
	@Disabled
	@Test
	void getListStoreItemReportError() {
		when(presellReportService.getListStoreItemReport(null)).thenReturn(anyList());
		assertThrows(EntityNotFoundException.class, () -> presellReportController.getListStoreItemReport(null));
	}
	
	@Test
	void getListMissingOrderReportSuccess() {
		MissingOrderDTO dto = new MissingOrderDTO();
		when(presellReportService.getListMissingOrderReport(1)).thenReturn(dto);
		var rs = presellReportController.getListMissingOrderReport(1);
		assertNotNull(rs);
	}
	@Disabled
	@Test
	void getListMissingOrderReportNotFound() {
		when(presellReportService.getListMissingOrderReport(anyInt())).thenReturn(any(MissingOrderDTO.class));
		assertThrows(EntityNotFoundException.class, () -> presellReportController.getListMissingOrderReport(1));
	}
	
	@Test
	void downloadToXLSPresellReportByItem() {
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test".getBytes());
		when(presellReportService.downLoadStorePresellItemReport(anyInt(), anyString())).thenReturn(anyByteArr);
		var rs = presellReportController.downloadToXLSPresellReportByItem(1);
    	assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}
	
	@Test
	void downloadToXLSPresellReportByStoreItem() {
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test".getBytes());
		when(presellReportService.downLoadStorePresellStoreItemReport(anyInt(), anyString())).thenReturn(anyByteArr);
		var rs = presellReportController.downloadToXLSPresellReportByStoreItem(1);
    	assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}
	
	@Test
	void downloadToXLSPresellReportByMissingOrder() {
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test".getBytes());
		when(presellReportService.downLoadStorePresellMissingOrderReport(anyInt(), anyString())).thenReturn(anyByteArr);
		var rs = presellReportController.downloadToXLSPresellReportByMissingOrder(1);
    	assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}
	
	@Test
	void downloadToXLSPresellReportByDraftOrder() {
		ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test".getBytes());
		when(presellReportService.downLoadStorePresellDraftReport(anyInt(), anyString())).thenReturn(anyByteArr);
		var rs = presellReportController.downloadToXLSPresellReportByDraftOrder(1);
    	assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}
}
