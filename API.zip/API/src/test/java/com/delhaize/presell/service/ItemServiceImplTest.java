package com.delhaize.presell.service;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.PresellLogProjection;
import com.delhaize.presell.dto.request.AddItemCommentForm;
import com.delhaize.presell.dto.request.ItemSearchCriteria;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.entity.Items;
import com.delhaize.presell.entity.ItemsPK;
import com.delhaize.presell.entity.Itmsoqmap;
import com.delhaize.presell.entity.ItmsoqmapPK;
import com.delhaize.presell.repository.*;
import com.delhaize.presell.repository.template.SOQBatchJDBCTemplate;
import com.delhaize.presell.service.impl.ItemServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;

import lombok.extern.log4j.Log4j2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@Log4j2
public class ItemServiceImplTest {

    @InjectMocks
    ItemServiceImpl itemServiceImpl;

    @Mock
    ItemsRepository itemsRepository;

    @Mock
    DistcsttypRepository distcsttypRepository;

    @Mock
    DistCostRepository distCostRepository;

    @Mock
    DuCntrRepository duCntrRepository;

    @Mock
    BaseItemRepository baseItemRepository;

    @Mock
    RtlPrcRepository rtlPrcRepository;

    @Mock
    ItmsoqmapRepository itmsoqmapRepository;

    @Mock
    ItemProjection ItemProjection;

    @Mock
    PreselLogRepository preselLogRepository;

    @Mock
    SOQBatchJDBCTemplate soqBatchJDBCTemplate;

    @Mock
    PresellRepository presellRepository;

    @Mock
    LvlMapngRepository lvlMapngRepository;

    @Mock
    LvlClassRepository lvlClassRepository;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getListItemReport() {

        List<ItemProjection> item = new ArrayList<>();
        int presellnumber = 1860;
        item.add(new ItemProjection() {
            @Override
            public BigDecimal getItemNbr() {
                return null;
            }

            @Override
            public BigDecimal getItemOrderQty() {
                return null;
            }

            @Override
            public String getItemDsc() {
                return null;
            }

            @Override
            public Date getShipDt() {
                return null;
            }

            @Override
            public BigDecimal getItemCapCst() {
                return null;
            }

            @Override
            public BigDecimal getItemSzCnt() {
                return null;
            }

            @Override
            public String getItemSzCd() {
                return null;
            }

            @Override
            public Integer getItemPkQty() {
                return null;
            }

            @Override
            public BigDecimal getRtlPrc() {
                return null;
            }

            @Override
            public BigDecimal getPsellGrmrgAmt() {
                return null;
            }

            @Override
            public String getPsellItemCmtTxt() {
                return null;
            }

            @Override
            public String getItemImgUrl() {
                return null;
            }

            @Override
            public Integer getPsellClsIdNbr() {
                return null;
            }

            @Override
            public String getPsellLvlClsCd() {
                return null;
            }

            @Override
            public BigDecimal getSuggOrderQty() {
                return null;
            }

        });
        Mockito.when(itemsRepository.getListItem(presellnumber)).thenReturn(item);

        var rs = itemServiceImpl.getListItemReport(presellnumber);

        assertNotNull(rs);
    }

    @Test
    public void getItemDetails() throws SQLException {
        ItemSearchCriteria criteria = new ItemSearchCriteria();
        criteria.setItemNbr("111");
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);

        AddItemsDTO addItemDTO = new AddItemsDTO();
        BigDecimal itemNumber = new BigDecimal(criteria.getItemNbr());
        Mockito.when(itemsRepository.getItemDetails(itemNumber)).thenReturn(addItemDTO);
        when(itemServiceImpl.fetchItemDetails(busUnit, "1")).thenReturn(addItemDTO);

        List<DcDTO> listDc = new ArrayList<>();
        listDc.add(new DcDTO("1", "1"));
        when(itemsRepository.getDCIds(busUnit, itemNumber)).thenReturn(listDc);

        List<VendorInfoDTO> listVendorId = new ArrayList<>();
        listVendorId.add(new VendorInfoDTO("1", "A"));
        when(itemsRepository.getVendorId(itemNumber, 1)).thenReturn(listVendorId);

        List<String> list = new ArrayList<>();
        list.add("1,11,111,1111,0");

        // Vendor set number
        String[] arr = list.get(0).split(",");
        String vendorSetNbr = arr[4].trim();
        String vendorId = "1";
        String dcSidNbr = "1";
        String costMstrId = "1";
        when(itemsRepository.fetchSidNumber("1")).thenReturn(list);

        // Vendor cost
        List<String> listCostMstrId = new ArrayList<>();
        listCostMstrId.add("1");
        listCostMstrId.add("2");
        when(itemsRepository.fetchCostMstrId(itemNumber, vendorId, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listCostMstrId);

        // Get CstMstr Cost Details
        List<String> listCstMstrCost = new ArrayList<>();
        listCstMstrCost.add("1,2,3,1,1,1,1");
        when(itemsRepository.fetchCstmstrCostDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
                Mockito.anyInt(), Mockito.anyInt())).thenReturn(listCstMstrCost);

        // Get bracket number
        List<String> listBracketNumbs = new ArrayList<>();
        listBracketNumbs.add("0");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        when(itemsRepository.fetchDefaultBracketNumber(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),
                Mockito.any())).thenReturn(listBracketNumbs);

        // Get item deal detail
        List<String> listDealAmt = new ArrayList<>();
        listDealAmt.add("1,11,111,1111,123");
        when(itemsRepository.fetchCstmstrDealDetails(costMstrId, vendorId, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listDealAmt);

        List<String> mstrItem = new ArrayList<>();
        mstrItem.add("1,2,3,4");
        when(baseItemRepository.fetchPrcMstrItem(Mockito.any())).thenReturn(mstrItem);

        List<String> srpItem = new ArrayList<>();
        srpItem.add("1,2,3");
        when(rtlPrcRepository.fetchSrpItemPrcMstr(Mockito.anyString(), Mockito.anyString(), anyInt(), Mockito.any()))
                .thenReturn(srpItem);

        List<DistcsttypDTO> listDistCstType = new ArrayList<>();
        listDistCstType.add(new DistcsttypDTO("MERCH", "1", "CAPI", "1", "1", "1", "1", "1", "1"));
        when(distcsttypRepository.fetchDistCodeType(anyString())).thenReturn(listDistCstType);
        List<String> capFactor = new ArrayList<>();
        capFactor.add("1,1,1");
        when(distCostRepository.fetchCAPFactorCapCstMer(anyString(), anyInt(), Mockito.any())).thenReturn(capFactor);
        var rs = itemServiceImpl.getItemDetails(criteria, presell);
        assertNotNull(rs);
    }

    @Test
    public void getItemDetails1() {
        ItemSearchCriteria criteria = new ItemSearchCriteria();
        criteria.setItemNbr("111");
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);

        AddItemsDTO addItemDTO = new AddItemsDTO();
        BigDecimal itemNumber = new BigDecimal(criteria.getItemNbr());
        Mockito.when(itemsRepository.getItemDetails(itemNumber)).thenReturn(addItemDTO);
        when(itemServiceImpl.fetchItemDetails(busUnit, "1")).thenReturn(addItemDTO);

        List<DcDTO> listDc = new ArrayList<>();
        listDc.add(new DcDTO("1", "1"));
        when(itemsRepository.getDCIds(busUnit, itemNumber)).thenReturn(listDc);

        List<VendorInfoDTO> listVendorId = new ArrayList<>();
        listVendorId.add(new VendorInfoDTO("1", "A"));
        when(itemsRepository.getVendorId(itemNumber, 1)).thenReturn(listVendorId);

        List<String> list = new ArrayList<>();
        list.add("1,11,111,1111,0");

        // Vendor set number
        String[] arr = list.get(0).split(",");
        String vendorSetNbr = arr[4].trim();
        String dcSidNbr = "1";
        when(itemsRepository.fetchSidNumber("1")).thenReturn(list);

        // Vendor cost
        List<String> listCostMstrId = new ArrayList<>();
        listCostMstrId.add("1");
        listCostMstrId.add("2");

        when(itemsRepository.fetchCostMstrId(itemNumber, null, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listCostMstrId);

        // Get item cost detail
        List<String> listItemCosts = new ArrayList<>();
        listItemCosts.add("1,11,111,1111,123");
        when(itemsRepository.fetchItemCostDetails(Mockito.any(), anyString(), anyInt(), anyInt(), anyInt(),
                Mockito.any())).thenReturn(listItemCosts);

        // Get item deal detail
        List<String> listDealAmt = new ArrayList<>();
        listDealAmt.add("1,11,111,1111,123");
        when(itemsRepository.fetchItemDealDetails(Mockito.any(), anyString(), anyInt(), anyInt()))
                .thenReturn(listDealAmt);

        // Get bracket number
        List<String> listBracketNumbs = new ArrayList<>();
        listBracketNumbs.add("0");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        when(itemsRepository.fetchDefaultBracketNumber(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),
                Mockito.any())).thenReturn(listBracketNumbs);

        List<String> mstrItem = new ArrayList<>();
        mstrItem.add("1,2,3,4");
        when(baseItemRepository.fetchPrcMstrItem(Mockito.any())).thenReturn(mstrItem);

        List<String> srpItem = new ArrayList<>();
        srpItem.add("1,2,3");
        when(rtlPrcRepository.fetchSrpItemPrcMstr(Mockito.anyString(), Mockito.anyString(), anyInt(), Mockito.any()))
                .thenReturn(srpItem);

        List<DistcsttypDTO> listDistCstType = new ArrayList<>();
        listDistCstType.add(new DistcsttypDTO("OCCUPCY", "1", "OCCU", "1", "1", "1", "1", "1", "1"));
        when(distcsttypRepository.fetchDistCodeType(anyString())).thenReturn(listDistCstType);
        List<String> capFactor = new ArrayList<>();
        capFactor.add("1,1,1");
        when(distCostRepository.fetchCAPFactorHndCasCubOcc(anyString(), anyInt(), Mockito.any(), anyInt()))
                .thenReturn(capFactor);
        List<String> sellUnitCube = new ArrayList<>();
        sellUnitCube.add("1,1,1");
        when(duCntrRepository.fetchSellUnitCube(Mockito.any(), anyInt(), anyInt(), anyString()))
                .thenReturn(sellUnitCube);

        var rs = itemServiceImpl.getItemDetails(criteria, presell);
        assertNotNull(rs);
    }

    @Test
    public void getItemDetails2() throws SQLException {
        ItemSearchCriteria criteria = new ItemSearchCriteria();
        criteria.setItemNbr("111");
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);

        AddItemsDTO addItemDTO = new AddItemsDTO();
        BigDecimal itemNumber = new BigDecimal(criteria.getItemNbr());
        Mockito.when(itemsRepository.getItemDetails(itemNumber)).thenReturn(addItemDTO);
        when(itemServiceImpl.fetchItemDetails(busUnit, "1")).thenReturn(addItemDTO);

        List<DcDTO> listDc = new ArrayList<>();
        listDc.add(new DcDTO("1", "1"));
        when(itemsRepository.getDCIds(busUnit, itemNumber)).thenReturn(listDc);

        List<VendorInfoDTO> listVendorId = new ArrayList<>();
        listVendorId.add(new VendorInfoDTO("1", "A"));
        when(itemsRepository.getVendorId(itemNumber, 1)).thenReturn(listVendorId);

        List<String> list = new ArrayList<>();
        list.add("1,11,111,1111,0");

        // Vendor set number
        String[] arr = list.get(0).split(",");
        String vendorSetNbr = arr[4].trim();
        String vendorId = "1";
        String dcSidNbr = "1";
        String costMstrId = "1";
        String bracketNbr = "2";
        when(itemsRepository.fetchSidNumber("1")).thenReturn(list);

        // Vendor cost
        List<String> listCostMstrId = new ArrayList<>();
        listCostMstrId.add("1");
        listCostMstrId.add("2");
        when(itemsRepository.fetchCostMstrId(itemNumber, vendorId, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listCostMstrId);

        // Get CstMstr Cost Details
        List<String> listCstMstrCost = new ArrayList<>();
        listCstMstrCost.add("1,2,3,1,1,1,1");
        when(itemsRepository.fetchCstmstrCostDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
                Mockito.anyInt(), Mockito.anyInt())).thenReturn(listCstMstrCost);

        // Get bracket number
        List<String> listBracketNumbs = new ArrayList<>();
        listBracketNumbs.add("0");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        when(itemsRepository.fetchDefaultBracketNumber(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),
                Mockito.any())).thenReturn(listBracketNumbs);

        if (listBracketNumbs != null) {
            bracketNbr = listBracketNumbs.get(0).trim();
            log.info("bracket: " + bracketNbr);
        }

        // Get item deal detail
        List<String> listDealAmt = new ArrayList<>();
        listDealAmt.add("1,11,111,1111,123");
        when(itemsRepository.fetchCstmstrDealDetails(costMstrId, vendorId, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listDealAmt);

        List<String> mstrItem = new ArrayList<>();
        mstrItem.add("1,2,3,4");
        when(baseItemRepository.fetchPrcMstrItem(Mockito.any())).thenReturn(mstrItem);

        List<String> srpItem = new ArrayList<>();
        srpItem.add("1,2,3");
        when(rtlPrcRepository.fetchSrpItemPrcMstr(Mockito.anyString(), Mockito.anyString(), anyInt(), Mockito.any()))
                .thenReturn(srpItem);

        List<DistcsttypDTO> listDistCstType = new ArrayList<>();
        listDistCstType.add(new DistcsttypDTO("DELIVRY", "1", "MPCT", "1", "1", "1", "1", "1", "1"));
        when(distcsttypRepository.fetchDistCodeType(anyString())).thenReturn(listDistCstType);
        var rs = itemServiceImpl.getItemDetails(criteria, presell);
        assertNotNull(rs);
    }

    @Test
    public void getItemDetails3() throws SQLException {
        ItemSearchCriteria criteria = new ItemSearchCriteria();
        criteria.setItemNbr("111");
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);

        AddItemsDTO addItemDTO = new AddItemsDTO();

        BigDecimal itemNumber = new BigDecimal(criteria.getItemNbr());
        Mockito.when(itemsRepository.getItemDetails(itemNumber)).thenReturn(addItemDTO);
        when(itemServiceImpl.fetchItemDetails(busUnit, "1")).thenReturn(addItemDTO);

        List<DcDTO> listDc = new ArrayList<>();
        listDc.add(new DcDTO("1", "1"));
        when(itemsRepository.getDCIds(busUnit, itemNumber)).thenReturn(listDc);

        List<VendorInfoDTO> listVendorId = new ArrayList<>();
        listVendorId.add(new VendorInfoDTO("1", "A"));
        when(itemsRepository.getVendorId(itemNumber, 1)).thenReturn(listVendorId);

        List<String> list = new ArrayList<>();
        list.add("1,11,111,1111,0");

        // Vendor set number
        String[] arr = list.get(0).split(",");
        String vendorSetNbr = arr[4].trim();
        String vendorId = "1";
        String dcSidNbr = "1";
        String costMstrId = "1";
        String bracketNbr = "2";
        when(itemsRepository.fetchSidNumber("1")).thenReturn(list);

        // Vendor cost
        List<String> listCostMstrId = new ArrayList<>();
        listCostMstrId.add("1");
        listCostMstrId.add("2");
        when(itemsRepository.fetchCostMstrId(itemNumber, vendorId, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listCostMstrId);

        // Get CstMstr Cost Details
        List<String> listCstMstrCost = new ArrayList<>();
        listCstMstrCost.add("1,2,3,1,1,1,1");
        when(itemsRepository.fetchCstmstrCostDetails(Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
                Mockito.anyInt(), Mockito.anyInt())).thenReturn(listCstMstrCost);

        // Get bracket number
        List<String> listBracketNumbs = new ArrayList<>();
        listBracketNumbs.add("0");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        listBracketNumbs.add("1");
        when(itemsRepository.fetchDefaultBracketNumber(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(),
                Mockito.any())).thenReturn(listBracketNumbs);

        if (listBracketNumbs != null) {
            bracketNbr = listBracketNumbs.get(0).trim();
            log.info("bracket: " + bracketNbr);
        }

        // Get item deal detail
        List<String> listDealAmt = new ArrayList<>();
        listDealAmt.add("1,11,111,1111,123");
        when(itemsRepository.fetchCstmstrDealDetails(costMstrId, vendorId, Integer.parseInt(vendorSetNbr),
                Integer.parseInt(dcSidNbr))).thenReturn(listDealAmt);

        List<String> mstrItem = new ArrayList<>();
        mstrItem.add("1,2,3,4");
        when(baseItemRepository.fetchPrcMstrItem(Mockito.any())).thenReturn(mstrItem);

        List<String> srpItem = new ArrayList<>();
        srpItem.add("1,2,3");
        when(rtlPrcRepository.fetchSrpItemPrcMstr(Mockito.anyString(), Mockito.anyString(), anyInt(), Mockito.any()))
                .thenReturn(srpItem);

        List<DistcsttypDTO> listDistCstType = new ArrayList<>();
        listDistCstType.add(new DistcsttypDTO("DELIVRY", "1", "MPCT", "1", "1", "1", "1", "1", "1"));
        when(distcsttypRepository.fetchDistCodeType(anyString())).thenReturn(listDistCstType);
        var rs = itemServiceImpl.getItemDetails(criteria, presell);
        assertNotNull(rs);
    }

    @Test
    void DCNotSetForItemNumb() {
        ItemSearchCriteria criteria = new ItemSearchCriteria();
        criteria.setItemNbr("111");
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);

        AddItemsDTO addItemDTO = new AddItemsDTO();

        BigDecimal itemNumber = new BigDecimal(criteria.getItemNbr());
        Mockito.when(itemsRepository.getItemDetails(itemNumber)).thenReturn(addItemDTO);
        when(itemServiceImpl.fetchItemDetails(busUnit, "1")).thenReturn(addItemDTO);

        when(itemsRepository.getDCIds(busUnit, itemNumber)).thenReturn(null);

        var rs = itemServiceImpl.getItemDetails(criteria, presell);
        assertNotNull(rs);
    }

    @Test
    void addDSDItem() {
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("A", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "A", "A", "A", "A", "A", "A", "A", "A", null, "A", "A", "A", "A", "A", null, null, "A", "A", "A", "A",
                "A"));
        presell.setItemDTOList(lisAddItemsDTOs);
        var rs = itemServiceImpl.addDSDItem(presell);
        assertNotNull(rs);
    }

    @Test
    void addDSDItemWithNullRequestBody() {
        var rs = itemServiceImpl.addDSDItem(null);
        assertNotNull(rs);
    }

    @Test
    void addItemComment() {
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1234);
        presell.setStoreDTOList(store);
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setBusUnitId("Ause");
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "A", "A", "A", "A", "A", "A", "A", "A", null, "A", "A", "A", "A", "A", null, null, "A", "A", "A", "A",
                "A"));
        presell.setItemDTOList(lisAddItemsDTOs);

        AddItemCommentForm form = new AddItemCommentForm();
        form.setItemComment("A");
        form.setUserId("rparo");
        form.setSelectedIndex("1");

        var rs = itemServiceImpl.addItemComment(form, presell);
        assertNotNull(rs);
    }

    @Test
    void addItemCommentError() {
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1234);
        presell.setStoreDTOList(store);
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setBusUnitId("Ause");
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("A", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "A", "A", "A", "A", "A", "A", "A", "A", null, "A", "A", "A", "A", "A", null, null, "A", "A", "A", "A",
                "A"));
        presell.setItemDTOList(lisAddItemsDTOs);

        AddItemCommentForm form = new AddItemCommentForm();
        form.setItemComment("A");
        form.setUserId("rparo");
        form.setSelectedIndex("1");

        var rs = itemServiceImpl.addItemComment(form, presell);
        assertNotNull(rs);
    }

    @Test
    void insertNewItemForPresell() {
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);
        List<ItemSOQDTO> itemSOQ = new ArrayList<>();
        ItemSOQDTO item = new ItemSOQDTO();
        item.setClassificationId(1);
        item.setClassificationDsc("A");
        item.setQuantity(new BigDecimal(1));
        itemSOQ.add(item);
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.INSERT, DBStatus.NEW,
                "DSD", "1", "1", "1", "1"));
        presell.setItemDTOList(lisAddItemsDTOs);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("rparo");
        request.setAction(SavePresellAction.SEND_TO_STORES);

        when(itemsRepository.getMinItemIdNbr(request.getPresellDetail().getPsellIdNbr())).thenReturn(new BigDecimal(1));

        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId(request.getUserId());
        itmsoqmap.setModUserId(request.getUserId());

        when(itmsoqmapRepository.save(itmsoqmap)).thenReturn(itmsoqmap);
        doNothing().when(soqBatchJDBCTemplate).insertSOQ(anyList());
        doNothing().when(soqBatchJDBCTemplate).updateSOQ(anyList());

        var rs = itemServiceImpl.insertOrUpdateItemForPresell(request);
        assertEquals(0, rs);
    }

    @Test
    void insertOldItemForPresell() {
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);
        List<ItemSOQDTO> itemSOQ = new ArrayList<>();
        ItemSOQDTO item = new ItemSOQDTO();
        item.setClassificationId(1);
        item.setClassificationDsc("A");
        item.setQuantity(new BigDecimal(1));
        itemSOQ.add(item);
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.INSERT, DBStatus.OLD,
                "1", "1", "1", "1", "1"));
        presell.setItemDTOList(lisAddItemsDTOs);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("rparo");
        request.setAction(SavePresellAction.SEND_TO_STORES);

        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId(request.getUserId());
        itmsoqmap.setModUserId(request.getUserId());

        when(itmsoqmapRepository.save(itmsoqmap)).thenReturn(itmsoqmap);

        var itemEntity = new Items();
        var itemPk = new ItemsPK();
        itemPk.setPsellIdNbr(1);
        itemPk.setItemNbr(new BigDecimal(1));
        itemPk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        itemEntity.setItemsPk(itemPk);
        itemEntity.setItemCst(new BigDecimal(1));
        itemEntity.setItemSzCnt(new BigDecimal(1));
        itemEntity.setItemSzCd("1");
        itemEntity.setItemPkQty(1);
        itemEntity.setItemCapCst(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setRtlPrc(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setPsellGrmrgAmt(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setItemDsc("111");
        itemEntity.setPsellItemCmtTxt("111");
        itemEntity.setItemImgUrl("AAA");
        itemEntity.setItemCntrbPct(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setAddUserId(request.getUserId());
        itemEntity.setModUserId(request.getUserId());

        when(itemsRepository.save(itemEntity)).thenReturn(itemEntity);
        doNothing().when(soqBatchJDBCTemplate).insertSOQ(anyList());
        doNothing().when(soqBatchJDBCTemplate).updateSOQ(anyList());

        var rs = itemServiceImpl.insertOrUpdateItemForPresell(request);
        assertEquals(0, rs);
    }

    @Test
    void updateItemForPresell() {
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);
        List<ItemSOQDTO> itemSOQ = new ArrayList<>();
        ItemSOQDTO item = new ItemSOQDTO();
        item.setClassificationId(1);
        item.setClassificationDsc("A");
        item.setQuantity(new BigDecimal(1));
        itemSOQ.add(item);
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.UPDATE, DBStatus.NEW,
                "1", "1", "1", "1", "1"));
        presell.setItemDTOList(lisAddItemsDTOs);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("rparo");
        request.setAction(SavePresellAction.SEND_TO_STORES);

        var itemEntity = new Items();
        var itemPk = new ItemsPK();
        itemPk.setPsellIdNbr(1);
        itemPk.setItemNbr(new BigDecimal(1));
        itemPk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        itemEntity.setItemsPk(itemPk);
        itemEntity.setItemCst(new BigDecimal(1));
        itemEntity.setItemSzCnt(new BigDecimal(1));
        itemEntity.setItemSzCd("1");
        itemEntity.setItemPkQty(1);
        itemEntity.setItemCapCst(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setRtlPrc(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setPsellGrmrgAmt(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setItemDsc("111");
        itemEntity.setPsellItemCmtTxt("111");
        itemEntity.setItemImgUrl("AAA");
        itemEntity.setItemCntrbPct(new BigDecimal(1).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setAddUserId(request.getUserId());
        itemEntity.setModUserId(request.getUserId());


        Optional<Items> data = Optional.of(itemEntity);
        when(itemsRepository.findById(any())).thenReturn(data);
        when(itemsRepository.save(itemEntity)).thenReturn(itemEntity);

        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId(request.getUserId());
        itmsoqmap.setModUserId(request.getUserId());

        when(itmsoqmapRepository.save(itmsoqmap)).thenReturn(itmsoqmap);
        doNothing().when(soqBatchJDBCTemplate).insertSOQ(anyList());
        doNothing().when(soqBatchJDBCTemplate).updateSOQ(anyList());

        var rs = itemServiceImpl.insertOrUpdateItemForPresell(request);
        assertEquals(0, rs);
    }

    @Test
    void updateItemForPresell1() {
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);
        List<ItemSOQDTO> itemSOQ = new ArrayList<>();
        ItemSOQDTO item = new ItemSOQDTO();
        item.setClassificationId(1);
        item.setClassificationDsc("A");
        item.setQuantity(new BigDecimal(1));
        itemSOQ.add(item);
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.UPDATE, DBStatus.OLD,
                "1", "1", "1", "1", "1"));
        presell.setItemDTOList(lisAddItemsDTOs);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("rparo");
        request.setAction(SavePresellAction.SEND_TO_STORES);

        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId(request.getUserId());
        itmsoqmap.setModUserId(request.getUserId());

        Optional<Itmsoqmap> data = Optional.of(itmsoqmap);
        when(itmsoqmapRepository.findById(any())).thenReturn(data);

        when(itmsoqmapRepository.save(itmsoqmap)).thenReturn(itmsoqmap);
        doNothing().when(soqBatchJDBCTemplate).insertSOQ(anyList());
        doNothing().when(soqBatchJDBCTemplate).updateSOQ(anyList());

        var rs = itemServiceImpl.insertOrUpdateItemForPresell(request);
        assertEquals(0, rs);
    }

    @Test
    void deleteItemForPresell() {
        String busUnit = "Ause";
        List<StoreDTO> store = new ArrayList<>();
        store.add(
                new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1);
        presell.setPsellDsc("A");
        presell.setBusUnitId(busUnit);
        presell.setPsellLvlIdNbr(1);
        presell.setAddUserId("A");
        presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
        presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
        presell.setPlnDistFlg("Y");
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        presell.setStoreDTOList(store);
        List<ItemSOQDTO> itemSOQ = new ArrayList<>();
        ItemSOQDTO item = new ItemSOQDTO();
        item.setClassificationId(1);
        item.setClassificationDsc("A");
        item.setQuantity(new BigDecimal(1));
        itemSOQ.add(item);
        List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
        lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
                "1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.DELETE, DBStatus.OLD,
                "1", "1", "1", "1", "1"));
        presell.setItemDTOList(lisAddItemsDTOs);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("rparo");
        request.setAction(SavePresellAction.SEND_TO_STORES);

        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId(request.getUserId());
        itmsoqmap.setModUserId(request.getUserId());

        when(itmsoqmapRepository.save(itmsoqmap)).thenReturn(itmsoqmap);
        doNothing().when(soqBatchJDBCTemplate).insertSOQ(anyList());
        doNothing().when(soqBatchJDBCTemplate).updateSOQ(anyList());

        var rs = itemServiceImpl.insertOrUpdateItemForPresell(request);
        assertEquals(0, rs);
    }

    @Test
    public void getItemOrderDetails() {
        Integer psellIdNbr = 1232;
        Integer storeNbr = 3232;
        List<ItemProjection> listStoreItems = new ArrayList<>();
        listStoreItems.add(new ItemProjection() {
            @Override
            public BigDecimal getItemNbr() {
                BigDecimal itemNumber = new BigDecimal(123);
                return itemNumber;
            }

            @Override
            public BigDecimal getItemOrderQty() {
                return new BigDecimal(1);
            }

            @Override
            public String getItemDsc() {
                return "A";
            }

            @Override
            public Date getShipDt() {
                return DatetimeUtils.getCurrentSQLDate();
            }

            @Override
            public BigDecimal getItemCapCst() {
                return new BigDecimal(1);
            }

            @Override
            public BigDecimal getItemSzCnt() {
                return new BigDecimal(1);
            }

            @Override
            public String getItemSzCd() {
                return "A";
            }

            @Override
            public Integer getItemPkQty() {
                return 1;
            }

            @Override
            public BigDecimal getRtlPrc() {
                return new BigDecimal(1);
            }

            @Override
            public BigDecimal getPsellGrmrgAmt() {
                return new BigDecimal(1);
            }

            @Override
            public String getPsellItemCmtTxt() {
                return "A";
            }

            @Override
            public String getItemImgUrl() {
                return "A";
            }

            @Override
            public Integer getPsellClsIdNbr() {
                return 1;
            }

            @Override
            public String getPsellLvlClsCd() {
                return "A";
            }

            @Override
            public BigDecimal getSuggOrderQty() {
                return new BigDecimal(1);
            }
        });
        List<Integer> storeNbrList = new ArrayList<>();
        storeNbrList.add(1212);
        storeNbrList.add(3333);
        List<PresellLogProjection> logList = new ArrayList<>();
        logList.add(new PresellLogProjection() {
            @Override
            public Timestamp getAudLogTs() {
                return null;
            }

            @Override
            public String getAddUserId() {
                return null;
            }

            @Override
            public String getLogStatCd() {
                return null;
            }

            @Override
            public String getLogCmtTxt() {
                return null;
            }
        });
        Integer psellLevelID = 3;
        int clasificationID = 2;
        String lvlCd = "f";
        Mockito.when(itemsRepository.getListStoreItems(psellIdNbr, storeNbr)).thenReturn(listStoreItems);
        Mockito.when(preselLogRepository.getLogDetails(psellIdNbr, storeNbrList)).thenReturn(logList);
        Mockito.when(presellRepository.getLvlId(psellIdNbr)).thenReturn(psellLevelID);
        Mockito.when(lvlMapngRepository.getClsId(psellIdNbr, storeNbr)).thenReturn(clasificationID);
        Mockito.when(lvlClassRepository.getPreselLvlCd(psellLevelID)).thenReturn(lvlCd);
        var rs = itemServiceImpl.getItemOrderDetails(psellIdNbr, storeNbr);
        assertNotNull(rs);
    }
}
