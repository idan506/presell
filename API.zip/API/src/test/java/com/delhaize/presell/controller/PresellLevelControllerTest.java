package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.PresellLevelDTO;
import com.delhaize.presell.dto.request.PresellLevelRequestDTO;
import com.delhaize.presell.service.PresellLevelService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;

public class PresellLevelControllerTest {
	@InjectMocks
	PresellLevelController presellLevelController;
	
	@Mock
	PresellLevelService presellLevelService;

	private UserSSOInfo user;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
		user = new UserSSOInfo();
		user.setUserId("userId");
		user.setRole(Secured.UserRole.ADMIN);
		user.setStoreNbr(1234);
	}
	
	@Test
	void getPresellLevelSuccess() {
		List<PresellLevelDTO> request = new ArrayList<>();
		var d1 = new PresellLevelDTO();
		d1.setLevelId(1);
		d1.setLevelDsc("A");
		d1.setFetchTime(DatetimeUtils.getUTCTimestamp());
		request.add(d1);
		when(presellLevelService.getPresellLevel()).thenReturn(request);
		var rs = presellLevelController.getPresellLevel();
		assertEquals(1, Objects.requireNonNull(rs.getBody()).size());
	}
	
	@Disabled
	@Test
	void getPresellLevelError() {
		List<PresellLevelDTO> request = new ArrayList<>();
		when(presellLevelService.getPresellLevel()).thenReturn(request);
		assertThrows(EntityNotFoundException.class, () -> presellLevelController.getPresellLevel());
	}
	
	@Test
	void deletePresellLevelSuccess() {
		PresellLevelRequestDTO request = buildRequestDTO();
		when(presellLevelService.deletePresellLevel(request)).thenReturn(1);
		var rs = presellLevelController.deletePresellLevel(request, user);
		assertEquals(1, rs.getBody());
	}
	
	@Test
	void deletePresellLevelError() {
		when(presellLevelService.deletePresellLevel(null)).thenThrow(EntityNotFoundException.class);
		assertThrows(Exception.class, () -> presellLevelController.deletePresellLevel(null, user));
	}
	
	@Test
	void insertOrUpdatePresellLevelSuccess() {
		PresellLevelRequestDTO request = buildRequestDTO();
		when(presellLevelService.insertOrUpdatePresellLevel(request)).thenReturn(1);
		var rs = presellLevelController.insertOrUpdatePresellLevel(request, user);
		assertEquals(1, rs.getBody());
	}
	
	@Test
	void insertOrUpdatePresellLevelError() {
		when(presellLevelService.insertOrUpdatePresellLevel(null)).thenThrow(EntityNotFoundException.class);
		assertThrows(Exception.class, () -> presellLevelController.insertOrUpdatePresellLevel(null, user));
	}
	
	private PresellLevelRequestDTO buildRequestDTO() {
		PresellLevelRequestDTO request = new PresellLevelRequestDTO();
		List<PresellLevelDTO> listPresellLvl = new ArrayList<>();
		listPresellLvl.add(new PresellLevelDTO("A", 1, DatetimeUtils.getUTCTimestamp()));
		request.setUserId("rparo");
		request.setPresellLevelDTOs(listPresellLvl);
		return request;
	}
}
