package com.delhaize.presell.service;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.service.impl.StatusServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StatusServiceImplTest {

    @InjectMocks
    StatusServiceImpl statusServiceImpl;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getStatusForPresell() {
        var rs = statusServiceImpl.getStatusForPresell();
        assertEquals(6, rs.size());
    }

    @Test
    public void getStatusForStoreOrder() {
        var rs = statusServiceImpl.getStatusForStoreOrder(Secured.UserRole.ADMIN);
        assertEquals(5, rs.size());
    }

    @Test
    public void getStatusForPresellReport() {
        var rs = statusServiceImpl.getStatusForPresellReport();
        assertEquals(4, rs.size());

    }
}
