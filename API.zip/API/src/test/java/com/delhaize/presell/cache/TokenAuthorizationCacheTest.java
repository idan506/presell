package com.delhaize.presell.cache;


import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.Instant;

public class TokenAuthorizationCacheTest {

    private String token = "Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6IlNGS0VkRXczS2ItbE90WEw2QW1pZnVCVUUtTWlVaWJBRW1SeFFhWWd1eEkiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8zODNhMjFmYS01YmQwLTRjODYtOWQzOC1iM2Y1MDJjODdlMTUvIiwiaWF0IjoxNjI5ODkyNjQ5LCJuYmYiOjE2Mjk4OTI2NDksImV4cCI6MTYyOTg5NjU0OSwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iXSwiYWlvIjoiQVNRQTIvOFRBQUFBcGFQcVd5c1NNdG5ndVp2ejd3UDY4YmNoRWNMKzFlSUpTc0dmdVplR1Jjdz0iLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IlNhbGVzYnJlYWtkb3duIFdlYiAtIERFViIsImFwcGlkIjoiMGFmZmZmOGMtMjM2Mi00ODYzLTg0ZjAtYzBjZDllMGVmZGZmIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJGb3JiZXMiLCJnaXZlbl9uYW1lIjoiTWFlIiwiaWR0eXAiOiJ1c2VyIiwiaW5fY29ycCI6InRydWUiLCJpcGFkZHIiOiIxOTguMTkwLjI1LjQiLCJuYW1lIjoiTWFlIEZvcmJlcyIsIm9pZCI6ImJmNWMyNTlmLTk3OTQtNDNmNi04M2MwLWY2YzhiMDY2OTNhMSIsIm9ucHJlbV9zaWQiOiJTLTEtNS0yMS0xMjQ2OTA5MDItNzAxMzMxOTIzLTE5MjU3MzY3OTEtMTgxMTc1IiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAwN0EwQzA5RjkiLCJyaCI6IjAuQVRFQS1pRTZPTkJiaGt5ZE9MUDFBc2gtRll6X193cGlJMk5JaFBEQXpaNE9fZjh4QUtNLiIsInNjcCI6IlVzZXIuUmVhZCBwcm9maWxlIG9wZW5pZCBlbWFpbCIsInNpZ25pbl9zdGF0ZSI6WyJpbmtub3dubnR3ayJdLCJzdWIiOiJzVmxQVFVZM0hBQW5WdUNvUDFXY3drUVdHcHJ3UFhOYUZjUDdjdGVtS1ZjIiwidGVuYW50X3JlZ2lvbl9zY29wZSI6IkVVIiwidGlkIjoiMzgzYTIxZmEtNWJkMC00Yzg2LTlkMzgtYjNmNTAyYzg3ZTE1IiwidW5pcXVlX25hbWUiOiIxMDU5ODM0QGRlbGhhaXpldC5jb20iLCJ1cG4iOiIxMDU5ODM0QGRlbGhhaXpldC5jb20iLCJ1dGkiOiJmcHJUWTIwaUpVT3ZpYkxVQUxpakFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXSwieG1zX3N0Ijp7InN1YiI6IngtU3F5LXphQTVDNFFDakt1MFdKQ3JnZVppVWJDdVhLbktkVEpSNVlvM0EifSwieG1zX3RjZHQiOjE1MDgzNDAzMzd9.E-K5hs4cL1CW4NDvr3GV_YrpXqoH8R5dGONzwuY9hpwJtNicbWq_qk4kmhx0TVUFZTcEpIRUe_-7rMwcO0fF7i7CNT5PNiQWWqNNZvPsjerXzrMt4WOYXFzdiu_SGAd3D-VyocKUg_4H0PbXvk9Zp8tz_hyJjV2PR094UwW1Q17-gHEd0oxYqNIanMApGuQGGInn3Hx95htXbq7jnK381HhUuBKiXwVJxS66HllsTRrhZjJYokXTJTK0N8FuAzlYcYIacZN-nVFwQ2W68Teq6atv5RooTTgcYdmqiycGwQqFJ8JZupyNBWe01K1BPQJ9usi4CK-LsY1vHTVj3jyCVQ";

    @InjectMocks
    TokenAuthorizationCache tokenAuthorizationCache;

    @Mock
    RedisTemplate<String, Object> redisTemplate;


    @Mock
    ValueOperations<String, Object> valueOperations;



    @BeforeEach
    public void start() throws IllegalAccessException {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testStoreToken() {

    	UserSSOInfo validationCacheDTO = new UserSSOInfo();
        validationCacheDTO.setTokenExpiryTime(Instant.now().toEpochMilli() - (1000 * 60));

        Mockito.when(redisTemplate.opsForValue()).thenReturn(valueOperations);

        Assertions.assertDoesNotThrow(() -> tokenAuthorizationCache.setTokenDataSet(token, validationCacheDTO));
    }

    @Test
    public void testStoreTokenFail() {

        UserSSOInfo validationCacheDTO = new UserSSOInfo();
        validationCacheDTO.setTokenExpiryTime(Instant.now().toEpochMilli() - (1000 * 100));
        Mockito.when(redisTemplate.opsForValue()).thenThrow(RuntimeException.class);

        Assertions.assertDoesNotThrow(() -> tokenAuthorizationCache.setTokenDataSet(token, validationCacheDTO));
    }

    @Test
    public void testFetchToken() {
        Mockito.when(redisTemplate.opsForValue()).thenReturn(valueOperations);

        Assertions.assertDoesNotThrow(() -> tokenAuthorizationCache.getTokenDataSet(token));
    }

    @Test
    public void testFetchTokenFail() {
        Mockito.when(redisTemplate.opsForValue()).thenThrow(RuntimeException.class);

        Assertions.assertNull(tokenAuthorizationCache.getTokenDataSet(token));
    }
}
