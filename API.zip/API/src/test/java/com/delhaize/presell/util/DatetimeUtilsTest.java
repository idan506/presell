package com.delhaize.presell.util;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DatetimeUtilsTest {
	@InjectMocks
	DatetimeUtils datetimeUtils;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void getUTCTimestamp() {
		var rs = DatetimeUtils.getUTCTimestamp();
		assertNotNull(rs);
	}
	
	@Test
	void getCurrentSQLDate() {
		var rs = DatetimeUtils.getCurrentSQLDate();
		assertNotNull(rs);
	}
	
	@Test
	void dayBetween() {
		Date presellDueDate = new Date();
		Date currentDate = new Date();
		var rs = DatetimeUtils.dayBetween(presellDueDate, currentDate);
		assertNotNull(rs);
	}
}
