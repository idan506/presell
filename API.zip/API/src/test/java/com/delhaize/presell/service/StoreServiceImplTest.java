package com.delhaize.presell.service;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.dto.PresellDetailDTO;
import com.delhaize.presell.dto.StoreDTO;
import com.delhaize.presell.dto.StoresDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import com.delhaize.presell.entity.PresellStore;
import com.delhaize.presell.entity.PresellStorePK;
import com.delhaize.presell.repository.PresellStoreRepository;
import com.delhaize.presell.repository.dao.PresellLevelMappingDAO;
import com.delhaize.presell.repository.dao.StoreDAO;
import com.delhaize.presell.repository.template.StoreBatchJDBCTemplate;
import com.delhaize.presell.service.impl.StoreServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class StoreServiceImplTest {

    @InjectMocks
    StoreServiceImpl storeServiceImpl;

    @Mock
    StoreDAO storeDAO;
    @Mock
    PresellLevelMappingDAO presellLevelMappingDAO;
    @Mock
    PresellStoreRepository presellStoreRepository;

    @Mock
    BuMstrService buMstrService;

    @Mock
    StoreBatchJDBCTemplate storeBatchJDBCTemplate;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }


   // @Test
    public void searchStore() {

        StoreSearchCriteria criteria = new StoreSearchCriteria() {
            @Override
            public String getStrStoreNo() {
                return "1234";
            }

            @Override
            public String getStrBusinessUnit() {
                return "";
            }

            @Override
            public String[] getStrDivision() {
                return super.getStrDivision();
            }

            @Override
            public String[] getStrDistrict() {
                return super.getStrDistrict();
            }

            @Override
            public String[] getStrStoreLoc() {
                return super.getStrStoreLoc();
            }

            @Override
            public String getStrStoreNosAlreadyAdded() {
                return super.getStrStoreNosAlreadyAdded();
            }

        };
        List<StoresDTO> listStoresDTO = new ArrayList<StoresDTO>();
        var data = new StoresDTO() {
            @Override
            public void setStoreNbr(Integer storeNbr) {
                super.setStoreNbr(storeNbr);
            }

            @Override
            public void setStoreNam(String storeNam) {
                super.setStoreNam(storeNam);
            }

            @Override
            public void setGeoRegnCd(String geoRegnCd) {
                super.setGeoRegnCd(geoRegnCd);
            }

            @Override
            public void setLocSidNbr(Integer locSidNbr) {
                super.setLocSidNbr(locSidNbr);
            }

            @Override
            public void setDivDsc(String divDsc) {
                super.setDivDsc(divDsc);
            }

            @Override
            public void setDstrcDsc(String dstrcDsc) {
                super.setDstrcDsc(dstrcDsc);
            }

            @Override
            public void setSchdArrvDt(Date schdArrvDt) {
                super.setSchdArrvDt(schdArrvDt);
            }
        };
        listStoresDTO.add(data);
        Mockito.when(storeDAO.searchStore(criteria)).thenReturn(listStoresDTO);
        var rs = storeServiceImpl.searchStore(criteria);
        assertNotNull(rs);

    }

    @Test
    public void getStoreNumberList() {

        StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria() {
            @Override
            public String getStoreNo() {
                return super.getStoreNo();
            }

            @Override
            public String getStoreType() {
                return super.getStoreType();
            }
        };
        List<Integer> listStoreNo = new ArrayList<>();
        listStoreNo.add(111);
        listStoreNo.add(112);
        listStoreNo.add(113);
        listStoreNo.add(114);
        Mockito.when(presellLevelMappingDAO.getPresellLevelStoreList(criteria)).thenReturn(listStoreNo);
        var rs = storeServiceImpl.getStoreNumberList(criteria);
        assertEquals(4, rs.size());
    }

    @Test
    public void saveNewStoresToPresell() {
        List<StoreDTO> store = new ArrayList<>();
        store.add(new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1234);
        presell.setStoreDTOList(store);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("12345");
        var storeEntity = new PresellStore();
        var pk = new PresellStorePK();
        pk.setStoreNbr(8980);
        pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        storeEntity.setStorePk(pk);
        storeEntity.setStoreStatCd("SEND_TO_STORES");
        storeEntity.setAddUserId(request.getUserId());
        storeEntity.setModUserId(request.getUserId());
        Mockito.when(presellStoreRepository.save(storeEntity)).thenReturn(storeEntity);
        mockStoreBatchJDBCMethod();
        var rs = storeServiceImpl.saveNewStoresToPresell(request);
        assertNotNull(rs);
    }

    @Test
    public void insertOrDeleteStore() {
        String status = "";
        List<StoreDTO> store = new ArrayList<>();
        store.add(new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1234);
        presell.setStoreDTOList(store);
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("12345");
        request.setAction(SavePresellAction.CREATE_AUTO_ORDER);
        var pk = new PresellStorePK();
        pk.setStoreNbr(store.get(0).getStoreNbr());
        pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        mockStoreBatchJDBCMethod();
        var rs = storeServiceImpl.insertOrDeleteStore(request);
        assertEquals(1, rs);
    }

    @Test
    public void insertOrDeleteStore1() {
        String status = "";
        List<StoreDTO> store = new ArrayList<>();
        store.add(new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.OLD));
        PresellDetailDTO presell = new PresellDetailDTO();
        presell.setPsellIdNbr(1234);
        presell.setStoreDTOList(store);
        presell.setPsellStatCd(Status.SEND_TO_STORES);
        PresellSaveRequestDTO request = new PresellSaveRequestDTO();
        request.setPresellDetail(presell);
        request.setUserId("12345");
        request.setAction(SavePresellAction.SAVE_AS_DRAFT);
        var pk = new PresellStorePK();
        pk.setStoreNbr(store.get(0).getStoreNbr());
        pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        PresellStore presellOpt = new PresellStore();
        presellOpt.setStoreStatCd(status);
        Optional<PresellStore> entity = Optional.of(presellOpt);
        Mockito.when(presellStoreRepository.findById(Mockito.any())).thenReturn(entity);
        // entity.setStoreStatCd(status);
        mockStoreBatchJDBCMethod();
        var rs = storeServiceImpl.insertOrDeleteStore(request);
        assertEquals(1, rs);
    }

    @Test
    public void getStoreTypeList() {
        List<BusUnitDTO> data = new ArrayList<>();
        data.add(new BusUnitDTO("test", "test"));
        Mockito.when(buMstrService.getBusUnit()).thenReturn(data);

        var rs = storeServiceImpl.getStoreTypeList();

        assertEquals(2, rs.size());

    }

    private void mockStoreBatchJDBCMethod() {
        Mockito.doNothing().when(storeBatchJDBCTemplate).batchInsert(Mockito.anyList());
        Mockito.doNothing().when(storeBatchJDBCTemplate).batchUpdate(Mockito.anyList());
        Mockito.doNothing().when(storeBatchJDBCTemplate).batchDelete(Mockito.anyList());
    }
}
