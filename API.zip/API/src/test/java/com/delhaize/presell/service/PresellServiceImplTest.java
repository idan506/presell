package com.delhaize.presell.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.delhaize.presell.dto.*;
import com.delhaize.presell.repository.*;
import com.delhaize.presell.repository.template.ItemBatchJDBCTemplate;
import com.delhaize.presell.repository.template.StoreBatchJDBCTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.PresellProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import com.delhaize.presell.entity.Presell;
import com.delhaize.presell.repository.dao.PresellDAO;
import com.delhaize.presell.service.impl.PresellServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class PresellServiceImplTest {
	@InjectMocks
	PresellServiceImpl presellServiceImpl;

	@Mock
	PresellDAO presellDAO;

	@Mock
	ItmsoqmapRepository itmsoqmapRepository;

	@Mock
	StorItemsRepository storItemsRepository;

	@Mock
	ItemsRepository itemsRepository;

	@Mock
	PresellStoreRepository presellStoreRepository;

	@Mock
	PreselLogRepository preselLogRepository;

	@Mock
	PresellRepository presellRepository;

	@Mock
	LvlMapngRepository lvlMapngRepository;

	@Mock
	StoreService storeService;

	@Mock
	ItemService itemService;

	@Mock
	LvlClassRepository lvlClassRepository;

	@Mock
	LvlMaintRepository lvlMaintRepository;

	@Mock
	BuMstrRepository buMstrRepository;

	@Mock
	StoreBatchJDBCTemplate storeBatchJDBCTemplate;

	@Mock
	ItemBatchJDBCTemplate itemBatchJDBCTemplate;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void searchPresell() {

		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = new PresellSearchCriteria();
		Page<PresellDTO> pagePresell = null;
		when(presellDAO.searchPresell(criteria, pageable)).thenReturn(pagePresell);
		var rs = presellServiceImpl.searchPresell(criteria, paginationAndSortDTO);
		assertTrue(true);
	}

	@Test
	public void downloadPresellToXLS() {
		PresellSearchCriteria criteria = new PresellSearchCriteria();
		criteria.setStatus(Status.SEND_TO_STORES);
		String fileName = String.format("Presell_List_%o.xls", System.currentTimeMillis());

		List<PresellDTO> listDto = new ArrayList<>();
		listDto.add(new PresellDTO(1, "A", "A", "A", "A", DatetimeUtils.getCurrentSQLDate(), "A", "A", false));
		Page<PresellDTO> pagePresell = new PageImpl<>(listDto);
//		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
//		paginationAndSortDTO.setPage(1);
//		paginationAndSortDTO.setSize(10);
//		paginationAndSortDTO.setSortBy("A");
//		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
//		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
//				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
//						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		when(presellDAO.searchPresell(criteria, null)).thenReturn(pagePresell);
		
		var rs = presellServiceImpl.downloadPresellToXLS(criteria, fileName);
		assertNotNull(rs);

	}

	@Test
	public void getUserIds() {
		List<String> list = new ArrayList<>();
		list.add("A");
		list.add("AA");
		list.add("AAA");
		when(presellRepository.getUserIDs()).thenReturn(list);
		var rs = presellServiceImpl.getUserIds();
		assertEquals(3, rs.size());
	}

	@Test
	public void deletePresellList() {
		List<Integer> presellList = new ArrayList<>();
		presellList.add(1);
		presellList.add(2);
		presellList.add(3);

		var rs = presellServiceImpl.deletePresellList(presellList);
		assertNotNull(rs);

	}

	@Test
	public void savePresellActionClose() {
		PresellSaveRequestDTO requestActionClose = buildRequestDTO(SavePresellAction.CLOSED);
		updatePresellAndStoreStatus(requestActionClose);

		var rs = presellServiceImpl.savePresell(requestActionClose);
		assertNotNull(rs);
	}

	@Test
	public void savePresellActionCreateAutoOrder() {
		PresellSaveRequestDTO requestActionClose = buildRequestDTO(SavePresellAction.CREATE_AUTO_ORDER);
		requestActionClose.getPresellDetail().setPsellStatCd(Status.SEND_TO_STORES);
		updatePresellAndStoreStatus(requestActionClose);
		List< ItemSOQDTO> itemSOQ = new ArrayList<>();
		ItemSOQDTO item = new ItemSOQDTO();
		item.setClassificationId(1);
		item.setClassificationDsc("A");
		item.setQuantity(new BigDecimal(1));
		itemSOQ.add( item);
		List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
		lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
				"1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.UPDATE, DBStatus.NEW,
				"1", "1", "1", "1", "1"));
		requestActionClose.getPresellDetail().setItemDTOList(lisAddItemsDTOs);
		doNothing().when(storeBatchJDBCTemplate).batchUpdate(anyList());
		var rs = presellServiceImpl.savePresell(requestActionClose);
		assertNotNull(rs);
	}

	@Test
	public void savePresellActionSaveDrf() {
		PresellSaveRequestDTO requestActionSaveDrf = buildRequestDTO(SavePresellAction.SAVE_AS_DRAFT);
		savePresellAction(requestActionSaveDrf);
		var rs = presellServiceImpl.savePresell(requestActionSaveDrf);
		assertNotNull(rs);
	}

	@Test
	public void savePresellActionSTS() {
		PresellSaveRequestDTO requestActionSTS = buildRequestDTO(SavePresellAction.SEND_TO_STORES);
		sendPresellToStores(requestActionSTS);
		var rs = presellServiceImpl.savePresell(requestActionSTS);
		assertNotNull(rs);
	}

	@Test
	public void sendToAdditionalStores() {
		PresellSaveRequestDTO request = buildRequestDTO(SavePresellAction.SEND_TO_STORES);
		int i = 1;
		when(storeService.saveNewStoresToPresell(request)).thenReturn(i);

		Presell presell = new Presell(null, null, null, null, null, null, null, null, null, null, null, null, null);
		Optional<Presell> data = Optional.of(presell);
		when(presellRepository.findById(request.getPresellDetail().getPsellIdNbr())).thenReturn(data);
		when(presellRepository.save(presell)).thenReturn(presell);

		var rs = presellServiceImpl.sendToAdditionalStores(request);
		assertNotNull(rs);
	}

	@Test
	public void sendToAdditionalStoresAuto() {
		PresellSaveRequestDTO request = buildRequestDTO(SavePresellAction.CREATE_AUTO_ORDER);
		request.getPresellDetail().setPsellStatCd(Status.REC_FROM_STORES);
		int i = 1;
		when(storeService.saveNewStoresToPresell(request)).thenReturn(i);

		List< ItemSOQDTO> itemSOQ = new ArrayList<>();
		ItemSOQDTO item = new ItemSOQDTO();
		item.setClassificationId(1);
		item.setClassificationDsc("A");
		item.setQuantity(new BigDecimal(1));
		itemSOQ.add( item);
		List<AddItemsDTO> lisAddItemsDTOs = new ArrayList<>();
		lisAddItemsDTOs.add(new AddItemsDTO("1", DatetimeUtils.getCurrentSQLDate(), DatetimeUtils.getCurrentSQLDate(),
				"1", "1", "1", "1", "1", "1", "1", "1", itemSOQ, "1", "1", "1", "1", "1", DBAction.UPDATE, DBStatus.NEW,
				"1", "1", "1", "1", "1"));
		request.getPresellDetail().setItemDTOList(lisAddItemsDTOs);
		Presell presell = new Presell(1, 1, "A", "A", DatetimeUtils.getCurrentSQLDate(), "A",
				DatetimeUtils.getCurrentSQLDate(), "A", "A", "A", DatetimeUtils.getUTCTimestamp(), "A",
				DatetimeUtils.getUTCTimestamp());
		Optional<Presell> data = Optional.of(presell);
		when(presellRepository.findById(request.getPresellDetail().getPsellIdNbr())).thenReturn(data);
		when(presellRepository.save(presell)).thenReturn(presell);
		doNothing().when(itemBatchJDBCTemplate).batchInsert(anyList());

		var rs = presellServiceImpl.savePresell(request);
		assertNotNull(rs);
	}

	@Test
	public void getPresellDetails() {
		int presellID = 1;
		PresellProjection presellData = new PresellProjection() {

			@Override
			public Integer getpsellLvlIdNbr() {
				return 1;
			}

			@Override
			public Date getRmndrEmailDt() {
				return DatetimeUtils.getCurrentSQLDate();
			}

			@Override
			public String getPsellStatCd() {
				return "REC";
			}

			@Override
			public Integer getPsellIdNbr() {
				return 1;
			}

			@Override
			public Date getPsellDueDt() {
				return DatetimeUtils.getCurrentSQLDate();
			}

			@Override
			public String getPsellDsc() {
				return "A";
			}

			@Override
			public String getPsellCmtTxt() {
				return "A";
			}

			@Override
			public String getPlnDistFlg() {
				return "A";
			}

			@Override
			public String getModUserId() {
				return "A";
			}

			@Override
			public Timestamp getModTs() {
				return DatetimeUtils.getUTCTimestamp();
			}

			@Override
			public String getBusUnitId() {
				return "A";
			}

			@Override
			public String getAddUserId() {
				return "A";
			}

			@Override
			public Timestamp getAddTs() {
				return DatetimeUtils.getUTCTimestamp();
			}
		};

		when(presellRepository.getPresellData(presellID)).thenReturn(presellData);

		List<ItemProjection> ilist = new ArrayList<>();
		ilist.add(new ItemProjection() {

			@Override
			public BigDecimal getSuggOrderQty() {
				return new BigDecimal(1);
			}

			@Override
			public java.sql.Date getShipDt() {
				return DatetimeUtils.getCurrentSQLDate();
			}

			@Override
			public BigDecimal getRtlPrc() {
				return new BigDecimal(1);
			}

			@Override
			public String getPsellLvlClsCd() {
				return "A";
			}

			@Override
			public String getPsellItemCmtTxt() {
				return "A";
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return new BigDecimal(1);
			}

			@Override
			public Integer getPsellClsIdNbr() {
				return 1;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return new BigDecimal(1);
			}

			@Override
			public String getItemSzCd() {
				return "A";
			}

			@Override
			public Integer getItemPkQty() {
				return 1;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return new BigDecimal(1);
			}

			@Override
			public BigDecimal getItemNbr() {
				return new BigDecimal(1);
			}

			@Override
			public String getItemImgUrl() {
				return "A";
			}

			@Override
			public String getItemDsc() {
				return "A";
			}

			@Override
			public BigDecimal getItemCapCst() {
				return new BigDecimal(1);
			}
		});
		String busUnit="";
		when(itemsRepository.getItemList(presellID)).thenReturn(ilist);
		when(buMstrRepository.getbusUnitDsc("")).thenReturn(busUnit);
		var rs = presellServiceImpl.getPresellDetails(presellID);

		assertNotNull(rs);
	}

	@Test
	public void downloadItemList() {
		int psellIdNbr = 1;
		String fileName = String.format("Presell_Item_%o.xls", System.currentTimeMillis());
		List<ClassificationDTO> classification = new ArrayList<>();
		var d1 = new ClassificationDTO(1, "A");
		classification.add(d1);

		when(lvlClassRepository.getClassifications()).thenReturn(classification);
		when(lvlMaintRepository.getPresellLevelDscForId(anyInt())).thenReturn("presell dsc");
		getPresellDetails();
		var rs = presellServiceImpl.downloadItemList(psellIdNbr, fileName);
		assertNotNull(rs);
	}

	private PresellSaveRequestDTO buildRequestDTO(SavePresellAction action) {
		PresellSaveRequestDTO request = new PresellSaveRequestDTO();
		PresellDetailDTO presell = new PresellDetailDTO();
		List<StoreDTO> store = new ArrayList<>();
		store.add(new StoreDTO(1, "A", "A", 1, "A", "A", DatetimeUtils.getCurrentSQLDate(), DBAction.UPDATE,
				DBStatus.OLD));
		List<AddItemsDTO> items = new ArrayList<>();
		var item = new AddItemsDTO();
		item.setShippingDate(DatetimeUtils.getCurrentSQLDate());
		item.setItemNbr("1");
		item.setStatus(DBStatus.OLD);
		item.setAction(DBAction.INACTION);
		item.setItemSOQ(new ArrayList<>());
		items.add(item);
		presell.setPsellIdNbr(1);
		presell.setPsellDsc("A");
		presell.setBusUnitId("A");
		presell.setPsellLvlIdNbr(1);
		presell.setAddUserId("rparo");
		presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
		presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
		presell.setPlnDistFlg("Y");
		presell.setPsellStatCd(Status.REC_FROM_STORES);
		presell.setPsellCmtTxt("A");
		presell.setStoreDTOList(store);
		presell.setItemDTOList(items);
		presell.setItemNotFoundList(null);
		presell.setLogs(null);
		presell.setItemCount(0);
		presell.setStoreCount(0);
		presell.setItemList(null);
		presell.setHmStoresForAdd(null);

		request.setUserId("rparo");
		request.setAction(action);
		request.setPresellDetail(presell);

		return request;
	}

	private void updatePresellAndStoreStatus(PresellSaveRequestDTO request) {
		Presell presell = new Presell(null, null, null, null, null, null, null, null, null, null, null, null, null);
		Optional<Presell> data = Optional.of(presell);
		when(presellRepository.findById(request.getPresellDetail().getPsellIdNbr())).thenReturn(data);
	}

	private void savePresellAction(PresellSaveRequestDTO request) {
		Presell presell = new Presell(1, null, null, null, null, null, null, null, null, null, null, null, null);
		Optional<Presell> data = Optional.of(presell);
		when(presellRepository.findById(request.getPresellDetail().getPsellIdNbr())).thenReturn(data);
		when(presellRepository.save(presell)).thenReturn(presell);
	}

	private void sendPresellToStores(PresellSaveRequestDTO request) {
		int i = 1;
		when(presellRepository.updateStatus(Status.SEND_TO_STORES.getKey(), request.getUserId(),
				DatetimeUtils.getUTCTimestamp(), request.getPresellDetail().getPsellIdNbr())).thenReturn(i);
	}

}
