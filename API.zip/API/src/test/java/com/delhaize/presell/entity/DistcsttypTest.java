package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DistcsttypTest {

   @InjectMocks
   Distcsttyp distcsttyp;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       distcsttyp.setDistCstTypCd("TEST");
       assertNotNull(distcsttyp.getDistCstTypCd());
       distcsttyp.setDistCstTypDsc("TEST");
       assertNotNull(distcsttyp.getDistCstTypDsc());
       distcsttyp.setDistCstRateCd("TEST");
       assertNotNull(distcsttyp.getDistCstRateCd());
       distcsttyp.setDistCstUomCd("TEST");
       assertNotNull(distcsttyp.getDistCstUomCd());
       distcsttyp.setCstByDcFlg("TEST");
       assertNotNull(distcsttyp.getCstByDcFlg());
       distcsttyp.setCstByMdeptFlg("TEST");
       assertNotNull(distcsttyp.getCstByMdeptFlg());
       distcsttyp.setCstBySelwhFlg("TEST");
       assertNotNull(distcsttyp.getCstBySelwhFlg());
       distcsttyp.setCstByCatgFlg("TEST");
       assertNotNull(distcsttyp.getCstByCatgFlg());
       distcsttyp.setCstByStoreFlg("TEST");
       assertNotNull(distcsttyp.getCstByStoreFlg());
       distcsttyp.setCstByItemFlg("TEST");
       assertNotNull(distcsttyp.getCstByItemFlg());
       distcsttyp.setCstGrpCd("TEST");
       assertNotNull(distcsttyp.getCstGrpCd());
       distcsttyp.setModUserId("TEST");
       assertNotNull(distcsttyp.getModUserId());
       distcsttyp.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(distcsttyp.getModTs());
       distcsttyp.setModPgmId("TEST");
       assertNotNull(distcsttyp.getModPgmId());

       assertNotEquals(distcsttyp, new Distcsttyp());
       System.out.println(distcsttyp.hashCode());
       System.out.println(distcsttyp.toString());
   }
}
