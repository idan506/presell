package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DuCntrPKTest {

   @InjectMocks
   DuCntrPK duCntrPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       duCntrPk.setItemSetNbr(1);
       assertNotNull(duCntrPk.getItemSetNbr());
       duCntrPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(duCntrPk.getItemNbr());
       duCntrPk.setDistItemSeqNbr(1);
       assertNotNull(duCntrPk.getDistItemSeqNbr());
       duCntrPk.setCntrTypCd("TEST");
       assertNotNull(duCntrPk.getCntrTypCd());
   }
}
