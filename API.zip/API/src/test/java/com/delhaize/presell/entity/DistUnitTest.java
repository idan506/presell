package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DistUnitTest {

   @InjectMocks
   DistUnit distUnit;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       distUnit.setDistUnitPk(new DistUnitPK());
       assertNotNull(distUnit.getDistUnitPk());
       distUnit.setOrderGuidCd("TEST");
       assertNotNull(distUnit.getOrderGuidCd());
       distUnit.setCutTmDur(new java.math.BigDecimal(1));
       assertNotNull(distUnit.getCutTmDur());
       distUnit.setWrapTmDur(new java.math.BigDecimal(1));
       assertNotNull(distUnit.getWrapTmDur());
       distUnit.setStkTmDur(new java.math.BigDecimal(1));
       assertNotNull(distUnit.getStkTmDur());
       distUnit.setPrdtLnId("TEST");
       assertNotNull(distUnit.getPrdtLnId());
       distUnit.setCstMthdCd("TEST");
       assertNotNull(distUnit.getCstMthdCd());
       distUnit.setCstUomCd("TEST");
       assertNotNull(distUnit.getCstUomCd());
       distUnit.setMgmtPlnGrpId("TEST");
       assertNotNull(distUnit.getMgmtPlnGrpId());
       distUnit.setOrderSumSeqNbr(1);
       assertNotNull(distUnit.getOrderSumSeqNbr());
       distUnit.setItemSnlCd("TEST");
       assertNotNull(distUnit.getItemSnlCd());
       distUnit.setMdseClsCd("TEST");
       assertNotNull(distUnit.getMdseClsCd());
       distUnit.setItemRtnCd("TEST");
       assertNotNull(distUnit.getItemRtnCd());
       distUnit.setCmpstTypCd("TEST");
       assertNotNull(distUnit.getCmpstTypCd());
       distUnit.setMinRtlDaysCnt(1);
       assertNotNull(distUnit.getMinRtlDaysCnt());
       distUnit.setRcvOnWgtCd("TEST");
       assertNotNull(distUnit.getRcvOnWgtCd());
       distUnit.setItemPkQty(1);
       assertNotNull(distUnit.getItemPkQty());
       distUnit.setModUserId("TEST");
       assertNotNull(distUnit.getModUserId());
       distUnit.setModPgmId("TEST");
       assertNotNull(distUnit.getModPgmId());
       distUnit.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(distUnit.getModTs());

       assertNotEquals(distUnit, new DistUnit());
       System.out.println(distUnit.hashCode());
       System.out.println(distUnit.toString());
   }
}
