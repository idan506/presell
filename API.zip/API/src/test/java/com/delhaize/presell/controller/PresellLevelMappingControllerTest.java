package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.InputStreamResource;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.dto.LevelDTO;
import com.delhaize.presell.dto.StorePresellLevelDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.service.PresellLevelMappingService;
import com.delhaize.web.exception.EntityNotFoundException;

public class PresellLevelMappingControllerTest {
	@InjectMocks
	PresellLevelMappingController presellLevelMappingController;
	
	@Mock
	PresellLevelMappingService presellLevelMappingService;

	private UserSSOInfo user;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
		user = new UserSSOInfo();
		user.setUserId("userId");
		user.setRole(Secured.UserRole.ADMIN);
		user.setStoreNbr(1234);
	}
	
	private StorePresellLevelDTO buildCriteria() {
		StorePresellLevelDTO criteria = new StorePresellLevelDTO();
		criteria.setUserId("rparo");

		List<LevelDTO> levelDTOs = new ArrayList<LevelDTO>();
		levelDTOs.add(new LevelDTO(1, 0, 1, DBAction.DELETE));
		levelDTOs.add(new LevelDTO(1, 0, 2, DBAction.INSERT));
		levelDTOs.add(new LevelDTO(1, 0, 3, DBAction.UPDATE));
		criteria.setPresellLevel(levelDTOs);
		return criteria;
	}
	
	@Test
	void searchStoreOrder() {
		StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria();
		when(presellLevelMappingService.searchStorePresellLevelMapping(criteria)).thenReturn(anyList());
		var rs = presellLevelMappingController.searchStorePresellLevelMapping(criteria);
		assertNotNull(rs);
	}
	
	@Test
	void downloadStorePresellLevelMapping() {
    	ByteArrayInputStream anyByteArr = new ByteArrayInputStream("test".getBytes());
    	when(presellLevelMappingService.downloadStorePresellLevelMapping(anyString())).thenReturn(anyByteArr);
    	var rs = presellLevelMappingController.downloadStorePresellLevelMapping();
    	assertEquals(new InputStreamResource(anyByteArr), rs.getBody());
	}
	
	@Test
	void saveStorePresellLevelMapingSuccess() {
		StorePresellLevelDTO criteria = buildCriteria();
		when(presellLevelMappingService.saveStorePresellLevelMaping(criteria)).thenReturn(1);
		var rs = presellLevelMappingController.saveStorePresellLevelMaping(criteria, user);
		assertNotNull(rs);
	}
	
	@Test
	void saveStorePresellLevelMapingError() {
		when(presellLevelMappingService.saveStorePresellLevelMaping(null)).thenThrow(EntityNotFoundException.class);
		assertThrows(Exception.class, () -> presellLevelMappingController.saveStorePresellLevelMaping(null, user));
	}
	
}
