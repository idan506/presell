package com.delhaize.presell.repository.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.PresellDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import com.delhaize.presell.util.DatetimeUtils;

public class PresellDAOImplTest {
	@InjectMocks
	PresellDAOImpl presellDAOImpl;

	@Mock
	EntityManager entityManager;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void searchPresellSuccessWithStatusDrf() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = buildCriteria(Status.SAVED_AS_DRAFT);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(new Long("10"));
		var rs = presellDAOImpl.searchPresell(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchPresellSuccessWithStatusSTS() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = buildCriteria(Status.SEND_TO_STORES);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(new Long("10"));
		var rs = presellDAOImpl.searchPresell(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchPresellSuccessWithStatusREC() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = buildCriteria(Status.REC_FROM_STORES);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(new Long("10"));
		var rs = presellDAOImpl.searchPresell(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchPresellSuccessWithStatusCLS() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = buildCriteria(Status.CLOSED);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(new Long("10"));
		var rs = presellDAOImpl.searchPresell(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchPresellSuccessWithStatusExCLS() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = buildCriteria(Status.ALL_EXCLUDING_CLOSED);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(new Long("10"));
		var rs = presellDAOImpl.searchPresell(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchPresellWithStatusNotAvailable() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		PresellSearchCriteria criteria = buildCriteria(Status.PENDING);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(new Long("10"));

		assertThrows(Exception.class, () -> presellDAOImpl.searchPresell(criteria, pageable));
	}

	@Test
	void searchPresellWithNullPageable() {
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setSortBy("A");
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);

		PresellSearchCriteria criteria = buildCriteria(Status.REC_FROM_STORES);

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		List<PresellDTO> result = new ArrayList<>();
		result.add(new PresellDTO(1, "A", "A", "A", "STS", DatetimeUtils.getCurrentSQLDate(), "A", "N", false));
		when(query.getResultList()).thenReturn(result);
		when(query.getSingleResult()).thenReturn(new Long("10"));
		var rs = presellDAOImpl.searchPresell(criteria, null);
		assertNotNull(rs);
	}

	@Test
	void searchPresellErrorTotalElement() {
		PresellSearchCriteria criteria = buildCriteria(Status.REC_FROM_STORES);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		when(query.getSingleResult()).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> presellDAOImpl.searchPresell(criteria, pageable));
	}

	private PresellSearchCriteria buildCriteria(Status status) {
		PresellSearchCriteria criteria = new PresellSearchCriteria();
		criteria.setPresellTitle("A");
		criteria.setPresellLevelId(1);
		criteria.setStatus(status);
		criteria.setPresellAuthor("A");
		criteria.setFromDueDate(DatetimeUtils.getCurrentSQLDate());
		criteria.setToDueDate(DatetimeUtils.getCurrentSQLDate());
		criteria.setPlannedDis("Y");
		criteria.setBusinessUnit("A");
		return criteria;
	}
}
