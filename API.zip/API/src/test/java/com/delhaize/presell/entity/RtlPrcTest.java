package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class RtlPrcTest {

   @InjectMocks
   RtlPrc rtlPrc;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       rtlPrc.setPrcSidNbr(1);
       assertNotNull(rtlPrc.getPrcSidNbr());
       rtlPrc.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(rtlPrc.getItemNbr());
       rtlPrc.setItemSetNbr(1);
       assertNotNull(rtlPrc.getItemSetNbr());
       rtlPrc.setPrcCmpntTypCd("TEST");
       assertNotNull(rtlPrc.getPrcCmpntTypCd());
       rtlPrc.setGrpTypCd("TEST");
       assertNotNull(rtlPrc.getGrpTypCd());
       rtlPrc.setGrpCd(1);
       assertNotNull(rtlPrc.getGrpCd());
       rtlPrc.setPrcMstrTypId("TEST");
       assertNotNull(rtlPrc.getPrcMstrTypId());
       rtlPrc.setPrcMstrId("TEST");
       assertNotNull(rtlPrc.getPrcMstrId());
       rtlPrc.setEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(rtlPrc.getEffDt());
       rtlPrc.setXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(rtlPrc.getXpirDt());
       rtlPrc.setSrpAmt(new java.math.BigDecimal(1));
       assertNotNull(rtlPrc.getSrpAmt());
       rtlPrc.setRtlMlt(1);
       assertNotNull(rtlPrc.getRtlMlt());
       rtlPrc.setPrcStratCd("TEST");
       assertNotNull(rtlPrc.getPrcStratCd());
       rtlPrc.setAddUserId("TEST");
       assertNotNull(rtlPrc.getAddUserId());
       rtlPrc.setModUserId("TEST");
       assertNotNull(rtlPrc.getModUserId());
       rtlPrc.setModPgmId("TEST");
       assertNotNull(rtlPrc.getModPgmId());
       rtlPrc.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(rtlPrc.getAddTs());
       rtlPrc.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(rtlPrc.getModTs());
       rtlPrc.setPaActnCd("TEST");
       assertNotNull(rtlPrc.getPaActnCd());

       assertNotEquals(rtlPrc, new RtlPrc());
       System.out.println(rtlPrc.hashCode());
       System.out.println(rtlPrc.toString());
   }
}
