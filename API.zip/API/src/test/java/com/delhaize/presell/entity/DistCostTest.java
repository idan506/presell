package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DistCostTest {

   @InjectMocks
   DistCost distCost;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       distCost.setDistCstSidNbr(1);
       assertNotNull(distCost.getDistCstSidNbr());
       distCost.setDistCstTypCd("TEST");
       assertNotNull(distCost.getDistCstTypCd());
       distCost.setPrdtClsTypNbr(1);
       assertNotNull(distCost.getPrdtClsTypNbr());
       distCost.setMdseDeptNbr(1);
       assertNotNull(distCost.getMdseDeptNbr());
       distCost.setMjrCatgId("TEST");
       assertNotNull(distCost.getMjrCatgId());
       distCost.setDcSidNbr(1);
       assertNotNull(distCost.getDcSidNbr());
       distCost.setWhseNbr(1);
       assertNotNull(distCost.getWhseNbr());
       distCost.setStoreSidNbr(1);
       assertNotNull(distCost.getStoreSidNbr());
       distCost.setItemSetNbr(1);
       assertNotNull(distCost.getItemSetNbr());
       distCost.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(distCost.getItemNbr());
       distCost.setEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(distCost.getEffDt());
       distCost.setXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(distCost.getXpirDt());
       distCost.setCstAmt(new java.math.BigDecimal(1));
       assertNotNull(distCost.getCstAmt());
       distCost.setCrncyTypCd("TEST");
       assertNotNull(distCost.getCrncyTypCd());
       distCost.setCstDaysCnt(1);
       assertNotNull(distCost.getCstDaysCnt());
       distCost.setModUserId("TEST");
       assertNotNull(distCost.getModUserId());
       distCost.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(distCost.getModTs());
       distCost.setModPgmId("TEST");
       assertNotNull(distCost.getModPgmId());

       assertNotEquals(distCost, new DistCost());
       System.out.println(distCost.hashCode());
       System.out.println(distCost.toString());
   }
}
