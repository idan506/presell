package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ItmsoqmapTest {

   @InjectMocks
   Itmsoqmap itmsoqmap;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       itmsoqmap.setItmsoqmapPk(new ItmsoqmapPK());
       assertNotNull(itmsoqmap.getItmsoqmapPk());
       itmsoqmap.setSuggOrderQty(new java.math.BigDecimal(1));
       assertNotNull(itmsoqmap.getSuggOrderQty());
       itmsoqmap.setAddUserId("TEST");
       assertNotNull(itmsoqmap.getAddUserId());
       itmsoqmap.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(itmsoqmap.getAddTs());
       itmsoqmap.setModUserId("TEST");
       assertNotNull(itmsoqmap.getModUserId());
       itmsoqmap.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(itmsoqmap.getModTs());

       assertNotEquals(itmsoqmap, new Itmsoqmap());
       System.out.println(itmsoqmap.hashCode());
       System.out.println(itmsoqmap.toString());
   }
}
