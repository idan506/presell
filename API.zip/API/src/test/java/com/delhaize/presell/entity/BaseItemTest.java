package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BaseItemTest {

   @InjectMocks
   BaseItem baseItem;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       baseItem.setBaseItemPk(new BaseItemPK());
       assertNotNull(baseItem.getBaseItemPk());
       baseItem.setRplcItemNbr(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getRplcItemNbr());
       baseItem.setDistTypCd("TEST");
       assertNotNull(baseItem.getDistTypCd());
       baseItem.setPluNbr(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getPluNbr());
       baseItem.setItemEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getItemEffDt());
       baseItem.setRcvXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getRcvXpirDt());
       baseItem.setItemXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getItemXpirDt());
       baseItem.setItemCrtDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getItemCrtDt());
       baseItem.setItemLastActDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getItemLastActDt());
       baseItem.setItemPkQty(1);
       assertNotNull(baseItem.getItemPkQty());
       baseItem.setItemSzCnt(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getItemSzCnt());
       baseItem.setItemSzCd("TEST");
       assertNotNull(baseItem.getItemSzCd());
       baseItem.setItemDsc("TEST");
       assertNotNull(baseItem.getItemDsc());
       baseItem.setItemChkDgtNbr(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getItemChkDgtNbr());
       baseItem.setAltUpcNbr(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getAltUpcNbr());
       baseItem.setItemScanCd("TEST");
       assertNotNull(baseItem.getItemScanCd());
       baseItem.setPharDeaSchdCd("TEST");
       assertNotNull(baseItem.getPharDeaSchdCd());
       baseItem.setSuplyTrnslCd("TEST");
       assertNotNull(baseItem.getSuplyTrnslCd());
       baseItem.setPvtLblCd("TEST");
       assertNotNull(baseItem.getPvtLblCd());
       baseItem.setItemHndlCd("TEST");
       assertNotNull(baseItem.getItemHndlCd());
       baseItem.setItemStatCd("TEST");
       assertNotNull(baseItem.getItemStatCd());
       baseItem.setPrdtRcovTypCd("TEST");
       assertNotNull(baseItem.getPrdtRcovTypCd());
       baseItem.setPrcBkCd("TEST");
       assertNotNull(baseItem.getPrcBkCd());
       baseItem.setUomCd("TEST");
       assertNotNull(baseItem.getUomCd());
       baseItem.setItemRtlTypCd("TEST");
       assertNotNull(baseItem.getItemRtlTypCd());
       baseItem.setTaxCatgMjrId("TEST");
       assertNotNull(baseItem.getTaxCatgMjrId());
       baseItem.setTaxCatgMnrId("TEST");
       assertNotNull(baseItem.getTaxCatgMnrId());
       baseItem.setNdcCd("TEST");
       assertNotNull(baseItem.getNdcCd());
       baseItem.setRtlUnitPkQty(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getRtlUnitPkQty());
       baseItem.setItemPhysFormCd("TEST");
       assertNotNull(baseItem.getItemPhysFormCd());
       baseItem.setMfrDcntuDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getMfrDcntuDt());
       baseItem.setGpiId("TEST");
       assertNotNull(baseItem.getGpiId());
       baseItem.setBrndOwnerNbr(1);
       assertNotNull(baseItem.getBrndOwnerNbr());
       baseItem.setBrndNbr(1);
       assertNotNull(baseItem.getBrndNbr());
       baseItem.setItemColorDsc("TEST");
       assertNotNull(baseItem.getItemColorDsc());
       baseItem.setSpclHndlInstrCd("TEST");
       assertNotNull(baseItem.getSpclHndlInstrCd());
       baseItem.setFrtDensClsCd(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getFrtDensClsCd());
       baseItem.setPendDcntuStatCd("TEST");
       assertNotNull(baseItem.getPendDcntuStatCd());
       baseItem.setModUserId("TEST");
       assertNotNull(baseItem.getModUserId());
       baseItem.setModPgmId("TEST");
       assertNotNull(baseItem.getModPgmId());
       baseItem.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(baseItem.getModTs());
       baseItem.setPrcMstrTypId("TEST");
       assertNotNull(baseItem.getPrcMstrTypId());
       baseItem.setPrcMstrId("TEST");
       assertNotNull(baseItem.getPrcMstrId());
       baseItem.setPrcUnitObsltDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(baseItem.getPrcUnitObsltDt());
       baseItem.setPvtBrndCd("TEST");
       assertNotNull(baseItem.getPvtBrndCd());
       baseItem.setSignDsc("TEST");
       assertNotNull(baseItem.getSignDsc());
       baseItem.setOvrlnDsc("TEST");
       assertNotNull(baseItem.getOvrlnDsc());
       baseItem.setAvgUnitWgt(new java.math.BigDecimal(1));
       assertNotNull(baseItem.getAvgUnitWgt());
       baseItem.setMsaPromoCd("TEST");
       assertNotNull(baseItem.getMsaPromoCd());
       baseItem.setMsaCatgCd("TEST");
       assertNotNull(baseItem.getMsaCatgCd());
       baseItem.setMsaCtnStickCnt(1);
       assertNotNull(baseItem.getMsaCtnStickCnt());
       baseItem.setFdlnSignDsc("TEST");
       assertNotNull(baseItem.getFdlnSignDsc());
       baseItem.setFdlnOvrlnDsc("TEST");
       assertNotNull(baseItem.getFdlnOvrlnDsc());
       baseItem.setOnlineCds("TEST");
       assertNotNull(baseItem.getOnlineCds());

       assertNotEquals(baseItem, new BaseItem());
       System.out.println(baseItem.hashCode());
       System.out.println(baseItem.toString());
   }
}
