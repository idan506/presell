package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LvlClassTest {

   @InjectMocks
   LvlClass lvlClass;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       lvlClass.setPsellClsIdNbr(1);
       assertNotNull(lvlClass.getPsellClsIdNbr());
       lvlClass.setPsellLvlClsCd("TEST");
       assertNotNull(lvlClass.getPsellLvlClsCd());
       lvlClass.setLgclDelFlg("TEST");
       assertNotNull(lvlClass.getLgclDelFlg());
       lvlClass.setAddUserId("TEST");
       assertNotNull(lvlClass.getAddUserId());
       lvlClass.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(lvlClass.getAddTs());
       lvlClass.setModUserId("TEST");
       assertNotNull(lvlClass.getModUserId());
       lvlClass.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(lvlClass.getModTs());

       assertNotEquals(lvlClass, new LvlClass());
       System.out.println(lvlClass.hashCode());
       System.out.println(lvlClass.toString());
   }
}
