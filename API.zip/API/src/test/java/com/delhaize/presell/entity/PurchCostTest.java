package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PurchCostTest {

   @InjectMocks
   PurchCost purchCost;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       purchCost.setPurCstSidNbr(1);
       assertNotNull(purchCost.getPurCstSidNbr());
       purchCost.setItemSetNbr(1);
       assertNotNull(purchCost.getItemSetNbr());
       purchCost.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(purchCost.getItemNbr());
       purchCost.setVendSetNbr(1);
       assertNotNull(purchCost.getVendSetNbr());
       purchCost.setVendId("TEST");
       assertNotNull(purchCost.getVendId());
       purchCost.setLocSidNbr(1);
       assertNotNull(purchCost.getLocSidNbr());
       purchCost.setBrktNbr(1);
       assertNotNull(purchCost.getBrktNbr());
       purchCost.setCstCmpntTypNbr(1);
       assertNotNull(purchCost.getCstCmpntTypNbr());
       purchCost.setCstMstrId("TEST");
       assertNotNull(purchCost.getCstMstrId());
       purchCost.setEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(purchCost.getEffDt());
       purchCost.setXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(purchCost.getXpirDt());
       purchCost.setCstAmt(new java.math.BigDecimal(1));
       assertNotNull(purchCost.getCstAmt());
       purchCost.setCrncyTypCd("TEST");
       assertNotNull(purchCost.getCrncyTypCd());
       purchCost.setAlwTypNbr(1);
       assertNotNull(purchCost.getAlwTypNbr());
       purchCost.setAlwCstRateCd("TEST");
       assertNotNull(purchCost.getAlwCstRateCd());
       purchCost.setBbkCollDlaydDur(1);
       assertNotNull(purchCost.getBbkCollDlaydDur());
       purchCost.setCstBasisCd("TEST");
       assertNotNull(purchCost.getCstBasisCd());
       purchCost.setCstDsc("TEST");
       assertNotNull(purchCost.getCstDsc());
       purchCost.setSellAlwNegFlg("TEST");
       assertNotNull(purchCost.getSellAlwNegFlg());
       purchCost.setTotSellAlwAmt(new java.math.BigDecimal(1));
       assertNotNull(purchCost.getTotSellAlwAmt());
       purchCost.setBbkPgmId("TEST");
       assertNotNull(purchCost.getBbkPgmId());
       purchCost.setBpgCondId("TEST");
       assertNotNull(purchCost.getBpgCondId());
       purchCost.setLastModUserId("TEST");
       assertNotNull(purchCost.getLastModUserId());
       purchCost.setLastModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(purchCost.getLastModTs());
       purchCost.setLastModPgmId("TEST");
       assertNotNull(purchCost.getLastModPgmId());
       purchCost.setBilledVendId("TEST");
       assertNotNull(purchCost.getBilledVendId());

       assertNotEquals(purchCost, new PurchCost());
       System.out.println(purchCost.hashCode());
       System.out.println(purchCost.toString());
   }
}
