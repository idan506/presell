package com.delhaize.presell.service;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.dto.projection.BusUnitProjection;
import com.delhaize.presell.repository.BuMstrRepository;
import com.delhaize.presell.service.impl.BuMstrServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

public class BuMstrServiceImplTest {


    @InjectMocks
    BuMstrServiceImpl buMstrServiceImpl;

    @Mock
    BusUnitProjection busUnitProjection;
    @Mock
    BuMstrRepository buMstrRepository;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getBusUnit() {

        List<BusUnitDTO> data = new ArrayList<>();
        data.add(new BusUnitDTO("test", "test"));
        Mockito.when(buMstrRepository.getBusUnits()).thenReturn(data);

        var rs = buMstrServiceImpl.getBusUnit();

        assertEquals(1, rs.size());


    }

}
