package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PreselLogTest {

   @InjectMocks
   PreselLog preselLog;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       preselLog.setPreselLogPk(new PreselLogPK());
       assertNotNull(preselLog.getPreselLogPk());
       preselLog.setLogStatCd("TEST");
       assertNotNull(preselLog.getLogStatCd());
       preselLog.setLogCmtTxt("TEST");
       assertNotNull(preselLog.getLogCmtTxt());

       assertNotEquals(preselLog, new PreselLog());
       System.out.println(preselLog.hashCode());
       System.out.println(preselLog.toString());
   }
}
