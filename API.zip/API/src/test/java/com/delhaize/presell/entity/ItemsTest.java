package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ItemsTest {

   @InjectMocks
   Items items;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       items.setItemsPk(new ItemsPK());
       assertNotNull(items.getItemsPk());
       items.setItemCst(new java.math.BigDecimal(1));
       assertNotNull(items.getItemCst());
       items.setItemSzCnt(new java.math.BigDecimal(1));
       assertNotNull(items.getItemSzCnt());
       items.setItemSzCd("TEST");
       assertNotNull(items.getItemSzCd());
       items.setItemPkQty(1);
       assertNotNull(items.getItemPkQty());
       items.setItemCapCst(new java.math.BigDecimal(1));
       assertNotNull(items.getItemCapCst());
       items.setRtlPrc(new java.math.BigDecimal(1));
       assertNotNull(items.getRtlPrc());
       items.setPsellGrmrgAmt(new java.math.BigDecimal(1));
       assertNotNull(items.getPsellGrmrgAmt());
       items.setItemDsc("TEST");
       assertNotNull(items.getItemDsc());
       items.setPsellItemCmtTxt("TEST");
       assertNotNull(items.getPsellItemCmtTxt());
       items.setItemImgUrl("TEST");
       assertNotNull(items.getItemImgUrl());
       items.setItemCntrbPct(new java.math.BigDecimal(1));
       assertNotNull(items.getItemCntrbPct());
       items.setAddUserId("TEST");
       assertNotNull(items.getAddUserId());
       items.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(items.getAddTs());
       items.setModUserId("TEST");
       assertNotNull(items.getModUserId());
       items.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(items.getModTs());

       assertNotEquals(items, new Items());
       System.out.println(items.hashCode());
       System.out.println(items.toString());
   }
}
