package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class DuCntrTest {

   @InjectMocks
   DuCntr duCntr;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       duCntr.setDuCntrPk(new DuCntrPK());
       assertNotNull(duCntr.getDuCntrPk());
       duCntr.setUpcNbr(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getUpcNbr());
       duCntr.setGtinNbr(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getGtinNbr());
       duCntr.setCntrWth(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getCntrWth());
       duCntr.setWthUomCd("TEST");
       assertNotNull(duCntr.getWthUomCd());
       duCntr.setCntrLen(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getCntrLen());
       duCntr.setLenUomCd("TEST");
       assertNotNull(duCntr.getLenUomCd());
       duCntr.setCntrDpth(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getCntrDpth());
       duCntr.setDpthUomCd("TEST");
       assertNotNull(duCntr.getDpthUomCd());
       duCntr.setCntrWgt(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getCntrWgt());
       duCntr.setWgtUomCd("TEST");
       assertNotNull(duCntr.getWgtUomCd());
       duCntr.setCntrVol(new java.math.BigDecimal(1));
       assertNotNull(duCntr.getCntrVol());
       duCntr.setVolUomCd("TEST");
       assertNotNull(duCntr.getVolUomCd());
       duCntr.setModUserId("TEST");
       assertNotNull(duCntr.getModUserId());
       duCntr.setModPgmId("TEST");
       assertNotNull(duCntr.getModPgmId());
       duCntr.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(duCntr.getModTs());

       assertNotEquals(duCntr, new DuCntr());
       System.out.println(duCntr.hashCode());
       System.out.println(duCntr.toString());
   }
}
