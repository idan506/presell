package com.delhaize.presell.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class CommonFunctionsTest {
	@InjectMocks
	CommonFunctions commonFunctions;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void arrayNotEmpty() {
		String[] arr = {"A", "B", "C"};
		var rs = CommonFunctions.arrayNotEmpty(arr);
		assertEquals(true, rs);
	}
	
	@Test
	void arrayIsEmpty() {
		var rs = CommonFunctions.arrayNotEmpty(null);
		assertEquals(false, rs);
	}
	
	@Test
	void appendParamsStringValue() {
		String[] arr = {"A", "B", "C"};
		StringBuilder strbAppendQuery = new StringBuilder();
		CommonFunctions.appendParamsStringValue(arr, strbAppendQuery);
		assertTrue(true);
	}
	
	@Test
	void getPrescisionUptoTwoDecimalPlacesEqZero() {
		var rs = CommonFunctions.getPrescisionUptoTwoDecimalPlaces(new Double(0));
		assertNotNull(rs);
	}
	
	@Test
	void getPrescisionUptoTwoDecimalPlaces() {
		var rs = CommonFunctions.getPrescisionUptoTwoDecimalPlaces(new Double(1));
		assertNotNull(rs);
	}
}
