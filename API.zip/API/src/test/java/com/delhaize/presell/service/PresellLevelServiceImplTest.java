package com.delhaize.presell.service;

import com.delhaize.presell.dto.PresellLevelDTO;
import com.delhaize.presell.dto.request.PresellLevelRequestDTO;
import com.delhaize.presell.entity.LvlMaint;
import com.delhaize.presell.repository.LvlMaintRepository;
import com.delhaize.presell.service.impl.PresellLevelServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.*;

public class PresellLevelServiceImplTest {
    @InjectMocks
    PresellLevelServiceImpl presellLevelServiceImpl;

    @Mock
    LvlMaintRepository lvlMaintRepository;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getPresellLevel() {
        List<PresellLevelDTO> data = new ArrayList<>();
        data.add(new PresellLevelDTO("A", 1, DatetimeUtils.getUTCTimestamp()));

        Mockito.when(lvlMaintRepository.getAllPresellLevel()).thenReturn(data);
        var rs = presellLevelServiceImpl.getPresellLevel();
        assertNotNull(rs);
    }

    @Test
    public void deletePresellLevel() {
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(false);
        PresellLevelRequestDTO data = new PresellLevelRequestDTO();
        PresellLevelDTO level = new PresellLevelDTO();
        level.setLevelId(1212);
        level.setFetchTime(DatetimeUtils.getUTCTimestamp());
        List<PresellLevelDTO> listlevel = new ArrayList<>();
        listlevel.add(level);
        data.setPresellLevelDTOs(listlevel);
        data.setUserId("1233");
        LvlMaint lvlMaint = new LvlMaint();
        lvlMaint.setLgclDelFlg("Ytesting");
        lvlMaint.setPsellLvlDsc("");
        lvlMaint.setPsellLvlIdNbr(123);
        lvlMaint.setAddUserId("11223");
        lvlMaint.setModTs(DatetimeUtils.getUTCTimestamp());
        lvlMaint.setAddTs(DatetimeUtils.getUTCTimestamp());
        List<LvlMaint> listData = new ArrayList<>();
        Optional<LvlMaint> dataOpt = Optional.of(lvlMaint);
        listData.add(dataOpt.get());
        Timestamp maxModDB = new Timestamp(DatetimeUtils.getUTCTimestamp().getTime() - 60*60*1000);
        Mockito.when(lvlMaintRepository.findById(level.getLevelId())).thenReturn(dataOpt);
        Mockito.when(lvlMaintRepository.saveAll(listData)).thenReturn(listData);
        Mockito.when(lvlMaintRepository.getMaxUpdateTimestamp()).thenReturn(maxModDB);
        var rs = presellLevelServiceImpl.deletePresellLevel(data);
        assertNotNull(rs);
    }

    @Test
    public void insertOrUpdatePresellLevel() {
        Timestamp maxModDB = DatetimeUtils.getUTCTimestamp();
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(false);
        PresellLevelRequestDTO data = new PresellLevelRequestDTO();
        PresellLevelDTO level = new PresellLevelDTO();
        level.setLevelId(1212);
        level.setFetchTime(DatetimeUtils.getUTCTimestamp());
        List<PresellLevelDTO> listlevel = new ArrayList<>();
        listlevel.add(level);
        data.setPresellLevelDTOs(listlevel);
        data.setUserId("1233");
        LvlMaint lvlMaint = new LvlMaint();
        lvlMaint.setLgclDelFlg("Ytesting");
        lvlMaint.setPsellLvlDsc("");
        lvlMaint.setPsellLvlIdNbr(123);
        lvlMaint.setAddUserId("11223");
        lvlMaint.setModTs(DatetimeUtils.getUTCTimestamp());
        lvlMaint.setAddTs(DatetimeUtils.getUTCTimestamp());
        int id = 2333;
        Mockito.when(lvlMaintRepository.getMaxSequence() + 1).thenReturn(id);
        lvlMaint.setPsellLvlIdNbr(id);
        List<LvlMaint> listData = new ArrayList<>();
        Optional<LvlMaint> dataOpt = Optional.of(lvlMaint);
        listData.add(dataOpt.get());

        Mockito.when(lvlMaintRepository.findById(level.getLevelId())).thenReturn(dataOpt);
        Mockito.when(lvlMaintRepository.saveAll(listData)).thenReturn(listData);
        Mockito.when(lvlMaintRepository.getMaxUpdateTimestamp()).thenReturn(maxModDB);
        var rs = presellLevelServiceImpl.insertOrUpdatePresellLevel(data);
        assertEquals(1, rs);
    }

    @Test
    public void insertOrUpdatePresellLevelPresell() {
        PresellLevelRequestDTO data = new PresellLevelRequestDTO();
        PresellLevelDTO level = new PresellLevelDTO();
        level.setLevelId(0);
        level.setFetchTime(DatetimeUtils.getUTCTimestamp());
        List<PresellLevelDTO> listlevel = new ArrayList<>();
        listlevel.add(level);
        data.setPresellLevelDTOs(listlevel);
        data.setUserId("1233");
        LvlMaint lvlMaint = new LvlMaint();
        lvlMaint.setLgclDelFlg("Ytesting");
        lvlMaint.setPsellLvlDsc("");
        lvlMaint.setPsellLvlIdNbr(123);
        lvlMaint.setAddUserId("11223");
        lvlMaint.setModTs(DatetimeUtils.getUTCTimestamp());
        lvlMaint.setAddTs(DatetimeUtils.getUTCTimestamp());
        List<LvlMaint> listData = new ArrayList<>();
        Optional<LvlMaint> dataOpt = Optional.of(lvlMaint);
        listData.add(dataOpt.get());
        Mockito.when(lvlMaintRepository.saveAll(listData)).thenReturn(listData);
        var rs = presellLevelServiceImpl.insertOrUpdatePresellLevel(data);
        assertEquals(1, rs);

    }

    @Test
    public void insertOrUpdatePresellLevel1() {
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(true);
        PresellLevelRequestDTO data = new PresellLevelRequestDTO();
        PresellLevelDTO level = new PresellLevelDTO();
        level.setLevelId(1232);
        level.setFetchTime(DatetimeUtils.getUTCTimestamp());
        List<PresellLevelDTO> listlevel = new ArrayList<>();
        listlevel.add(level);
        data.setPresellLevelDTOs(listlevel);
        data.setUserId("1233");
        LvlMaint lvlMaint = new LvlMaint();
        lvlMaint.setLgclDelFlg("Ytesting");
        lvlMaint.setPsellLvlDsc("");
        lvlMaint.setPsellLvlIdNbr(123);
        lvlMaint.setAddUserId("11223");
        lvlMaint.setModTs(DatetimeUtils.getUTCTimestamp());
        lvlMaint.setAddTs(DatetimeUtils.getUTCTimestamp());
        List<LvlMaint> listData = new ArrayList<>();
        Timestamp maxModDB = new Timestamp(DatetimeUtils.getUTCTimestamp().getTime() + 60*60*1000);
        Optional<LvlMaint> dataOpt = Optional.of(lvlMaint);
        listData.add(dataOpt.get());
        lvlMaint.setLgclDelFlg("Ytesting");
        lvlMaint.setPsellLvlDsc("");
        lvlMaint.setPsellLvlIdNbr(123);
        lvlMaint.setAddUserId("11223");
        lvlMaint.setModTs(DatetimeUtils.getUTCTimestamp());
        lvlMaint.setAddTs(DatetimeUtils.getUTCTimestamp());
        listData.add(dataOpt.get());
        Mockito.when(lvlMaintRepository.saveAll(listData)).thenReturn(listData);
        Mockito.when(lvlMaintRepository.getMaxUpdateTimestamp()).thenReturn(maxModDB);
        assertEquals(1, presellLevelServiceImpl.insertOrUpdatePresellLevel(data));
        Mockito.when(lvlMaintRepository.findById(level.getLevelId())).thenReturn(dataOpt);
        assertThrows(Exception.class, () -> presellLevelServiceImpl.insertOrUpdatePresellLevel(data));
    }
}