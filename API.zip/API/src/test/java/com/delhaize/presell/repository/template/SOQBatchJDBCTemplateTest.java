package com.delhaize.presell.repository.template;

import com.delhaize.presell.entity.Itmsoqmap;
import com.delhaize.presell.entity.ItmsoqmapPK;
import com.delhaize.presell.util.DatetimeUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SOQBatchJDBCTemplateTest {
    private SOQBatchJDBCTemplate soqBatchJDBCTemplate;
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    void initSetup() {
        jdbcTemplate = mock(JdbcTemplate.class);
        soqBatchJDBCTemplate = new SOQBatchJDBCTemplate(jdbcTemplate);
    }

    @Test
    void insertSOQTest() throws SQLException {
        Assertions.assertDoesNotThrow(() -> soqBatchJDBCTemplate.insertSOQ(new ArrayList<>()));
        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId("rparo");
        itmsoqmap.setModUserId("rparo");
        var setter = new SOQBatchJDBCTemplate.SOQBatchInsertPreparedStatementSetter(List.of(itmsoqmap));
        setter.setValues(mock(PreparedStatement.class), 0);
        assertEquals(1, setter.getBatchSize());
        when(jdbcTemplate.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class))).thenReturn(new int[]{});
        Assertions.assertDoesNotThrow(() -> soqBatchJDBCTemplate.insertSOQ(List.of(itmsoqmap)));
    }

    @Test
    void updateSOQTest() throws SQLException {
        Assertions.assertDoesNotThrow(() -> soqBatchJDBCTemplate.updateSOQ(new ArrayList<>()));
        Itmsoqmap itmsoqmap = new Itmsoqmap();
        var pk = new ItmsoqmapPK();
        pk.setPsellIdNbr(1);
        pk.setItemNbr(new BigDecimal(1));
        pk.setShipDt(DatetimeUtils.getCurrentSQLDate());
        pk.setPsellClsIdNbr(1);
        itmsoqmap.setItmsoqmapPk(pk);
        itmsoqmap.setSuggOrderQty(new BigDecimal(1));
        itmsoqmap.setModUserId("rparo");
        itmsoqmap.setModUserId("rparo");
        var setter = new SOQBatchJDBCTemplate.SOQBatchUpdatePreparedStatementSetter(List.of(itmsoqmap));
        setter.setValues(mock(PreparedStatement.class), 0);
        assertEquals(1, setter.getBatchSize());
        when(jdbcTemplate.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class))).thenReturn(new int[]{});
        Assertions.assertDoesNotThrow(() -> soqBatchJDBCTemplate.updateSOQ(List.of(itmsoqmap)));
    }
}
