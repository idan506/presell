package com.delhaize.presell.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class AddressPKTest {

   @InjectMocks
   AddressPK addressPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       addressPk.setLocSidNbr(1);
       assertNotNull(addressPk.getLocSidNbr());
       addressPk.setCntctTypCd("TEST");
       assertNotNull(addressPk.getCntctTypCd());
       addressPk.setAdrTypCd("TEST");
       assertNotNull(addressPk.getAdrTypCd());
   }
}
