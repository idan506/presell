package com.delhaize.presell.repository.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;

public class PresellLevelMappingDAOImplTest {
	@InjectMocks
	PresellLevelMappingDAOImpl presellLevelMappingDAOImpl;
	
	@Mock
	EntityManager entityManager;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void getPresellLevelStoreListByStoreNo() {
		StorePresellLevelMappingCriteria criteria = buildCriteria("1", null);
		TypedQuery query = mock(TypedQuery.class);
		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		List<Integer> result = new ArrayList<>();
		result.add(1);
		result.add(2);
		when(query.getResultList()).thenReturn(result);
		presellLevelMappingDAOImpl.getPresellLevelStoreList(criteria);
		assertTrue(true);
	}
	
	@Test
	void getPresellLevelStoreListByStoreNoNotExist() {
		StorePresellLevelMappingCriteria criteria = buildCriteria("1", null);
		TypedQuery query = mock(TypedQuery.class);
		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		List<Integer> result = new ArrayList<>();
		result.add(3);
		result.add(4);
		when(query.getResultList()).thenReturn(result);
		presellLevelMappingDAOImpl.getPresellLevelStoreList(criteria);
		assertTrue(true);
	}
	
	@Test
	void getPresellLevelStoreListByStoreTypeAll() {
		StorePresellLevelMappingCriteria criteria = buildCriteria(null, "ALL");
		TypedQuery query = mock(TypedQuery.class);
		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		presellLevelMappingDAOImpl.getPresellLevelStoreList(criteria);
		assertTrue(true);
	}
	
	@Test
	void getPresellLevelStoreListByStoreType() {
		StorePresellLevelMappingCriteria criteria = buildCriteria(null, "HAN");
		TypedQuery query = mock(TypedQuery.class);
		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		presellLevelMappingDAOImpl.getPresellLevelStoreList(criteria);
		assertTrue(true);
	}
	
	private StorePresellLevelMappingCriteria buildCriteria(String storeNo, String storeType) {
		StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria();
		criteria.setStoreNo(storeNo);
		criteria.setStoreType(storeType);
		return criteria;
	}
}
