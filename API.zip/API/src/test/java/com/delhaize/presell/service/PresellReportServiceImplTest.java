package com.delhaize.presell.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.MissingOrderProjection;
import com.delhaize.presell.dto.projection.StoreItemProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import com.delhaize.presell.repository.ItemsRepository;
import com.delhaize.presell.repository.PresellRepository;
import com.delhaize.presell.repository.StorItemsRepository;
import com.delhaize.presell.repository.dao.PresellReportDAO;
import com.delhaize.presell.service.impl.PresellReportServiceImpl;

public class PresellReportServiceImplTest {
	@InjectMocks
	PresellReportServiceImpl presellReportServiceImpl;

	@Mock
	ItemsRepository itemsRepository;

	@Mock
	StorItemsRepository storItemsRepository;

	@Mock
	PresellRepository presellRepository;

	@Mock
	PresellReportDAO presellReportDAO;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getListItemReport() {
		int psellIdNbr = 1;
		List<ItemProjection> items = new ArrayList<>();
		items.add(new ItemProjection() {

			@Override
			public BigDecimal getSuggOrderQty() {
				return null;
			}

			@Override
			public Date getShipDt() {
				return null;
			}

			@Override
			public BigDecimal getRtlPrc() {
				return null;
			}

			@Override
			public String getPsellLvlClsCd() {
				return null;
			}

			@Override
			public String getPsellItemCmtTxt() {
				return null;
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return null;
			}

			@Override
			public Integer getPsellClsIdNbr() {
				return null;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return null;
			}

			@Override
			public String getItemSzCd() {
				return null;
			}

			@Override
			public Integer getItemPkQty() {
				return null;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return null;
			}

			@Override
			public BigDecimal getItemNbr() {
				return null;
			}

			@Override
			public String getItemImgUrl() {
				return null;
			}

			@Override
			public String getItemDsc() {
				return null;
			}

			@Override
			public BigDecimal getItemCapCst() {
				return null;
			}
		});
		when(itemsRepository.getListItem(psellIdNbr)).thenReturn(items);
		var rs = presellReportServiceImpl.getListItemReport(psellIdNbr);
		assertEquals(1, rs.size());
	}

	@Test
	public void getListStoreItemReport() {
		int psellIdNbr = 1;
		List<StoreItemProjection> storeItems = new ArrayList<>();
		storeItems.add(new StoreItemProjection() {

			@Override
			public Integer getStoreNbr() {
				return null;
			}

			@Override
			public Date getShipDt() {
				return null;
			}

			@Override
			public BigDecimal getRtlPrc() {
				return null;
			}

			@Override
			public String getPsellLvlClsCd() {
				return null;
			}

			@Override
			public String getPsellItemCmtTxt() {
				return null;
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return null;
			}

			@Override
			public String getLocOrgDsc() {
				return null;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return null;
			}

			@Override
			public String getItemSzCd() {
				return null;
			}

			@Override
			public Integer getItemPkQty() {
				return null;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return null;
			}

			@Override
			public BigDecimal getItemNbr() {
				return null;
			}

			@Override
			public String getItemImgUrl() {
				return null;
			}

			@Override
			public String getItemDsc() {
				return null;
			}

			@Override
			public BigDecimal getItemCapCst() {
				return null;
			}
		});

		when(storItemsRepository.getListStoreItem(psellIdNbr)).thenReturn(storeItems);
		var rs = presellReportServiceImpl.getListStoreItemReport(psellIdNbr);
		assertEquals(1, rs.size());
	}

	@Test
	public void getListMissingOrderReport() {
		int psellIdNbr = 1;
		List<MissingOrderProjection> listMissingReports = new ArrayList<>();
		List<MissingOrderProjection> listDraftReports = new ArrayList<>();

		when(storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SEND_TO_STORES))
				.thenReturn(listMissingReports);

		when(storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SAVED_AS_DRAFT))
				.thenReturn(listDraftReports);

		var rs = presellReportServiceImpl.getListMissingOrderReport(psellIdNbr);
		assertNotNull(rs);
	}

	@Test
	public void downLoadStorePresellItemReport() {
		int psellIdNbr = 1;
		List<ItemProjection> listItem = new ArrayList<>();
		listItem.add(new ItemProjection() {

			@Override
			public BigDecimal getSuggOrderQty() {
				return new BigDecimal(1);
			}

			@Override
			public Date getShipDt() {
				return new Date(1);
			}

			@Override
			public BigDecimal getRtlPrc() {
				return new BigDecimal(1);
			}

			@Override
			public String getPsellLvlClsCd() {
				return "A";
			}

			@Override
			public String getPsellItemCmtTxt() {
				return "A";
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return new BigDecimal(1);
			}

			@Override
			public Integer getPsellClsIdNbr() {
				return 1;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return new BigDecimal(1);
			}

			@Override
			public String getItemSzCd() {
				return "A";
			}

			@Override
			public Integer getItemPkQty() {
				return 1;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return new BigDecimal(1);
			}

			@Override
			public BigDecimal getItemNbr() {
				return new BigDecimal(1);
			}

			@Override
			public String getItemImgUrl() {
				return "A";
			}

			@Override
			public String getItemDsc() {
				return "A";
			}

			@Override
			public BigDecimal getItemCapCst() {
				return new BigDecimal(1);
			}
		});
		when(itemsRepository.getListItem(psellIdNbr)).thenReturn(listItem);
		java.util.Date dtCurrentDate = new java.util.Date();

		PresellReportDTO presellReport = new PresellReportDTO(1, "A", "A", "A", PresellConstants.SEND_TO_STORES,
				dtCurrentDate, "A", "A", "A");
		when(presellRepository.getPresellReportDetails(psellIdNbr)).thenReturn(presellReport);

		String fileName = "Presell_Rpt_" + dtCurrentDate.getTime() + ".xls";
		var rs = presellReportServiceImpl.downLoadStorePresellItemReport(psellIdNbr, fileName);
		assertNotNull(rs);
	}

	@Test
	public void downLoadStorePresellStoreItemReport() {
		int psellIdNbr = 1;
		java.util.Date dtCurrentDate = new java.util.Date();
		String fileName = "Presell_Rpt_" + dtCurrentDate.getTime() + ".xls";
		List<StoreItemProjection> listStore = new ArrayList<>();
		listStore.add(new StoreItemProjection() {

			@Override
			public Integer getStoreNbr() {
				return 1;
			}

			@Override
			public Date getShipDt() {
				return new Date(1);
			}

			@Override
			public BigDecimal getRtlPrc() {
				return new BigDecimal(1);
			}

			@Override
			public String getPsellLvlClsCd() {
				return "A";
			}

			@Override
			public String getPsellItemCmtTxt() {
				return "A";
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return new BigDecimal(1);
			}

			@Override
			public String getLocOrgDsc() {
				return "A";
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return new BigDecimal(1);
			}

			@Override
			public String getItemSzCd() {
				return "A";
			}

			@Override
			public Integer getItemPkQty() {
				return 1;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return new BigDecimal(1);
			}

			@Override
			public BigDecimal getItemNbr() {
				return new BigDecimal(1);
			}

			@Override
			public String getItemImgUrl() {
				return "A";
			}

			@Override
			public String getItemDsc() {
				return "A";
			}

			@Override
			public BigDecimal getItemCapCst() {
				return new BigDecimal(1);
			}
		});
		when(storItemsRepository.getListStoreItem(psellIdNbr)).thenReturn(listStore);

		// when(storItemsRepository.getListStoreItem(psellIdNbr)).thenReturn(listStore);
		PresellReportDTO presellReport = new PresellReportDTO(1, "A", "A", "A", PresellConstants.REC_FROM_STORES,
				dtCurrentDate, "A", "A", "A");
		when(presellRepository.getPresellReportDetails(psellIdNbr)).thenReturn(presellReport);
		var rs = presellReportServiceImpl.downLoadStorePresellStoreItemReport(psellIdNbr, fileName);
		assertNotNull(rs);
	}

	@Test
	public void downLoadStorePresellDraftReport() {
		int psellIdNbr = 1;
		java.util.Date dtCurrentDate = new java.util.Date();
		String fileName = "Presell_Rpt_" + dtCurrentDate.getTime() + ".xls";
		List<MissingOrderProjection> listMissingReports = new ArrayList<>();
		listMissingReports.add(new MissingOrderProjection() {
			
			@Override
			public Integer getStoreNbr() {
				return 1;
			}
			
			@Override
			public String getStoreNam() {
				return "A";
			}
			
			@Override
			public String getLocOrgDsc() {
				return "A";
			}
		});
		when(storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SEND_TO_STORES))
				.thenReturn(listMissingReports);
		PresellReportDTO presellReport = new PresellReportDTO(1, "A", "A", "A", PresellConstants.REC_FROM_STORES,
				dtCurrentDate, "A", "A", "A");
		when(presellRepository.getPresellReportDetails(psellIdNbr)).thenReturn(presellReport);
		var rs = presellReportServiceImpl.downLoadStorePresellDraftReport(psellIdNbr, fileName);
		assertNotNull(rs);
	}
	
	@Test
	public void downLoadStorePresellMissingOrderReport() {
		int psellIdNbr = 1;
		java.util.Date dtCurrentDate = new java.util.Date();
		String fileName = "Presell_Rpt_" + dtCurrentDate.getTime() + ".xls";
		List<MissingOrderProjection> listMissingReports = new ArrayList<>();
		listMissingReports.add(new MissingOrderProjection() {
			
			@Override
			public Integer getStoreNbr() {
				return 1;
			}
			
			@Override
			public String getStoreNam() {
				return "A";
			}
			
			@Override
			public String getLocOrgDsc() {
				return "A";
			}
		});
		when(storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SAVED_AS_DRAFT))
				.thenReturn(listMissingReports);
		PresellReportDTO presellReport = new PresellReportDTO(1, "A", "A", "A", PresellConstants.REC_FROM_STORES,
				dtCurrentDate, "A", "A", "A");
		when(presellRepository.getPresellReportDetails(psellIdNbr)).thenReturn(presellReport);
		var rs = presellReportServiceImpl.downLoadStorePresellMissingOrderReport(psellIdNbr, fileName);
		assertNotNull(rs);
	}

	@Test
	public void getPresellReportDetails() {
		int psellIdNbr = 1;
		PresellReportDTO presellReport = new PresellReportDTO();
		when(presellRepository.getPresellReportDetails(psellIdNbr)).thenReturn(presellReport);
		var rs = presellReportServiceImpl.getPresellReportDetails(psellIdNbr);
		assertNotNull(rs);
	}
	
	@Test
	public void searchPresellReport() {
		PresellReportSearchCriteria criteria = new PresellReportSearchCriteria(
				null, null, null, null, null, null, null, null, null);
		
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());
		Page<PresellReportDTO> pageReport = null;
		when(presellReportDAO.searchPresellReport(criteria, pageable)).thenReturn(pageReport);
		var rs = presellReportServiceImpl.searchPresellReport(criteria, paginationAndSortDTO);
		assertTrue(true);
	}

}
