package com.delhaize.presell.repository.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import com.delhaize.presell.util.DatetimeUtils;

public class PresellReportDAOImplTest {
	@InjectMocks
	PresellReportDAOImpl presellReportDAOImpl;

	@Mock
	EntityManager entityManager;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void searchPresellReportWithStatusAll() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.ALL);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = presellReportDAOImpl.searchPresellReport(criteria, pageable);
		assertNotNull(rs);
	}
	
	@Test
	void searchPresellReportWithStatusREC() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.REC_FROM_STORES);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = presellReportDAOImpl.searchPresellReport(criteria, pageable);
		assertNotNull(rs);
	}
	
	@Test
	void searchPresellReportWithStatusSTS() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.SEND_TO_STORES);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = presellReportDAOImpl.searchPresellReport(criteria, pageable);
		assertNotNull(rs);
	}
	
	@Test
	void searchPresellReportWithStatusCLS() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = presellReportDAOImpl.searchPresellReport(criteria, pageable);
		assertNotNull(rs);
	}
	
	@Test
	void searchPresellReportWithStatusNotFound() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.ALL_EXCLUDING_CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		
		when(query.getSingleResult()).thenReturn(new Long("10"));
		assertThrows(Exception.class, () -> presellReportDAOImpl.searchPresellReport(criteria, pageable));
	}
	
	@Test
	void searchPresellReportErrorTotalElement() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.ALL);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		assertThrows(Exception.class, () -> presellReportDAOImpl.searchPresellReport(criteria, pageable));

	}
	
	@Test
	void searchPresellReportWithNullPageable() {
		PresellReportSearchCriteria criteria = buildCriteria(Status.ALL);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		TypedQuery query = mock(TypedQuery.class);
		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		List<PresellReportDTO> result = new ArrayList<>();
		result.add(new PresellReportDTO(1, "A", "A", "A", "REC", DatetimeUtils.getCurrentSQLDate(), "A", "A", "A"));
		when(query.getResultList()).thenReturn(result);
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = presellReportDAOImpl.searchPresellReport(criteria, null);
		assertNotNull(rs);

	}
	
	private PresellReportSearchCriteria buildCriteria(Status status) {
		PresellReportSearchCriteria criteria = new PresellReportSearchCriteria();
		criteria.setPresellTitle("A");
		criteria.setPresellLevelId(1);
		criteria.setStatus(status);
		criteria.setStoreNo("1");
		criteria.setPresellAuthor("A");
		criteria.setBusinessUnit("A");
		criteria.setFromDueDate(DatetimeUtils.getCurrentSQLDate());
		criteria.setToDueDate(DatetimeUtils.getCurrentSQLDate());
		criteria.setPlannedDis("Y");
		return criteria;
	}

}
