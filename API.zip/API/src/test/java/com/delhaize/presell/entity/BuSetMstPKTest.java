package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BuSetMstPKTest {

   @InjectMocks
   BuSetMstPK buSetMstPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       buSetMstPk.setBusUnitId("TEST");
       assertNotNull(buSetMstPk.getBusUnitId());
       buSetMstPk.setEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(buSetMstPk.getEffDt());
   }
}
