package com.delhaize.presell.service;

import com.delhaize.presell.dto.projection.LocOrgProjection;
import com.delhaize.presell.dto.projection.StateProjection;
import com.delhaize.presell.repository.AddressRepository;
import com.delhaize.presell.repository.LocOrgRepository;
import com.delhaize.presell.service.impl.LocationServiceImpl;
import nonapi.io.github.classgraph.utils.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class LocationServiceImplTest {
    @InjectMocks
    LocationServiceImpl locationServiceImpl;
    @Mock
    LocOrgRepository locOrgRepository;
    @Mock
    AddressRepository addressRepository;

    @BeforeEach
    public void Start() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getDivisions(){
        List<LocOrgProjection> data=new ArrayList<>();
        data.add(new LocOrgProjection(){

            @Override
            public Integer getLocOrgSidNbr() {
                return null;
            }

            @Override
            public String getLocOrgDsc() {
                return null;
            }
        });
        String locOrgTypId="";
        Mockito.when(locOrgRepository.fetchLocations(locOrgTypId)).thenReturn(data);
        var rs=locationServiceImpl.getDivisions();
        assertNotNull(rs);
    }
    @Test
    public void getDistricts(){
        List<LocOrgProjection> data=new ArrayList<>();
        data.add(new LocOrgProjection(){

            @Override
            public Integer getLocOrgSidNbr() {
                return null;
            }

            @Override
            public String getLocOrgDsc() {
                return null;
            }
        });
        String locOrgTypId="";
        Mockito.when(locOrgRepository.fetchLocations(locOrgTypId)).thenReturn(data);
        var rs=locationServiceImpl.getDistricts();
        assertNotNull(rs);
    }
    @Test
    public void getStates(){
        List<StateProjection> data=new ArrayList<>();
        data.add(new StateProjection(){
            @Override
            public String getState() {
                return null;
            }
        } );
        Mockito.when(addressRepository.fetchStates()).thenReturn(data);
        var rs=locationServiceImpl.getStates();
        assertNotNull(rs);
    }

}
