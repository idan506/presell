package com.delhaize.presell.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class AddressTest {

   @InjectMocks
   Address address;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       address.setAddressPk(new AddressPK());
       assertNotNull(address.getAddressPk());
       address.setCntctLn1Adr("TEST");
       assertNotNull(address.getCntctLn1Adr());
       address.setCntctLn2Adr("TEST");
       assertNotNull(address.getCntctLn2Adr());
       address.setCntctCityNam("TEST");
       assertNotNull(address.getCntctCityNam());
       address.setCntctStCd("TEST");
       assertNotNull(address.getCntctStCd());
       address.setCntctPstlCd("TEST");
       assertNotNull(address.getCntctPstlCd());
       address.setCntctCntryNam("TEST");
       assertNotNull(address.getCntctCntryNam());
       address.setLatNbr(new java.math.BigDecimal(1));
       assertNotNull(address.getLatNbr());
       address.setLonNbr(new java.math.BigDecimal(1));
       assertNotNull(address.getLonNbr());
       address.setTzCd("TEST");
       assertNotNull(address.getTzCd());
       address.setModUserId("TEST");
       assertNotNull(address.getModUserId());
       address.setModPgmId("TEST");
       assertNotNull(address.getModPgmId());
       address.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(address.getModTs());

       assertNotEquals(address, new Address());
       System.out.println(address.hashCode());
       System.out.println(address.toString());
   }
}
