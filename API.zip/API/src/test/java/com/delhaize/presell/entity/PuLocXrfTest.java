package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PuLocXrfTest {

   @InjectMocks
   PuLocXrf puLocXrf;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       puLocXrf.setPuLocXrfPk(new PuLocXrfPK());
       assertNotNull(puLocXrf.getPuLocXrfPk());
       puLocXrf.setShipPlltTypCd("TEST");
       assertNotNull(puLocXrf.getShipPlltTypCd());
       puLocXrf.setAuthEffDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(puLocXrf.getAuthEffDt());
       puLocXrf.setAuthXpirDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(puLocXrf.getAuthXpirDt());
       puLocXrf.setActCstMstrId("TEST");
       assertNotNull(puLocXrf.getActCstMstrId());
       puLocXrf.setWebItemFlg("TEST");
       assertNotNull(puLocXrf.getWebItemFlg());
       puLocXrf.setAsscRoSidNbr(1);
       assertNotNull(puLocXrf.getAsscRoSidNbr());
       puLocXrf.setModUserId("TEST");
       assertNotNull(puLocXrf.getModUserId());
       puLocXrf.setModPgmId("TEST");
       assertNotNull(puLocXrf.getModPgmId());
       puLocXrf.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(puLocXrf.getModTs());

       assertNotEquals(puLocXrf, new PuLocXrf());
       System.out.println(puLocXrf.hashCode());
       System.out.println(puLocXrf.toString());
   }
}
