package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PresellTest {

   @InjectMocks
   Presell presell;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       presell.setPsellIdNbr(1);
       assertNotNull(presell.getPsellIdNbr());
       presell.setPsellLvlIdNbr(1);
       assertNotNull(presell.getPsellLvlIdNbr());
       presell.setBusUnitId("TEST");
       assertNotNull(presell.getBusUnitId());
       presell.setPsellDsc("TEST");
       assertNotNull(presell.getPsellDsc());
       presell.setPsellDueDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(presell.getPsellDueDt());
       presell.setPlnDistFlg("TEST");
       assertNotNull(presell.getPlnDistFlg());
       presell.setRmndrEmailDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(presell.getRmndrEmailDt());
       presell.setPsellCmtTxt("TEST");
       assertNotNull(presell.getPsellCmtTxt());
       presell.setPsellStatCd("TEST");
       assertNotNull(presell.getPsellStatCd());
       presell.setAddUserId("TEST");
       assertNotNull(presell.getAddUserId());
       presell.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(presell.getAddTs());
       presell.setModUserId("TEST");
       assertNotNull(presell.getModUserId());
       presell.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(presell.getModTs());

       assertNotEquals(presell, new Presell());
       System.out.println(presell.hashCode());
       System.out.println(presell.toString());
   }
}
