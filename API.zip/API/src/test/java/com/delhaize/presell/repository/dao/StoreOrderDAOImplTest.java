package com.delhaize.presell.repository.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.StoreOrderDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;
import com.delhaize.presell.util.DatetimeUtils;

public class StoreOrderDAOImplTest {
	@InjectMocks
	StoreOrderDAOImpl storeOrderDAOImpl;

	@Mock
	EntityManager entityManager;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void searchStoreOrderWithStatusSubmitted() {
		StoreOrderCriteria criteria = buildCriteria(Status.SUBMITTED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);
		List<StoreOrderDTO> result = new ArrayList<>();
		result.add(new StoreOrderDTO(1, "A", "A", "A", "SUB", DatetimeUtils.getCurrentSQLDate(), "Y"));
		when(query.getResultList()).thenReturn(result);
		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrder(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderWithStatusPending() {
		StoreOrderCriteria criteria = buildCriteria(Status.PENDING);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrder(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderWithStatusREC() {
		StoreOrderCriteria criteria = buildCriteria(Status.REC_FROM_STORES);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrder(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderWithStatusClose() {
		StoreOrderCriteria criteria = buildCriteria(Status.CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrder(criteria, pageable);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreOrderWithAllStatus() {
		StoreOrderCriteria criteria = buildCriteria(Status.ALL_EXCLUDING_CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrder(criteria, pageable);
		assertNotNull(rs);
	}
	
	@Test
	void searchStoreOrderWithNullPageable() {
		StoreOrderCriteria criteria = buildCriteria(Status.ALL_EXCLUDING_CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrder(criteria, null);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderWithStatusNotFound() {
		StoreOrderCriteria criteria = buildCriteria(Status.ALL);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenThrow(IllegalArgumentException.class);
		assertThrows(Exception.class, () -> storeOrderDAOImpl.searchStoreOrder(criteria, pageable));

	}

	@Test
	void searchStoreOrderRoleRTWithStatusSubmitted() {
		StoreOrderCriteria criteria = buildCriteria(Status.SUBMITTED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrderWithRoleRT(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderRoleRTWithStatusPending() {
		StoreOrderCriteria criteria = buildCriteria(Status.PENDING);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrderWithRoleRT(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderRoleRTWithStatusSaveAsDraft() {
		StoreOrderCriteria criteria = buildCriteria(Status.SAVED_AS_DRAFT);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrderWithRoleRT(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderRoleRTWithStatusClose() {
		StoreOrderCriteria criteria = buildCriteria(Status.CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrderWithRoleRT(criteria, pageable);
		assertNotNull(rs);
	}

	@Test
	void searchStoreOrderRoleRTWithStatusNotFound() {
		StoreOrderCriteria criteria = buildCriteria(Status.ALL_EXCLUDING_CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");

		Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
				paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
						: Sort.by(paginationAndSortDTO.getSortBy()).descending());

		TypedQuery query = mock(TypedQuery.class);
		when(entityManager.createQuery(anyString(), any())).thenThrow(IllegalArgumentException.class);
		assertThrows(Exception.class, () -> storeOrderDAOImpl.searchStoreOrderWithRoleRT(criteria, pageable));
	}
	
	@Test
	void searchStoreOrderRoleRTWithNullPageable() {
		StoreOrderCriteria criteria = buildCriteria(Status.CLOSED);
		PaginationAndSortDTO paginationAndSortDTO = new PaginationAndSortDTO();
		paginationAndSortDTO.setPage(1);
		paginationAndSortDTO.setSize(10);
		paginationAndSortDTO.setOrder(Sort.Direction.ASC);
		paginationAndSortDTO.setSortBy("AAA");
		TypedQuery query = mock(TypedQuery.class);

		when(entityManager.createQuery(anyString(), any())).thenReturn(query);

		when(query.getSingleResult()).thenReturn(new Long("10"));

		var rs = storeOrderDAOImpl.searchStoreOrderWithRoleRT(criteria, null);
		assertNotNull(rs);
	}

	private StoreOrderCriteria buildCriteria(Status status) {
		StoreOrderCriteria criteria = new StoreOrderCriteria();
		criteria.setPresellTitle("A");
		criteria.setPresellLevelId(1);
		criteria.setStatus(status);
		criteria.setPresellAuthor("A");
		criteria.setStoreNo("1");
		criteria.setFromDueDate(DatetimeUtils.getCurrentSQLDate());
		criteria.setToDueDate(DatetimeUtils.getCurrentSQLDate());
		criteria.setPlannedDis("Y");
		criteria.setUserRole(PresellConstants.USER_GROUP_RETL_ROLE);
		return criteria;
	}
}
