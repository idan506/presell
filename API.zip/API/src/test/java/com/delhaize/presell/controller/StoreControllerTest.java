package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.dto.StoresDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import com.delhaize.presell.service.StoreService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;

public class StoreControllerTest {
	@InjectMocks
	StoreController storeController;

	@Mock
	StoreService storeService;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void searchStore() {
		StoreSearchCriteria criteria = new StoreSearchCriteria();
		criteria.setStrStoreNo("1");
		List<StoresDTO> listReport = new ArrayList<>();
		listReport.add(new StoresDTO(1, "A", "A", 1, "A", "A", DatetimeUtils.getCurrentSQLDate()));
		when(storeService.searchStore(criteria)).thenReturn(listReport);
		Mockito.when(storeService.searchStore(criteria)).thenReturn(listReport);
		var rs = storeController.searchStore(criteria);
		assertNotNull(rs);
	}

	@Test
	void getStoreNumberListSuccess() {
		StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria();
		criteria.setStoreNo("1");
		criteria.setStoreType("A");
		List<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(2);
		when(storeService.getStoreNumberList(criteria)).thenReturn(list);
		var rs = storeController.getStoreNumberList(criteria);
		assertEquals(2, rs.getBody().size());
	}

	@Test
	void getStoreNumberListError() {
		StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria();
		criteria.setStoreNo("1");
		criteria.setStoreType("A");
		when(storeService.getStoreNumberList(criteria)).thenThrow(EntityNotFoundException.class);
		assertThrows(Exception.class, () -> storeController.getStoreNumberList(criteria));
	}

	@Test
	void getStoreTypeListSuccess() {
		List<BusUnitDTO> busUnitDTOs = new ArrayList<>();
		busUnitDTOs.add(new BusUnitDTO("A", "A"));
		when(storeService.getStoreTypeList()).thenReturn(busUnitDTOs);
		var rs = storeController.getStoreTypeList();
		assertEquals(1, rs.getBody().size());
	}

	@Test
	void getStoreTypeListError() {
		when(storeService.getStoreTypeList()).thenThrow(EntityNotFoundException.class);
		assertThrows(Exception.class, () -> storeController.getStoreTypeList());
	}
}
