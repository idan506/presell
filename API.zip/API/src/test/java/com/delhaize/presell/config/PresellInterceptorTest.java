package com.delhaize.presell.config;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.TokenAuthorization;
import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.controller.BuMstrController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.HandlerMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PresellInterceptorTest {

    private String token = "Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6ImhXRk1Scmc3Z19pbzlLVmpXcWQyTXlrdEFqWnVydG9ZaEtUazhKeEFqRTAiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1yNS1BVWliZkJpaTdOZDFqQmViYXhib1hXMCIsImtpZCI6Ik1yNS1BVWliZkJpaTdOZDFqQmViYXhib1hXMCJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8zODNhMjFmYS01YmQwLTRjODYtOWQzOC1iM2Y1MDJjODdlMTUvIiwiaWF0IjoxNjQ1NzYyMjA0LCJuYmYiOjE2NDU3NjIyMDQsImV4cCI6MTY0NTc2NzEyNCwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iXSwiYWlvIjoiQVNRQTIvOFRBQUFBZXVHT0ZnVjcyMXowNTBJcDVGMURnNW9ZNU1ycDVabEowQXBwYmFiN21mMD0iLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IlByZXNlbGwtRGV2IiwiYXBwaWQiOiI2MzkwNzdhNC01MzJkLTQzOGItODZhYy1lZjI4MTNkYjhkYTgiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IkZvcmJlcyIsImdpdmVuX25hbWUiOiJNYWUiLCJpZHR5cCI6InVzZXIiLCJpbl9jb3JwIjoidHJ1ZSIsImlwYWRkciI6IjE5OC4xOTAuMjUuNCIsIm5hbWUiOiJNYWUgRm9yYmVzIiwib2lkIjoiYmY1YzI1OWYtOTc5NC00M2Y2LTgzYzAtZjZjOGIwNjY5M2ExIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTEyNDY5MDkwMi03MDEzMzE5MjMtMTkyNTczNjc5MS0xODExNzUiLCJwbGF0ZiI6IjMiLCJwdWlkIjoiMTAwMzIwMDA3QTBDMDlGOSIsInJoIjoiMC5BVEVBLWlFNk9OQmJoa3lkT0xQMUFzaC1GUU1BQUFBQUFBQUF3QUFBQUFBQUFBQXhBS00uIiwic2NwIjoiZW1haWwgcHJvZmlsZSBVc2VyLlJlYWQgb3BlbmlkIiwic2lnbmluX3N0YXRlIjpbImlua25vd25udHdrIl0sInN1YiI6InNWbFBUVVkzSEFBblZ1Q29QMVdjd2tRV0dwcndQWE5hRmNQN2N0ZW1LVmMiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiRVUiLCJ0aWQiOiIzODNhMjFmYS01YmQwLTRjODYtOWQzOC1iM2Y1MDJjODdlMTUiLCJ1bmlxdWVfbmFtZSI6IjEwNTk4MzRAZGVsaGFpemV0LmNvbSIsInVwbiI6IjEwNTk4MzRAZGVsaGFpemV0LmNvbSIsInV0aSI6IlNOamJ1blVUeDBXRFRfcUt6aTRFQUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfc3QiOnsic3ViIjoiRDdmTE9hZk12c0VVcVBDd3pMMlhoZnllVmlaOVZBR1hEYnFXdEoyMGVOYyJ9LCJ4bXNfdGNkdCI6MTUwODM0MDMzN30.cZhVST7u5aFMU5pzSWqWlkDkOHr02ymEb77dITgBUhBfDtll54cRZxJjjP87wcjxlyVDYOxCFK-uCOqqbgefU9QZnAKZuWNd-JeTpMGdFJ5ZIrkeQuNtJTTEdGQlNs02_tpE8MRzQjawYU43_JUL3VAvRwGq4qCZeuUSQ_cBksCptK_kvIeat8IzHIl9D_8HcAcslyggt_p_gk0GnczProy9kY0gziZ1Wqvunqp0GsRGvz00biijCUtEKrSD8GhZfhPWi6x3d_ImDpoiWC8dOj2vsSz4RWeBopw76_HfUfECdtHKKxs5yFqVmB9K0QXtCxjeRDN0W5jaz5mfIlr0IQ";

    private PresellInterceptor presellInterceptor;
    private TokenAuthorization tokenAuthorization;

    @BeforeEach
    void setup() {
        this.tokenAuthorization = mock(TokenAuthorization.class);
        this.presellInterceptor = new PresellInterceptor(tokenAuthorization);
    }

    @Test
    void testPreHandle() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HandlerMethod handlerMethod = mock(HandlerMethod.class);
        when(request.getMethod()).thenReturn("GET");
        when(request.getRequestURI()).thenReturn("/api/v1/data");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(token);
        Method method = BuMstrController.class.getMethods()[0];
        when(handlerMethod.getMethod()).thenReturn(method);
        UserSSOInfo userSSOInfo = getUserSSOInfo();

        when(tokenAuthorization.validateToken(anyString(), any())).thenReturn(userSSOInfo);

        assertTrue(presellInterceptor.preHandle(request, response, handlerMethod));
    }

    @Test
    void testPreHandleEmptyToken() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HandlerMethod handlerMethod = mock(HandlerMethod.class);
        when(request.getMethod()).thenReturn("GET");
        when(request.getRequestURI()).thenReturn("/api/v1/data");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(null);
        Method method = BuMstrController.class.getMethods()[0];
        when(handlerMethod.getMethod()).thenReturn(method);
        UserSSOInfo userSSOInfo = getUserSSOInfo();

        when(tokenAuthorization.validateToken(anyString(), any())).thenReturn(userSSOInfo);

        assertThrows(Exception.class, () -> presellInterceptor.preHandle(request, response, handlerMethod));
    }

    @Test
    void testPreHandleOptionsMethod() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        HandlerMethod handlerMethod = mock(HandlerMethod.class);
        when(request.getMethod()).thenReturn("OPTIONS");

        assertTrue(presellInterceptor.preHandle(request, response, handlerMethod));
    }

    @Test
    void testPreHandleInvalidHandler() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        BuMstrController invalidHandlerMethod = new BuMstrController(null);
        when(request.getMethod()).thenReturn("GET");

        assertFalse(presellInterceptor.preHandle(request, response, invalidHandlerMethod));
    }

    private UserSSOInfo getUserSSOInfo() {
        var user = new UserSSOInfo();
        user.setUserId("ab036");
        user.setRole(Secured.UserRole.ADMIN);
        user.setStoreNbr(8003);
        user.setTokenExpiryTime(System.currentTimeMillis());
        return user;
    }
}
