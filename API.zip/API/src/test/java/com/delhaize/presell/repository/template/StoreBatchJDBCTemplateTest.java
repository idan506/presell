package com.delhaize.presell.repository.template;

import com.delhaize.presell.entity.PresellStore;
import com.delhaize.presell.entity.PresellStorePK;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class StoreBatchJDBCTemplateTest {
    private StoreBatchJDBCTemplate storeBatchJDBCTemplate;
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    void initSetup() {
        jdbcTemplate = mock(JdbcTemplate.class);
        storeBatchJDBCTemplate = new StoreBatchJDBCTemplate(jdbcTemplate);
    }

    @Test
    void insertStoreTest() throws SQLException {
        Assertions.assertDoesNotThrow(() -> storeBatchJDBCTemplate.batchInsert(new ArrayList<>()));
        var store1 = new PresellStore();
        var pkStore1 = new PresellStorePK();
        pkStore1.setStoreNbr(1);
        pkStore1.setPsellIdNbr(2);
        store1.setStorePk(pkStore1);
        store1.setStoreStatCd("SEC");
        store1.setAddUserId("rparo");
        store1.setModUserId("rparo");
        var listStores = List.of(store1);
        var setter = new StoreBatchJDBCTemplate.StoreBatchInsertPreparedStatementSetter(listStores);
        setter.setValues(mock(PreparedStatement.class), 0);
        Assertions.assertEquals(1, setter.getBatchSize());
        when(jdbcTemplate.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class))).thenReturn(new int[]{});
        Assertions.assertDoesNotThrow(() -> storeBatchJDBCTemplate.batchInsert(List.of(store1)));
    }

    @Test
    void updateStoreTest() throws SQLException {
        Assertions.assertDoesNotThrow(() -> storeBatchJDBCTemplate.batchUpdate(new ArrayList<>()));
        var store1 = new PresellStore();
        var pkStore1 = new PresellStorePK();
        pkStore1.setStoreNbr(1);
        pkStore1.setPsellIdNbr(2);
        store1.setStorePk(pkStore1);
        store1.setStoreStatCd("SEC");
        store1.setAddUserId("rparo");
        store1.setModUserId("rparo");
        var listStores = List.of(store1);
        var setter = new StoreBatchJDBCTemplate.StoreBatchUpdatePreparedStatementSetter(listStores);
        setter.setValues(mock(PreparedStatement.class), 0);
        Assertions.assertEquals(1, setter.getBatchSize());
        when(jdbcTemplate.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class))).thenReturn(new int[]{});
        Assertions.assertDoesNotThrow(() -> storeBatchJDBCTemplate.batchUpdate(listStores));
    }

    @Test
    void deleteStoreTest() throws SQLException {
        Assertions.assertDoesNotThrow(() -> storeBatchJDBCTemplate.batchDelete(new ArrayList<>()));
        var pkStore1 = new PresellStorePK();
        pkStore1.setStoreNbr(1);
        pkStore1.setPsellIdNbr(2);
        var listStorePks = List.of(pkStore1);
        var setter = new StoreBatchJDBCTemplate.StoreBatchDeletePreparedStatementSetter(listStorePks);
        setter.setValues(mock(PreparedStatement.class), 0);
        Assertions.assertEquals(1, setter.getBatchSize());
        when(jdbcTemplate.batchUpdate(anyString(), any(BatchPreparedStatementSetter.class))).thenReturn(new int[]{});
        Assertions.assertDoesNotThrow(() -> storeBatchJDBCTemplate.batchDelete(listStorePks));
    }
}
