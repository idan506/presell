package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class LvlMaintTest {

   @InjectMocks
   LvlMaint lvlMaint;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       lvlMaint.setPsellLvlIdNbr(1);
       assertNotNull(lvlMaint.getPsellLvlIdNbr());
       lvlMaint.setPsellLvlDsc("TEST");
       assertNotNull(lvlMaint.getPsellLvlDsc());
       lvlMaint.setLgclDelFlg("TEST");
       assertNotNull(lvlMaint.getLgclDelFlg());
       lvlMaint.setAddUserId("TEST");
       assertNotNull(lvlMaint.getAddUserId());
       lvlMaint.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(lvlMaint.getAddTs());
       lvlMaint.setModUserId("TEST");
       assertNotNull(lvlMaint.getModUserId());
       lvlMaint.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(lvlMaint.getModTs());

       assertNotEquals(lvlMaint, new LvlMaint());
       System.out.println(lvlMaint.hashCode());
       System.out.println(lvlMaint.toString());
   }
}
