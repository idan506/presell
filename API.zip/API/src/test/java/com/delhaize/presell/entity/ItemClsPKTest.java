package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ItemClsPKTest {

   @InjectMocks
   ItemClsPK itemClsPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       itemClsPk.setPrdtClsTypNbr(1);
       assertNotNull(itemClsPk.getPrdtClsTypNbr());
       itemClsPk.setItemSetNbr(1);
       assertNotNull(itemClsPk.getItemSetNbr());
       itemClsPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(itemClsPk.getItemNbr());
   }
}
