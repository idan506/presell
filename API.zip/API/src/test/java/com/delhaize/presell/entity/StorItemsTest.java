package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class StorItemsTest {

   @InjectMocks
   StorItems storItems;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       storItems.setStorItemsPk(new StorItemsPK());
       assertNotNull(storItems.getStorItemsPk());
       storItems.setItemOrderQty(new java.math.BigDecimal(1));
       assertNotNull(storItems.getItemOrderQty());
       storItems.setAddUserId("TEST");
       assertNotNull(storItems.getAddUserId());
       storItems.setAddTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(storItems.getAddTs());
       storItems.setModUserId("TEST");
       assertNotNull(storItems.getModUserId());
       storItems.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(storItems.getModTs());

       assertNotEquals(storItems, new StorItems());
       System.out.println(storItems.hashCode());
       System.out.println(storItems.toString());
   }
}
