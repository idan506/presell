package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ItmsoqmapPKTest {

   @InjectMocks
   ItmsoqmapPK itmsoqmapPk;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       itmsoqmapPk.setPsellIdNbr(1);
       assertNotNull(itmsoqmapPk.getPsellIdNbr());
       itmsoqmapPk.setItemNbr(new java.math.BigDecimal(1));
       assertNotNull(itmsoqmapPk.getItemNbr());
       itmsoqmapPk.setShipDt(new java.sql.Date(System.currentTimeMillis()));
       assertNotNull(itmsoqmapPk.getShipDt());
       itmsoqmapPk.setPsellClsIdNbr(1);
       assertNotNull(itmsoqmapPk.getPsellClsIdNbr());
   }
}
