package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.dto.StatusDTO;
import com.delhaize.presell.service.StatusService;

public class StatusControllerTest {
	@InjectMocks
	StatusController statusController;
	
	@Mock
	StatusService statusService;

	private UserSSOInfo user;
	
	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
		user = new UserSSOInfo();
		user.setUserId("userId");
		user.setRole(Secured.UserRole.ADMIN);
		user.setStoreNbr(1234);
	}
	
	@Test
	void getStatusForPresell() {
		List<StatusDTO> statusList = new ArrayList<>();
		statusList.add(new StatusDTO("1", "A"));
		statusList.add(new StatusDTO("2", "B"));
		statusList.add(new StatusDTO("3", "C"));
		when(statusService.getStatusForPresell()).thenReturn(statusList);
		var rs = statusController.getStatusForPresell();
		assertEquals(3, rs.getBody().size());
	}
	
	@Test
	void getStatusForStoreOrder() {
		List<StatusDTO> statusList = new ArrayList<>();
		statusList.add(new StatusDTO("1", "A"));
		statusList.add(new StatusDTO("2", "B"));
		statusList.add(new StatusDTO("3", "C"));
		when(statusService.getStatusForStoreOrder(user.getRole())).thenReturn(statusList);
		var rs = statusController.getStatusForStoreOrder(user);
		assertEquals(3, rs.getBody().size());
	}
	
	@Test
	void getStatusForPresellReport() {
		List<StatusDTO> statusList = new ArrayList<>();
		statusList.add(new StatusDTO("1", "A"));
		statusList.add(new StatusDTO("2", "B"));
		statusList.add(new StatusDTO("3", "C"));
		when(statusService.getStatusForPresellReport()).thenReturn(statusList);
		var rs = statusController.getStatusForPresellReport();
		assertEquals(3, rs.getBody().size());
	}
	
}
