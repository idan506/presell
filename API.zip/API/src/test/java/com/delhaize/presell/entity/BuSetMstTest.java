package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class BuSetMstTest {

   @InjectMocks
   BuSetMst buSetMst;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       buSetMst.setBuSetMstPk(new BuSetMstPK());
       assertNotNull(buSetMst.getBuSetMstPk());
       buSetMst.setItemSetNbr(1);
       assertNotNull(buSetMst.getItemSetNbr());
       buSetMst.setVendSetNbr(1);
       assertNotNull(buSetMst.getVendSetNbr());

       assertNotEquals(buSetMst, new BuSetMst());
       System.out.println(buSetMst.hashCode());
       System.out.println(buSetMst.toString());
   }
}
