package com.delhaize.presell.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.StoreOrderItemDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.dto.ItemsDTO;
import com.delhaize.presell.dto.PresellDetailDTO;
import com.delhaize.presell.dto.StoreDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.request.AddItemCommentForm;
import com.delhaize.presell.dto.request.ItemSearchCriteria;
import com.delhaize.presell.service.ItemService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;

public class ItemControllerTest {
	@InjectMocks
	ItemController itemController;

	@Mock
	ItemService itemService;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void getListItemReportSuccess() {
		List<ItemProjection> listItems = new ArrayList<>();
		listItems.add(new ItemProjection() {
			@Override
			public BigDecimal getItemNbr() {
				return null;
			}

			@Override
			public BigDecimal getItemOrderQty() {
				return null;
			}

			@Override
			public String getItemDsc() {
				return null;
			}

			@Override
			public Date getShipDt() {
				return null;
			}

			@Override
			public BigDecimal getItemCapCst() {
				return null;
			}

			@Override
			public BigDecimal getItemSzCnt() {
				return null;
			}

			@Override
			public String getItemSzCd() {
				return null;
			}

			@Override
			public Integer getItemPkQty() {
				return null;
			}

			@Override
			public BigDecimal getRtlPrc() {
				return null;
			}

			@Override
			public BigDecimal getPsellGrmrgAmt() {
				return null;
			}

			@Override
			public String getPsellItemCmtTxt() {
				return null;
			}

			@Override
			public String getItemImgUrl() {
				return null;
			}

			@Override
			public Integer getPsellClsIdNbr() {
				return null;
			}

			@Override
			public String getPsellLvlClsCd() {
				return null;
			}

			@Override
			public BigDecimal getSuggOrderQty() {
				return null;
			}

		});
		when(itemService.getListItemReport(anyInt())).thenReturn(listItems);
		var rs = itemController.getListItemReport(1);
		assertNotNull(rs);
	}
    @Disabled
	@Test
	void getListItemReportNotFound() {
		when(itemService.getListItemReport(anyInt())).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> itemController.getListItemReport(1));
	}

	@Test
	void addWarhouseItem() {
		ItemSearchCriteria criteria = new ItemSearchCriteria();
		criteria.setItemNbr("12323,1212,2323");
		List<StoreDTO> store = new ArrayList<>();
		store.add(
				new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
		PresellDetailDTO presell = new PresellDetailDTO();
		presell.setPsellIdNbr(1234);
		presell.setStoreDTOList(store);
		presell.setPsellStatCd(Status.SEND_TO_STORES);
		presell.setBusUnitId("Ause");

		when(itemService.getItemDetails(criteria, presell)).thenReturn(presell);
		var rs = itemController.addWarhouseItem(criteria, presell);
		assertNotNull(rs);

	}
@Disabled
	@Test
	void addWarhouseItemNotFound() {
		ItemSearchCriteria criteria = new ItemSearchCriteria();
		criteria.setItemNbr("12323,1212,2323");
		List<StoreDTO> store = new ArrayList<>();
		store.add(
				new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
		PresellDetailDTO presell = new PresellDetailDTO();
		presell.setPsellIdNbr(1234);
		presell.setStoreDTOList(store);
		presell.setPsellStatCd(Status.SEND_TO_STORES);
		presell.setBusUnitId("Ause");

		when(itemService.getItemDetails(criteria, presell)).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> itemController.addWarhouseItem(criteria, presell));
	}

	@Test
	void addDSDItemSuccess() {
		List<StoreDTO> store = new ArrayList<>();
		store.add(
				new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
		PresellDetailDTO presell = new PresellDetailDTO();
		presell.setPsellIdNbr(1234);
		presell.setStoreDTOList(store);
		presell.setPsellStatCd(Status.SEND_TO_STORES);
		presell.setBusUnitId("Ause");
		when(itemService.addDSDItem(presell)).thenReturn(presell);
		var rs = itemController.addDSDItem(presell);
		assertNotNull(rs);
	}
    @Disabled
	@Test
	void addDSDItemError() {
		List<StoreDTO> store = new ArrayList<>();
		store.add(
				new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
		PresellDetailDTO presell = new PresellDetailDTO();
		presell.setPsellIdNbr(1234);
		presell.setStoreDTOList(store);
		presell.setPsellStatCd(Status.SEND_TO_STORES);
		presell.setBusUnitId("Ause");
		when(itemService.addDSDItem(presell)).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> itemController.addDSDItem(presell));
	}

	@Test
	void addItemCommentSuccess() {
		List<StoreDTO> store = new ArrayList<>();
		store.add(
				new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
		PresellDetailDTO presell = new PresellDetailDTO();
		presell.setPsellIdNbr(1234);
		presell.setStoreDTOList(store);
		presell.setPsellStatCd(Status.SEND_TO_STORES);
		presell.setBusUnitId("Ause");

		AddItemCommentForm form = new AddItemCommentForm();
		form.setItemComment("A");
		form.setUserId("rparo");
		form.setSelectedIndex("1");

		when(itemService.addItemComment(form, presell)).thenReturn(presell);
		var rs = itemController.addItemComment(form, presell);
		assertNotNull(rs);
	}
    @Disabled
	@Test
	void addItemCommentError() {
		List<StoreDTO> store = new ArrayList<>();
		store.add(
				new StoreDTO(123, "", "", 11, "", "", DatetimeUtils.getUTCTimestamp(), DBAction.INSERT, DBStatus.NEW));
		PresellDetailDTO presell = new PresellDetailDTO();
		presell.setPsellIdNbr(1234);
		presell.setStoreDTOList(store);
		presell.setPsellStatCd(Status.SEND_TO_STORES);
		presell.setBusUnitId("Ause");

		AddItemCommentForm form = new AddItemCommentForm();
		form.setItemComment("A");
		form.setUserId("rparo");
		form.setSelectedIndex("1");

		when(itemService.addItemComment(form, presell)).thenReturn(null);
		assertThrows(EntityNotFoundException.class, () -> itemController.addItemComment(form, presell));
	}

	@Test
	void getItemOrderDetailsSuccess() {
		StoreOrderItemDTO storeOredr=new StoreOrderItemDTO();
		List<ItemsDTO> listItem = new ArrayList<>();
		listItem.add(new ItemsDTO("A", DatetimeUtils.getCurrentSQLDate(), "A", "A", "A", "A", "A", "A", "A", "A", "A",
				"A", "A", 0, "A", "A", "11",null));
		storeOredr.setItemList(listItem);
		when(itemService.getItemOrderDetails(anyInt(), anyInt())).thenReturn(storeOredr);
		var rs = itemController.getItemOrderDetails(1, 1);
		assertNotNull(rs);
	}

//	@Test
//	void getItemOrderDetailsNotFound() {
//		when(itemService.getItemOrderDetails(1, 1)).thenReturn(null);
//		assertThrows(EntityNotFoundException.class, () -> itemController.getItemOrderDetails(1, 1));
//	}

	@Test
	void getItemOrderDetailsError() {
		when(itemService.getItemOrderDetails(null, null)).thenThrow(NullPointerException.class);
		assertThrows(Exception.class, () -> itemController.getItemOrderDetails(null, null));
	}

}
