package com.delhaize.presell;



import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresellApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
