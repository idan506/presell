package com.delhaize.presell.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class StrFlagsTest {

   @InjectMocks
   StrFlags strFlags;

   @BeforeEach
   public void Start() {
       MockitoAnnotations.initMocks(this);
   }

   @Test
   void createEntityTest() {
       strFlags.setStrFlagsPk(new StrFlagsPK());
       assertNotNull(strFlags.getStrFlagsPk());
       strFlags.setStoreFlg("TEST");
       assertNotNull(strFlags.getStoreFlg());
       strFlags.setModUserId("TEST");
       assertNotNull(strFlags.getModUserId());
       strFlags.setModPgmId("TEST");
       assertNotNull(strFlags.getModPgmId());
       strFlags.setModTs(new java.sql.Timestamp(System.currentTimeMillis()));
       assertNotNull(strFlags.getModTs());

       assertNotEquals(strFlags, new StrFlags());
       System.out.println(strFlags.hashCode());
       System.out.println(strFlags.toString());
   }
}
