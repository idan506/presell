package com.delhaize.presell.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.delhaize.presell.dto.*;
import com.delhaize.presell.service.impl.PresellLevelServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.dto.projection.StoreProjection;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.entity.LvlMapng;
import com.delhaize.presell.entity.LvlMapngPK;
import com.delhaize.presell.repository.LvlMaintRepository;
import com.delhaize.presell.repository.LvlMapngRepository;
import com.delhaize.presell.repository.StoreRepository;
import com.delhaize.presell.repository.dao.PresellLevelMappingDAO;
import com.delhaize.presell.service.impl.PresellLevelMappingServiceImpl;
import com.delhaize.presell.util.DatetimeUtils;

public class PresellLevelMappingServiceImplTest {

	@InjectMocks
	PresellLevelMappingServiceImpl presellLevelMappingServiceImpl;

	@Mock
	PresellLevelMappingDAO presellLevelMappingDAO;

	@Mock
	StoreRepository storeRepository;

	@Mock
	LvlMapngRepository lvlMapngRepository;

	@Mock
	LvlMaintRepository lvlMaintRepository;

	@Mock
	PresellLevelServiceImpl presellLevelServiceImpl;

	@BeforeEach
	public void Start() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void searchStorePresellLevelMappingWithStoreNo() {
		StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria();
		criteria.setStoreNo("1");

		List<LvlMappingDTO> lvlMaping = new ArrayList<>();
		lvlMaping.add(new LvlMappingDTO(1, 4));
		lvlMaping.add(new LvlMappingDTO(7, 1));
		Integer levelIDNbr = null;
		Integer classIDNbr = null;
		HashMap<Integer, Integer> hmPresellLevel = new HashMap<>();

		List<Integer> listStoreNo = new ArrayList<>();
		for (int i = 1; i < 9993; i++) {
			listStoreNo.add(i);
		}
		when(presellLevelMappingDAO.getPresellLevelStoreList(criteria)).thenReturn(listStoreNo);

		Integer storeNumb = Integer.parseInt(criteria.getStoreNo());
		StorePresellLevelMappingDTO storeOrder = buildDetail();

		when(storeRepository.getStoreDetails(storeNumb)).thenReturn(storeOrder);

		when(lvlMapngRepository.getStorePresellLevelMapping(storeNumb)).thenReturn(lvlMaping);
		List<PresellLevelDTO> level=new ArrayList<>();
		when(presellLevelServiceImpl.getPresellLevel()).thenReturn(level);
		for (int pos = 0; pos < lvlMaping.size(); pos++) {
			levelIDNbr = lvlMaping.get(pos).getLevelId();
			classIDNbr = lvlMaping.get(pos).getClassId();
			hmPresellLevel.put(levelIDNbr, classIDNbr);
		}

		storeOrder.setHmStorePresellLevelMap(hmPresellLevel);
		storeOrder.setListStoreNo(listStoreNo);

		var rs = presellLevelMappingServiceImpl.searchStorePresellLevelMapping(criteria);

		assertEquals(1, rs.size());
	}

	@Test
	public void searchStorePresellLevelMapping() {
		StorePresellLevelMappingCriteria criteria = new StorePresellLevelMappingCriteria();

		List<LvlMappingDTO> lvlMaping = new ArrayList<>();
		lvlMaping.add(new LvlMappingDTO(1, 4));
		lvlMaping.add(new LvlMappingDTO(7, 1));
		Integer levelIDNbr = null;
		Integer classIDNbr = null;
		HashMap<Integer, Integer> hmPresellLevel = new HashMap<>();

		List<Integer> listStoreNo = new ArrayList<>();
		for (int i = 1; i < 9993; i++) {
			listStoreNo.add(i);
		}
		when(presellLevelMappingDAO.getPresellLevelStoreList(criteria)).thenReturn(listStoreNo);

		StorePresellLevelMappingDTO storeOrder = buildDetail();

		when(storeRepository.getStoreDetails(listStoreNo.get(0))).thenReturn(storeOrder);

		when(lvlMapngRepository.getStorePresellLevelMapping(listStoreNo.get(0))).thenReturn(lvlMaping);
		List<PresellLevelDTO> level=new ArrayList<>();
		when(presellLevelServiceImpl.getPresellLevel()).thenReturn(level);
		for (int pos = 0; pos < lvlMaping.size(); pos++) {
			levelIDNbr = lvlMaping.get(pos).getLevelId();
			classIDNbr = lvlMaping.get(pos).getClassId();
			hmPresellLevel.put(levelIDNbr, classIDNbr);
		}

		storeOrder.setHmStorePresellLevelMap(hmPresellLevel);
		storeOrder.setListStoreNo(listStoreNo);

		var rs = presellLevelMappingServiceImpl.searchStorePresellLevelMapping(criteria);

		assertEquals(1, rs.size());
	}

	@Test
	public void saveStorePresellLevelMaping() {
		StorePresellLevelDTO criteria = buildCriteria();
		if (criteria != null) {
			List<LevelDTO> presellLevel = criteria.getPresellLevel();
			if (presellLevel != null) {
				for (int i = 0; i < presellLevel.size(); i++) {
					if (presellLevel.get(i).getAction().equals("Delete")) {
						lvlMapngRepository.deletePreselllevel(presellLevel.get(i).getStoreNbr(),
								presellLevel.get(i).getPsellLvlIdNbr());
					} else if (presellLevel.get(i).getAction().equals("Insert")) {
						var levelMapping = new LvlMapng();
						var levelMappingPK = new LvlMapngPK();
						levelMappingPK.setStoreNbr(presellLevel.get(i).getStoreNbr());
						levelMappingPK.setPsellLvlIdNbr(presellLevel.get(i).getPsellLvlIdNbr());
						levelMapping.setPsellClsIdNbr(presellLevel.get(i).getPsellClsIdNbr());
						levelMapping.setAddUserId(criteria.getUserId());
						levelMapping.setModUserId(criteria.getUserId());
						levelMapping.setAddTs(DatetimeUtils.getUTCTimestamp());
						levelMapping.setModTs(DatetimeUtils.getUTCTimestamp());
						levelMapping.setLvlMapngPk(levelMappingPK);
						when(lvlMapngRepository.saveAndFlush(levelMapping)).thenReturn(levelMapping);
					} else if (presellLevel.get(i).getAction().equals("Update")) {
						int value = 0;
						when(lvlMapngRepository.updatelevelMapping(presellLevel.get(i).getStoreNbr(),
								presellLevel.get(i).getPsellLvlIdNbr(), presellLevel.get(i).getPsellClsIdNbr(),
								criteria.getUserId(), DatetimeUtils.getUTCTimestamp())).thenReturn(value);
					}
				}
			}
		}
		var rs = presellLevelMappingServiceImpl.saveStorePresellLevelMaping(criteria);
		assertNotNull(rs);
	}

	@Test
	public void downloadStorePresellLevelMapping() {
		Date dtCurrentDate = new Date();
		String fileName = "Presell_MAP_" + dtCurrentDate.getTime() + ".xls";

		List<StoreProjection> listStore = new ArrayList<>();
		listStore.add(new StoreProjection() {

			@Override
			public Integer getStoreNbr() {
				// TODO Auto-generated method stub
				return 1;
			}

			@Override
			public String getStoreNam() {
				// TODO Auto-generated method stub
				return "AAAA";
			}

			@Override
			public Integer getPsellLvlIdNbr() {
				// TODO Auto-generated method stub
				return 1;
			}

			@Override
			public String getPsellLvlClsCd() {
				// TODO Auto-generated method stub
				return "AAA";
			}

			@Override
			public String getLocOrgDsc() {
				// TODO Auto-generated method stub
				return "AAA";
			}

			@Override
			public String getGeoRegnCd() {
				// TODO Auto-generated method stub
				return "AAA";
			}
		});
		when(storeRepository.getListStore()).thenReturn(listStore);

		List<StoreProjection> listMapping = new ArrayList<>();
		listMapping.add(new StoreProjection() {

			@Override
			public Integer getStoreNbr() {
				return 1;
			}

			@Override
			public String getStoreNam() {
				return "A";
			}

			@Override
			public Integer getPsellLvlIdNbr() {
				return 1;
			}

			@Override
			public String getPsellLvlClsCd() {
				return "A";
			}

			@Override
			public String getLocOrgDsc() {
				return "A";
			}

			@Override
			public String getGeoRegnCd() {
				return "A";
			}
		});
		
		listMapping.add(new StoreProjection() {

			@Override
			public Integer getStoreNbr() {
				return 1;
			}

			@Override
			public String getStoreNam() {
				return "A";
			}

			@Override
			public Integer getPsellLvlIdNbr() {
				return 1;
			}

			@Override
			public String getPsellLvlClsCd() {
				return "A";
			}

			@Override
			public String getLocOrgDsc() {
				return "A";
			}

			@Override
			public String getGeoRegnCd() {
				return "A";
			}
		});
		
		listMapping.add(new StoreProjection() {

			@Override
			public Integer getStoreNbr() {
				return 2;
			}

			@Override
			public String getStoreNam() {
				return "AA";
			}

			@Override
			public Integer getPsellLvlIdNbr() {
				return 2;
			}

			@Override
			public String getPsellLvlClsCd() {
				return "A";
			}

			@Override
			public String getLocOrgDsc() {
				return "A";
			}

			@Override
			public String getGeoRegnCd() {
				return "A";
			}
		});

		when(storeRepository.getListStoreDownloadDetail()).thenReturn(listMapping);

		List<PresellLevelDTO> listPresellLevel = new ArrayList<>();
		var d1 = new PresellLevelDTO();
		d1.setLevelId(1);
		d1.setLevelDsc("A");
		d1.setFetchTime(DatetimeUtils.getUTCTimestamp());
		listPresellLevel.add(d1);

		when(lvlMaintRepository.getAllPresellLevel()).thenReturn(listPresellLevel);
		var actualRs = presellLevelMappingServiceImpl.downloadStorePresellLevelMapping(fileName);
		assertNotNull(actualRs);

	}

	private StorePresellLevelDTO buildCriteria() {
		StorePresellLevelDTO criteria = new StorePresellLevelDTO();
		criteria.setUserId("rparo");

		List<LevelDTO> levelDTOs = new ArrayList<LevelDTO>();
		levelDTOs.add(new LevelDTO(1, 0, 1, DBAction.DELETE));
		levelDTOs.add(new LevelDTO(1, 0, 2, DBAction.INSERT));
		levelDTOs.add(new LevelDTO(1, 0, 3, DBAction.UPDATE));
		criteria.setPresellLevel(levelDTOs);
		return criteria;
	}

	private StorePresellLevelMappingDTO buildDetail() {
		StorePresellLevelMappingDTO storeDTO = new StorePresellLevelMappingDTO();
		storeDTO.setStoreNbr(1);
		storeDTO.setStoreNam("0001SALISBURY 10");
		storeDTO.setBusUnitId("FDLN");
		storeDTO.setBusUnitDsc("FOOD LION");
		storeDTO.setStoreFlg("N");
		storeDTO.setGeoRegnCd("NC");
		storeDTO.setLocOrgDsc("UNASSIGNED");
		return storeDTO;
	}

}
