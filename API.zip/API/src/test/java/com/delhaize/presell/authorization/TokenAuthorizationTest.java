package com.delhaize.presell.authorization;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

import com.delhaize.presell.cache.TokenAuthorizationCache;
import com.delhaize.presell.constant.AppConstants;
import com.delhaize.presell.dto.AuthorizationDetailsDTO;
import com.delhaize.presell.dto.UserValidationResponseDTO;
import com.delhaize.presell.dto.ValidatedUsersDTO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.delhaize.web.exception.GenericApiException;
import org.springframework.web.client.RestTemplate;

public class TokenAuthorizationTest {

    private String token = "Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6ImhXRk1Scmc3Z19pbzlLVmpXcWQyTXlrdEFqWnVydG9ZaEtUazhKeEFqRTAiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1yNS1BVWliZkJpaTdOZDFqQmViYXhib1hXMCIsImtpZCI6Ik1yNS1BVWliZkJpaTdOZDFqQmViYXhib1hXMCJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8zODNhMjFmYS01YmQwLTRjODYtOWQzOC1iM2Y1MDJjODdlMTUvIiwiaWF0IjoxNjQ1NzYyMjA0LCJuYmYiOjE2NDU3NjIyMDQsImV4cCI6MTY0NTc2NzEyNCwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iXSwiYWlvIjoiQVNRQTIvOFRBQUFBZXVHT0ZnVjcyMXowNTBJcDVGMURnNW9ZNU1ycDVabEowQXBwYmFiN21mMD0iLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IlByZXNlbGwtRGV2IiwiYXBwaWQiOiI2MzkwNzdhNC01MzJkLTQzOGItODZhYy1lZjI4MTNkYjhkYTgiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IkZvcmJlcyIsImdpdmVuX25hbWUiOiJNYWUiLCJpZHR5cCI6InVzZXIiLCJpbl9jb3JwIjoidHJ1ZSIsImlwYWRkciI6IjE5OC4xOTAuMjUuNCIsIm5hbWUiOiJNYWUgRm9yYmVzIiwib2lkIjoiYmY1YzI1OWYtOTc5NC00M2Y2LTgzYzAtZjZjOGIwNjY5M2ExIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTEyNDY5MDkwMi03MDEzMzE5MjMtMTkyNTczNjc5MS0xODExNzUiLCJwbGF0ZiI6IjMiLCJwdWlkIjoiMTAwMzIwMDA3QTBDMDlGOSIsInJoIjoiMC5BVEVBLWlFNk9OQmJoa3lkT0xQMUFzaC1GUU1BQUFBQUFBQUF3QUFBQUFBQUFBQXhBS00uIiwic2NwIjoiZW1haWwgcHJvZmlsZSBVc2VyLlJlYWQgb3BlbmlkIiwic2lnbmluX3N0YXRlIjpbImlua25vd25udHdrIl0sInN1YiI6InNWbFBUVVkzSEFBblZ1Q29QMVdjd2tRV0dwcndQWE5hRmNQN2N0ZW1LVmMiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiRVUiLCJ0aWQiOiIzODNhMjFmYS01YmQwLTRjODYtOWQzOC1iM2Y1MDJjODdlMTUiLCJ1bmlxdWVfbmFtZSI6IjEwNTk4MzRAZGVsaGFpemV0LmNvbSIsInVwbiI6IjEwNTk4MzRAZGVsaGFpemV0LmNvbSIsInV0aSI6IlNOamJ1blVUeDBXRFRfcUt6aTRFQUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfc3QiOnsic3ViIjoiRDdmTE9hZk12c0VVcVBDd3pMMlhoZnllVmlaOVZBR1hEYnFXdEoyMGVOYyJ9LCJ4bXNfdGNkdCI6MTUwODM0MDMzN30.cZhVST7u5aFMU5pzSWqWlkDkOHr02ymEb77dITgBUhBfDtll54cRZxJjjP87wcjxlyVDYOxCFK-uCOqqbgefU9QZnAKZuWNd-JeTpMGdFJ5ZIrkeQuNtJTTEdGQlNs02_tpE8MRzQjawYU43_JUL3VAvRwGq4qCZeuUSQ_cBksCptK_kvIeat8IzHIl9D_8HcAcslyggt_p_gk0GnczProy9kY0gziZ1Wqvunqp0GsRGvz00biijCUtEKrSD8GhZfhPWi6x3d_ImDpoiWC8dOj2vsSz4RWeBopw76_HfUfECdtHKKxs5yFqVmB9K0QXtCxjeRDN0W5jaz5mfIlr0IQ";

    private TokenAuthorization tokenAuthorization;
    private RestTemplate restTemplate;
    private TokenAuthorizationCache cacheService;

    MockedStatic<Instant> instantMockedStatic = mockStatic(Instant.class);

    @BeforeEach
    public void setUp() {
        this.restTemplate = mock(RestTemplate.class);
        this.cacheService = mock(TokenAuthorizationCache.class);
        this.tokenAuthorization = new TokenAuthorization(restTemplate, cacheService);

        ReflectionTestUtils.setField(tokenAuthorization, "clientId", "639077a4-532d-438b-86ac-ef2813db8da8");
        ReflectionTestUtils.setField(tokenAuthorization, "tenantId", "383a21fa-5bd0-4c86-9d38-b3f502c87e15");
        ReflectionTestUtils.setField(tokenAuthorization, "adminObjectId", "ecff5595-57fd-474a-8386-7cb68f8e7b2c");
        ReflectionTestUtils.setField(tokenAuthorization, "retailObjectId", "96324265-dbbe-4146-9423-b9a79aa06af7");
        ReflectionTestUtils.setField(tokenAuthorization, "merchandiseObjectId", "a407b880-2980-4cc3-b810-28aef26cfd81");
    }

    @AfterEach
    void finish() {
        instantMockedStatic.close();
    }

    @Test
    void testValidateTokenWithDecodeFailed() {
        token = "Bearer abc";
        Assertions.assertThrows(Exception.class, () -> {
            tokenAuthorization.validateToken(token, new ArrayList<>());
        });
    }

    @Test
    void testValidateTokenWithTokenExpired() {
        instantMockedStatic.when(Instant::now).thenReturn(Instant.MAX);
        Assertions.assertThrows(Exception.class, () -> {
            tokenAuthorization.validateToken(token, new ArrayList<>());
        });
    }


    @Test
    void testValidateTokenWithTokenNotBelongToPresell() {
        ReflectionTestUtils.setField(tokenAuthorization, "clientId", "d12aa3be-431e-ab0e-5d96f667d77f");
        instantMockedStatic.when(Instant::now).thenReturn(Instant.EPOCH);
        Assertions.assertThrows(Exception.class, () -> {
            tokenAuthorization.validateToken(token, new ArrayList<>());
        });
    }

    @Test
    void test1ValidateTokenWithSuccess() {

        when(cacheService.getTokenDataSet(token)).thenReturn(null);
        doNothing().when(cacheService).setTokenDataSet(eq(token), any());
        String userId = "vn11399";
        String tokenValue = token.substring("Bearer ".length() - 1);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(tokenValue);
        HttpEntity<String> entity = new HttpEntity<>(AppConstants.PARAMETERS, headers);
        AuthorizationDetailsDTO authorizationDetailsDTO = new AuthorizationDetailsDTO();
        authorizationDetailsDTO.setId(userId);
        authorizationDetailsDTO.setUserPrincipalName("userId@test.com");
        ResponseEntity<AuthorizationDetailsDTO> response1 = new ResponseEntity<>(authorizationDetailsDTO, HttpStatus.OK);
        ArrayList<UserValidationResponseDTO> values = new ArrayList <> ();
        UserValidationResponseDTO userValidationResponseDTO1 = new UserValidationResponseDTO();
        userValidationResponseDTO1.setPrincipalId("ecff5595-57fd-474a-8386-7cb68f8e7b2c");
        UserValidationResponseDTO userValidationResponseDTO2 = new UserValidationResponseDTO();
        userValidationResponseDTO2.setPrincipalId("e5e4a92c-bbe5-4fa5-820d-c0a70a73fb16");
        values.add(userValidationResponseDTO1);
        values.add(userValidationResponseDTO2);
        ValidatedUsersDTO validatedUsersDTO = new ValidatedUsersDTO();
        validatedUsersDTO.setValue(values);
        instantMockedStatic.when(Instant::now).thenReturn(Instant.EPOCH);
        ResponseEntity<ValidatedUsersDTO> response2 = new ResponseEntity<ValidatedUsersDTO>(validatedUsersDTO, HttpStatus.OK);
        when(restTemplate.exchange(eq("https://graph.microsoft.com/v1.0/me"), eq(HttpMethod.GET), any(), eq(AuthorizationDetailsDTO.class))).thenReturn(response1);
        String newURL = "https://graph.microsoft.com/beta/users/" + userId + "/appRoleAssignments";
        when(restTemplate.exchange(eq(newURL), eq(HttpMethod.GET), any(), eq(ValidatedUsersDTO.class))).thenReturn(response2);
        UserSSOInfo user = tokenAuthorization.validateToken(token, new ArrayList<>());
        Assertions.assertNotNull(user);
    }
}
