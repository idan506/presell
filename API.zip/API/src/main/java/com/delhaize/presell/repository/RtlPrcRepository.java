package com.delhaize.presell.repository;

import com.delhaize.presell.entity.RtlPrc;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RtlPrcRepository extends JpaRepository<RtlPrc, Integer> {
	
	@Query(value = "SELECT srpAmt "
			+ "FROM RtlPrc "
			+ "WHERE itemNbr = :itemNbr ")
	List<String> fetchSrpItem(@Param("itemNbr") BigDecimal itemNbr);
	
	@Query(value = "SELECT srpAmt, effDt "
			+ "FROM RtlPrc "
			+ "WHERE prcMstrId = :prcMstrId "
			+ "AND prcMstrTypId = :prcMstrTypId "
			+ "AND grpCd = :grpCd "
			+ "AND effDt < :date "
			+ "ORDER BY effDt DESC ")
	List<String> fetchSrpItemPrcMstr(@Param("prcMstrId") String prcMstrId, @Param("prcMstrTypId") String prcMstrTypId,
			@Param("grpCd") Integer grpCd, @Param("date") Date date);
}
