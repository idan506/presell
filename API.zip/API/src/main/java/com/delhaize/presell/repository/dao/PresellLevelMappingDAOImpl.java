package com.delhaize.presell.repository.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Repository
public class PresellLevelMappingDAOImpl implements PresellLevelMappingDAO {

    @PersistenceContext
    EntityManager entityManager;

    private static class SearchStorePresellLevelMappingConstants {
        private static final String SEARCH_STORELIST_QRY = "SELECT DISTINCT " + "TLOC100.storeNbr " + "FROM "
                + "Store TLOC100, " + "Location TLOC001, " + "BuMstr TGEO700 ";

        private static final String SEARCH_STORELIST_QRY_WHERE = "WHERE " + "TLOC001.locSidNbr = TLOC100.storeSidNbr "
                + "AND TLOC001.busUnitId = TGEO700.busUnitId " + "AND TLOC100.storeNbr < 9999 "
                + "AND TLOC100.storeNbr <> 1991 ";
        private static final String SEARCH_STORELIST_QRY_ORDERBY = " ORDER BY TLOC100.storeNbr ";
    }

    @Override
    public List<Integer> getPresellLevelStoreList(StorePresellLevelMappingCriteria criteria) {
        StringBuilder queryString = buildQueryString(criteria);
        log.info("getPresellLevelStoreList");
        log.debug("===========================================================");
        log.debug("Query: {}", queryString);
        log.debug("===========================================================");
        TypedQuery<Integer> query = entityManager.createQuery(queryString.toString(), Integer.class);
        List<Integer> listStoreNo;
        int iFlag = 0;
        String storeNoEntered;
        listStoreNo = query.getResultList();
        if (criteria.getStoreNo() != null && !criteria.getStoreNo().equals(PresellConstants.BLANK)) {
            // if user has entered the store no. then display all store no.
            // with the store no. entered by user should be the displayed first
            storeNoEntered = criteria.getStoreNo();

            for (Integer integer : listStoreNo) {
                if (storeNoEntered.equalsIgnoreCase(String.valueOf(integer))) {
                    iFlag = 1;
                    break;
                }
            }
            if (iFlag == 0) {
                listStoreNo = null; // the entered store no. does not exists
            }
        }

        return listStoreNo;
    }

    private StringBuilder buildQueryString(StorePresellLevelMappingCriteria criteria) {
        log.info("buildQueryString");
        StringBuilder queryString = new StringBuilder(SearchStorePresellLevelMappingConstants.SEARCH_STORELIST_QRY);
        // When the user enters Store Number, get list of all stores
        if (PresellConstants.ALL.equals(criteria.getStoreType())) {
            queryString.append(SearchStorePresellLevelMappingConstants.SEARCH_STORELIST_QRY_WHERE);
        } else {
            String storeFlag = (PresellConstants.IND.equals(criteria.getStoreType())) ? PresellConstants.Y_VALUE
                    : PresellConstants.N_VALUE;
            queryString.append(", StrFlags TLOC101 ");
            queryString.append(SearchStorePresellLevelMappingConstants.SEARCH_STORELIST_QRY_WHERE);
            if (PresellConstants.N_VALUE.equals(storeFlag)) {
                queryString.append("AND TGEO700.parntBusUnitId = '")
                        .append(criteria.getStoreType()).append("'");
            }
            queryString.append(" AND TLOC101.strFlagsPk.flgNam = 'INDEPENDENT-FLAG' " + " AND TLOC101.storeFlg = '")
                    .append(storeFlag)
                    .append("' ")
                    .append(" AND TLOC100.storeSidNbr = TLOC101.strFlagsPk.storeSidNbr");
        }
        queryString.append(SearchStorePresellLevelMappingConstants.SEARCH_STORELIST_QRY_ORDERBY);
        return queryString;
    }

}
