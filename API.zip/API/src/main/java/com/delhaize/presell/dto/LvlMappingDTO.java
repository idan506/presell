package com.delhaize.presell.dto;

import com.delhaize.presell.annotation.QueryProjection;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class LvlMappingDTO {
	private Integer levelId;
	private Integer classId;
}
