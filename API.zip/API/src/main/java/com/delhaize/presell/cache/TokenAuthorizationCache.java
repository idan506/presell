package com.delhaize.presell.cache;

import com.delhaize.presell.authorization.UserSSOInfo;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.concurrent.TimeUnit;

@Log4j2
@Service
public class TokenAuthorizationCache {

    private final RedisTemplate<String, Object> redisTemplate;

    @Autowired
    public TokenAuthorizationCache(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Value("${redis.authorization.hash.private-key}")
    private String privateKey;

    public void setTokenDataSet(String token, UserSSOInfo userSSOInfo) {
        log.info("Store validation data to cache.");
        // calculate timeout based on expiryTime
        long timeInMili = userSSOInfo.getTokenExpiryTime() * 1000 - Instant.now().toEpochMilli();
        log.debug("This cache key will be expired in {} milisec", timeInMili);
        if (timeInMili <= 0) {
            log.info("the token is nearly expired. So ignore caching it");
            return;
        }
        try {
	        ValueOperations<String, Object> values = redisTemplate.opsForValue();
	        // hash token before saving
	        var hashedToken = hashTokenToStoreAsKey(token);
	        values.setIfAbsent(hashedToken, userSSOInfo, timeInMili, TimeUnit.MILLISECONDS);
        } catch (Exception ex) {
            log.error("Could not cache the token validation. The error message: {}", ex.getLocalizedMessage());
        	//there is no problem for this time. We will cache it by another chance later
        }
    }

    public UserSSOInfo getTokenDataSet(String token) {
        log.info("Fetch the user data from cache.");
        try {
	        ValueOperations<String, Object> values = redisTemplate.opsForValue();
	        // hash token to get authorization data
	        var hashedToken = hashTokenToStoreAsKey(token);
	        return (UserSSOInfo) values.get(hashedToken);
        } catch (Exception ex) {
            log.error("Could not get the token validation from the cache. The error message: {}", ex.getLocalizedMessage());
        	//there is no problem for this time. It will be back to the normal process
        	return null;
        }
    }

    private String hashTokenToStoreAsKey(String token) {
        var hashedToken = DigestUtils.sha256Hex(token + privateKey);
        log.debug("Hashed Token: {}", hashedToken);
        return hashedToken;
    }
}
