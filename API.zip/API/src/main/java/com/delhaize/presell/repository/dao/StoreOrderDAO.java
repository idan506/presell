package com.delhaize.presell.repository.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.delhaize.presell.dto.StoreOrderDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;

public interface StoreOrderDAO {
	Page<StoreOrderDTO> searchStoreOrderWithRoleRT(StoreOrderCriteria criteria, Pageable pageable);
	
	Page<StoreOrderDTO> searchStoreOrder(StoreOrderCriteria criteria, Pageable pageable);
}
