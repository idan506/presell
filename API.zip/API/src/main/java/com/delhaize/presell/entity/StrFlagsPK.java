package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class StrFlagsPK implements Serializable {


  @Column(name="STORE_SID_NBR")
  private Integer storeSidNbr;

  @Column(name="FLG_NAM")
  private String flgNam;
}
