package com.delhaize.presell.dto;

import com.delhaize.presell.annotation.QueryProjection;
import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.dto.serialization.WhiteSpaceRemovalSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class AddItemsDTO  {
	private String itemNbr;
	@NotNull
	private Date shippingDate;
	private Date oldShippingDate;
	private String pack;
	private String size;
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String sizeCode;
	private String cost;
	private String costWithCAP;
	private String SRP;
	private String GM;
	private String quantity;
	private List<ItemSOQDTO> itemSOQ;
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String description;
	private String comments;
	private String URL;
	private String displayURL;
	private String cntrbPcnt;
	private DBAction action = DBAction.INACTION;
	private DBStatus status = DBStatus.OLD;
	private String type;
	private String select;
	private String delete;
	private String storeQty;
	private String failureMessage;
	
	public void setAction(DBAction action) {
		this.action = action == null ? DBAction.INACTION : action;
	}
}
