package com.delhaize.presell.dto.request;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.delhaize.presell.constant.Status;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PresellReportSearchCriteria {
	private String presellTitle;

    private Integer presellLevelId;

    private Status status;

    private String presellAuthor;

    private String storeNo;

    @Schema(example = "01/20/2015")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date fromDueDate;

    @Schema(example = "01/20/2021")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date toDueDate;

    private String plannedDis;
    
    private String businessUnit;
    
}
