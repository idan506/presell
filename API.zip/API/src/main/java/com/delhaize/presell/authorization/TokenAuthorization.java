package com.delhaize.presell.authorization;

import com.delhaize.presell.cache.TokenAuthorizationCache;
import com.delhaize.presell.constant.AppConstants;
import com.delhaize.presell.dto.AuthorizationDetailsDTO;
import com.delhaize.presell.dto.UserValidationResponseDTO;
import com.delhaize.presell.dto.ValidatedUsersDTO;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.util.CommonFunctions;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

@Log4j2
@Component
public class TokenAuthorization {

    private final RestTemplate restTemplate;

    private final TokenAuthorizationCache cacheService;

    @Autowired
    public TokenAuthorization(RestTemplate restTemplate, TokenAuthorizationCache cacheService) {
        this.restTemplate = restTemplate;
        this.cacheService = cacheService;
    }

    @Value("${app.client.id}")
    private String clientId;

    @Value("${app.tenant.id}")
    private String tenantId;

    @Value("${psell.service.admin.object.id}")
    private String adminObjectId;

    @Value("${psell.service.retail.object.id}")
    private String retailObjectId;

    @Value("${psell.service.mdse.object.id}")
    private String merchandiseObjectId;

    public UserSSOInfo validateToken(String token, List<Secured.UserRole> permitRoles) {
        List<UserValidationResponseDTO> validatedUsers;
        Secured.UserRole userRole = null;
        boolean isTokenCached = false;
        UserSSOInfo userSSOInfo = cacheService.getTokenDataSet(token);
        log.info(userSSOInfo);

        if (userSSOInfo == null) {
            userSSOInfo = new UserSSOInfo();
            validatedUsers = validateTokenProcess(token, userSSOInfo);
            if (validatedUsers == null || validatedUsers.isEmpty()) {
                throw ExceptionHandlingHelper.newGenericException(ResponseError.USER_UNAUTHORIZED_ERROR);
            }
            if (isAdminRole(validatedUsers)) {
                userRole = Secured.UserRole.ADMIN;
            } else if (isMerchandiseRole(validatedUsers)) {
                userRole = Secured.UserRole.MERCHUSER;
            } else if (isPresellRetailRole(validatedUsers)) {
                userRole = Secured.UserRole.RETAIL;
            } else {
                log.info("Not supported");
            }
        } else {
            isTokenCached = true;
            userRole = userSSOInfo.getRole();
        }
        if (userRole != null && (permitRoles.contains(userRole) || permitRoles.isEmpty())) {
            log.info("Token Validated !!!!!!!!!!!!: ");
            userSSOInfo.setRole(userRole);
            if (!isTokenCached) {
                // cache user data as token key
                cacheService.setTokenDataSet(token, userSSOInfo);
            }
            return userSSOInfo;
        }
        throw ExceptionHandlingHelper.newGenericException(ResponseError.USER_UNAUTHORIZED_ERROR);
    }

    private List<UserValidationResponseDTO> validateTokenProcess(String authorization, UserSSOInfo userSSOInfo) {

        log.info("Start validate token process");
        JsonNode actualObj;
        try {
            String payload = authorization.split("\\.")[1];
            String d = new String(Base64.decodeBase64(payload), StandardCharsets.UTF_8);
            ObjectMapper mapper = new ObjectMapper();
            actualObj = mapper.readValue(d, JsonNode.class);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.DECODE_TOKEN_EXCEPTION, e);
        }

        String claimTenantId = "tid";
        String tenant = actualObj.get(claimTenantId).asText();
        String claimAppId = "appid";
        String client = actualObj.get(claimAppId).asText();
        String claimExpTime = "exp";
        long expiryTime = actualObj.get(claimExpTime).asLong();

        userSSOInfo.setTokenExpiryTime(expiryTime);

        //check if the token was expired or not
        expiryTime = expiryTime * 1000;
        long now = Instant.now().toEpochMilli();
        if (now >= expiryTime) {
            log.error("the token was expired");
            throw ExceptionHandlingHelper.newGenericException(ResponseError.TOKEN_EXPIRED);
        }
        try {
            //verify the tenant id and app id
            if (clientId.equalsIgnoreCase(client) && tenantId.equalsIgnoreCase(tenant)) {

                HttpHeaders headers = new HttpHeaders();
                headers.setAccept(List.of(MediaType.APPLICATION_JSON));
                headers.setBearerAuth(authorization);
                HttpEntity<String> entity = new HttpEntity<>(AppConstants.PARAMETERS, headers);
                log.info("Call URL for Validate ");
                ResponseEntity<AuthorizationDetailsDTO> response = restTemplate.exchange(
                        "https://graph.microsoft.com/v1.0/me", HttpMethod.GET, entity, AuthorizationDetailsDTO.class);

                log.info("Token Validated !!!!!!!!!!!!: ");
                if (response.getStatusCode().equals(HttpStatus.OK)) {
                    AuthorizationDetailsDTO resBody = response.getBody();
                    assert resBody != null;
                    String userId = resBody.getUserPrincipalName().split("@")[0];
                    userSSOInfo.setUserId(userId);
                    String resBodyId = CommonFunctions.filterValidCharacterOfUserId(resBody.getId());
                    // role validation code
                    String newURL = "https://graph.microsoft.com/beta/users/" + resBodyId + "/appRoleAssignments";
                    log.info("Call NEW URL for Validate ");
                    ResponseEntity<ValidatedUsersDTO> response2 = restTemplate.exchange(newURL, HttpMethod.GET, entity,
                            ValidatedUsersDTO.class);
                    return response2.getBody().getValue();
                } else {
                    log.error("Could not get the user profile");
                    throw ExceptionHandlingHelper.newGenericException(ResponseError.FETCH_USER_PROFILE_FAILED);
                }
            } else {
                log.error("Either client id or tenant id is invalid");
                throw ExceptionHandlingHelper.newGenericException(ResponseError.TOKEN_NOT_FOR_SI);
            }
        } catch (Exception ex) {
            log.error("Problem when trying to connect key vault.");
            log.error(ex.getMessage());
            throw ExceptionHandlingHelper.newGenericException(ResponseError.CAN_NOT_REACH_KEY_VAULT);
        }
    }

    private boolean isPresellRetailRole(List<UserValidationResponseDTO> validatedUsers) {
        return validatedUsers.stream()
                .anyMatch(normalUserValid -> Objects.equals(normalUserValid.getPrincipalId(), retailObjectId));
    }

    private boolean isAdminRole(List<UserValidationResponseDTO> validatedUsers) {
        return validatedUsers.stream()
                .anyMatch(adminUserValid -> Objects.equals(adminUserValid.getPrincipalId(), adminObjectId));
    }

    private boolean isMerchandiseRole(List<UserValidationResponseDTO> validatedUsers) {
        return validatedUsers.stream()
                .anyMatch(adminUserValid -> Objects.equals(adminUserValid.getPrincipalId(), merchandiseObjectId));
    }
}
