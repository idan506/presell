package com.delhaize.presell.service.impl;

import com.delhaize.presell.dto.projection.LocOrgProjection;
import com.delhaize.presell.dto.projection.StateProjection;
import com.delhaize.presell.repository.AddressRepository;
import com.delhaize.presell.repository.LocOrgRepository;
import com.delhaize.presell.service.LocationService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Log4j2
@Service
public class LocationServiceImpl implements LocationService {

    private final LocOrgRepository locOrgRepository;

    private final AddressRepository addressRepository;

    @Autowired
    public LocationServiceImpl(LocOrgRepository locOrgRepository, AddressRepository addressRepository) {
        this.locOrgRepository = locOrgRepository;
        this.addressRepository = addressRepository;
    }

    @Override
    public List<LocOrgProjection> getDivisions() {
        log.info("-----Get divisions-----");
        return locOrgRepository.fetchLocations("DV");
    }

    @Override
    public List<LocOrgProjection> getDistricts() {
        log.info("-----Get districts-----");
        return locOrgRepository.fetchLocations("DS");
    }

    @Override
    public List<StateProjection> getStates() {
        log.info("----Get states-----");
        return addressRepository.fetchStates();
    }
}
