package com.delhaize.presell.dto;

import com.delhaize.presell.dto.projection.PresellLogProjection;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PresellStoreDetailDTO {
	private Integer psellIdNbr;
	private Integer psellLvlIdNbr;
	private String busUnitId;
	private String busUnitDsc;
	private String psellDsc;
	@DateTimeFormat(pattern = "MM/dd/yyyy")
	private Date psellDueDt;
	private String plnDistFlg;
	@DateTimeFormat(pattern = "MM/dd/yyyy")
	private Date rmndrEmailDt;
	private String psellCmtTxt;
	private String psellStatCd;
	private String addUserId;
	private String authorName = "author name";
	private Timestamp addTs;
	private String mSodUserId;
	private Timestamp modTs;
	private String psellLvlDsc;
	private Integer remainingDays;
	private Integer storeNo;
	private String storeStatus;
	private List<ItemsDTO> itemList;
	private List<StoreResultsPresellDTO> hmStoresForAdd;
	private int itemCount;
	private int storeCount;
	private List<ClassificationDTO> classification;
	private List<PresellLogProjection> logs;

}
