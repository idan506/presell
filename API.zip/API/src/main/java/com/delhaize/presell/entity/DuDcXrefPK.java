package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class DuDcXrefPK implements Serializable {


  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;

  @Column(name="DIST_ITEM_SEQ_NBR")
  private Integer distItemSeqNbr;

  @Column(name="DC_SID_NBR")
  private Integer dcSidNbr;
}
