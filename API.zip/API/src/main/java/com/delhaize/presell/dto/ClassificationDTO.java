package com.delhaize.presell.dto;

import com.delhaize.presell.util.DatetimeUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClassificationDTO {

    private Integer classificationId;

    private String classificationDsc;

    private Timestamp fetchTime;

    public ClassificationDTO(Integer classificationId, String classificationDsc) {
        this.classificationId = classificationId;
        this.classificationDsc = classificationDsc;
        this.fetchTime = DatetimeUtils.getUTCTimestamp();
    }
}
