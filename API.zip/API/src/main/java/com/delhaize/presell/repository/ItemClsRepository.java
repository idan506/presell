package com.delhaize.presell.repository;

import com.delhaize.presell.entity.ItemCls;
import com.delhaize.presell.entity.ItemClsPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemClsRepository extends JpaRepository<ItemCls, ItemClsPK> {
}
