package com.delhaize.presell.dto;


import com.delhaize.presell.constant.DBAction;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LevelDTO {

    private int psellClsIdNbr;

    private int storeNbr;

    private int psellLvlIdNbr;

    private DBAction action;
}
