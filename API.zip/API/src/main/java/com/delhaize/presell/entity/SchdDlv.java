package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TORD013_SCHD_DLV")
public class SchdDlv {

  @EmbeddedId
  private SchdDlvPK schdDlvPk;

  @Column(name="BTCH_LOAD_ID")
  private String btchLoadId;

  @Column(name="SCHD_ARRV_DT")
  private java.sql.Date schdArrvDt;

  @Column(name="SCHD_ARRV_TM")
  private java.sql.Time schdArrvTm;

  @Column(name="BTCH_ID")
  private String btchId;

  @Column(name="SCHD_TRNMT_DT")
  private java.sql.Date schdTrnmtDt;

  @Column(name="SCHD_TRNMT_TM")
  private java.sql.Time schdTrnmtTm;

  @Column(name="MSG_CD")
  private String msgCd;

  @Column(name="MLBAG_FLG")
  private String mlbagFlg;

  @Column(name="TEMP_SCHD_FLG")
  private String tempSchdFlg;

  @Column(name="SCHD_DEPRT_DT")
  private java.sql.Date schdDeprtDt;

  @Column(name="SCHD_DEPRT_TM")
  private java.sql.Time schdDeprtTm;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @Column(name="ADD_TS")
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    SchdDlv schdDlv = (SchdDlv) o;
    return schdDlvPk != null && Objects.equals(schdDlvPk, schdDlv.schdDlvPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(schdDlvPk);
  }
}
