package com.delhaize.presell.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class UserValidationResponseDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@JsonProperty
	 private String id;
	
	@JsonProperty
     private String creationTimestamp;
	
	@JsonProperty
     private String appRoleId;
     
	@JsonProperty
     private String principalDisplayName;
	
	@JsonProperty
     private String principalId;
	
	@JsonProperty
     private String principalType;
	
	@JsonProperty
     private String resourceDisplayName;
	
	@JsonProperty
     private String resourceId;
}
