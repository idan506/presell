package com.delhaize.presell.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class ItemSOQDTO  {
    private Integer classificationId;
    private String classificationDsc;
    private BigDecimal quantity;
}
