package com.delhaize.presell.dto;

import java.io.Serializable;

import com.delhaize.presell.annotation.QueryProjection;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class DistcsttypDTO implements Serializable {
	
	private String distCstTypCd;
	private String distCstTypDsc;
	private String distCstRateCd;
	private String cstByDcFlg;
	private String cstByMdeptFlg;
	private String cstBySelwhFlg;
	private String cstByCatgFlg;
	private String cstByStoreFlg;
	private String cstByItemFlg;
}
