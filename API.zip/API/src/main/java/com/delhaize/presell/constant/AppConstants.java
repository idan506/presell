package com.delhaize.presell.constant;

public class AppConstants {

    private AppConstants() {
    }

    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer ";
    public static final String PARAMETERS = "parameters";
    public static final String HTTP_STATUS_MESSAGE_OK = "200 OK";
    public static final String HTTP_STATUS_MESSAGE_BAD_REQUEST = "400 BAD_REQUEST";
    public static final String BAD_INPUT_MESSAGE = "Bad Input Request please try again";
    public static final String BAD_INPUT_DETAILS = "Passed Inputs are not correct";
    public static final String MESSAGE = "message";

    public static final String PRESELL_RETAIL = "RETAIL";
    public static final String PRESELL_ADMIN = "ADMIN";
    public static final String PRESELL_MERCHUSER = "MERCHUSER";

}
