package com.delhaize.presell.repository.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;

public interface PresellReportDAO {
	Page<PresellReportDTO> searchPresellReport(PresellReportSearchCriteria criteria, Pageable pageable);
}
