package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TGEO700_BU_MSTR")
public class BuMstr {


  @Id
  @Column(name="BUS_UNIT_ID")
  private String busUnitId;

  @Column(name="BUS_UNIT_DSC")
  private String busUnitDsc;

  @Column(name="PARNT_BUS_UNIT_ID")
  private String parntBusUnitId;

  @Column(name="PARNT_BUS_UNIT_FLG")
  private String parntBusUnitFlg;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @Column(name="ADD_TS")
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="BUS_UNIT_NBR")
  private Integer busUnitNbr;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    BuMstr buMstr = (BuMstr) o;
    return busUnitId != null && Objects.equals(busUnitId, buMstr.busUnitId);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
