package com.delhaize.presell.constant;

public enum DBStatus {
    OLD,
    NEW
}
