package com.delhaize.presell.service.impl;

import com.delhaize.presell.constant.*;
import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.dto.StoreDTO;
import com.delhaize.presell.dto.StoresDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import com.delhaize.presell.entity.PresellStore;
import com.delhaize.presell.entity.PresellStorePK;
import com.delhaize.presell.repository.PresellStoreRepository;
import com.delhaize.presell.repository.dao.PresellLevelMappingDAO;
import com.delhaize.presell.repository.dao.StoreDAO;
import com.delhaize.presell.repository.template.StoreBatchJDBCTemplate;
import com.delhaize.presell.service.BuMstrService;
import com.delhaize.presell.service.StoreService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@Service
public class StoreServiceImpl implements StoreService {

//    private final PresellStoreRepository presellStoreRepository;
    private final StoreDAO storeDAO;
    private final PresellLevelMappingDAO presellLevelMappingDAO;
    private final BuMstrService buMstrService;
    private final StoreBatchJDBCTemplate storeBatchJDBCTemplate;

    @Autowired
    public StoreServiceImpl(PresellStoreRepository presellStoreRepository, StoreDAO storeDAO, PresellLevelMappingDAO presellLevelMappingDAO, BuMstrService buMstrService, StoreBatchJDBCTemplate storeBatchJDBCTemplate) {
        this.storeDAO = storeDAO;
//        this.presellStoreRepository = presellStoreRepository;
        this.presellLevelMappingDAO = presellLevelMappingDAO;
        this.buMstrService = buMstrService;
        this.storeBatchJDBCTemplate = storeBatchJDBCTemplate;
    }

    @Override
    public List<StoresDTO> searchStore(StoreSearchCriteria criteria) {
        return storeDAO.searchStore(criteria);
    }

    @Override
    @Transactional
    public int insertOrDeleteStore(PresellSaveRequestDTO request) {
        log.info("-----Insert or delete store for presell-----");
        List<PresellStorePK> deleteIds = new ArrayList<>();
        request.getPresellDetail().getStoreDTOList()
                .stream().filter(e -> e.getAction().equals(DBAction.DELETE))
                .forEach(store -> {
                    log.info("Delete item {}", store.getStoreNbr());
                    var pk = new PresellStorePK();
                    pk.setStoreNbr(store.getStoreNbr());
                    pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
                    deleteIds.add(pk);
                });
        storeBatchJDBCTemplate.batchDelete(deleteIds);
        var stores = request.getPresellDetail().getStoreDTOList()
                .stream().filter(e -> !e.getAction().equals(DBAction.DELETE))
                .collect(Collectors.toList());
        List<PresellStore> addStores = new ArrayList<>();
        List<PresellStore> updateStores = new ArrayList<>();
        stores.forEach(store -> {
            String status = "";
            /* Setting the Store Status based on whether the Presell is being saved as draft,
             * 'sent to stores', or auto-order being generated
             */
            if ((request.getAction().equals(SavePresellAction.CREATE_AUTO_ORDER) // auto
                    && !request.getPresellDetail().getPsellStatCd().equals(Status.SEND_TO_STORES))) {
                status = Status.SUBMITTED.getKey();
            } else if (request.getAction().equals(SavePresellAction.SAVE_AS_DRAFT)) {
                status = PresellConstants.ADMIN_SAVE;
            } else if (request.getAction().equals(SavePresellAction.SEND_TO_STORES)) {
                status = Status.SEND_TO_STORES.getKey();
            }

            /* Making changes according to the Store record based on the status
             *  status='OLD'  	Updating Store status
             *  status='NEW'  	Inserting new record
             *  status='DELETE'	Deleting the particular record
             */
            if (store.getStatus().equals(DBStatus.NEW)) {
                addStores.add(getNewPresellStoreEntity(request, store, status));
            } else if (!"".equals(status) && store.getStatus().equals(DBStatus.OLD)) {
                   var pk = new PresellStorePK();
                   pk.setStoreNbr(store.getStoreNbr());
                   pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
                   var entity = new PresellStore();
                   entity.setStorePk(pk);
                   entity.setStoreStatCd(status);
                   entity.setModUserId(request.getUserId());
                   updateStores.add(entity);
            }
        });
        storeBatchJDBCTemplate.batchInsert(addStores);
        storeBatchJDBCTemplate.batchUpdate(updateStores);
        return 1;
    }

    @Override
    @Transactional
    public int saveNewStoresToPresell(PresellSaveRequestDTO request) {
        log.info("----Save new stores to presell-----");
        int rs=0;
        List<PresellStore> addStores = request.getPresellDetail().getStoreDTOList()
                .stream().filter(e -> e.getAction().equals(DBAction.INSERT))
                .map(e -> getNewPresellStoreEntity(request, e, Status.SEND_TO_STORES.getKey()))
                .collect(Collectors.toList());
        storeBatchJDBCTemplate.batchInsert(addStores);
        if(addStores.size()!=0) {
            rs=1;
            log.info("saveNewStoresToPresell********");
        }
        return rs;
    }


    private PresellStore getNewPresellStoreEntity(PresellSaveRequestDTO request, StoreDTO store, String status) {
        var storeEntity = new PresellStore();
        var pk = new PresellStorePK();
        pk.setStoreNbr(store.getStoreNbr());
        pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        storeEntity.setStorePk(pk);
        storeEntity.setStoreStatCd(status);
        storeEntity.setAddUserId(request.getUserId());
        storeEntity.setModUserId(request.getUserId());
        return storeEntity;
    }

    @Override
    public List<Integer> getStoreNumberList(StorePresellLevelMappingCriteria criteria) {
        log.info("-----Get store number list-----");
        return presellLevelMappingDAO.getPresellLevelStoreList(criteria);
    }

    @Override
    public List<BusUnitDTO> getStoreTypeList() {
        log.info("-----Get store type list----");
        List<BusUnitDTO> storeType = new ArrayList<>();

        storeType = buMstrService.getBusUnit();
        var ind = new BusUnitDTO();
        ind.setBusUnitId("IND");
        ind.setBusUnitDsc("Independent");
        storeType.add(ind);

        return storeType;
    }
}
