package com.delhaize.presell.repository;

import com.delhaize.presell.dto.projection.StateProjection;
import com.delhaize.presell.entity.Address;
import com.delhaize.presell.entity.AddressPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AddressRepository extends JpaRepository<Address, AddressPK> {

    @Query("select distinct TLOC003.cntctStCd AS state from Location TLOC001, Address TLOC003, Store TLOC100 " +
            "where TLOC001.locSidNbr = TLOC100.storeSidNbr " +
            "and TLOC001.locSidNbr = TLOC003.addressPk.locSidNbr " +
            "and TLOC001.locTypId = 'ST'")
    List<StateProjection> fetchStates();

}
