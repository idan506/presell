package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TLOC708_LOC_ORG")
public class LocOrg {


  @Id
  @Column(name="LOC_ORG_SID_NBR")
  private Integer locOrgSidNbr;

  @Column(name="LOC_ORG_TYP_ID")
  private String locOrgTypId;

  @Column(name="PARNT_HIER_SID_NBR")
  private Integer parntHierSidNbr;

  @Column(name="LOC_ORG_DSC")
  private String locOrgDsc;

  @Column(name="HIER_NBR")
  private Integer hierNbr;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    LocOrg locOrg = (LocOrg) o;
    return locOrgSidNbr != null && Objects.equals(locOrgSidNbr, locOrg.locOrgSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
