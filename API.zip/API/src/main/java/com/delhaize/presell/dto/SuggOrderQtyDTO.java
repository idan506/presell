package com.delhaize.presell.dto;

import com.delhaize.presell.dto.serialization.IntegerFormattingSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SuggOrderQtyDTO {

    private int presellLevelID;

    private String presellLevelCode;

    @JsonSerialize(using = IntegerFormattingSerializer.class)
    private String suggOrderQty;
}
