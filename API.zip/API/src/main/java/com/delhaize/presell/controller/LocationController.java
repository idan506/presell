package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.projection.LocOrgProjection;
import com.delhaize.presell.dto.projection.StateProjection;
import com.delhaize.presell.service.LocationService;
import com.delhaize.web.exception.EntityNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Log4j2
@CrossOrigin
@RestController
@RequestMapping("/api/v1/location")
@Tag(name = "location", description = "the location API")
public class LocationController {

    private final LocationService locationService;

    @Autowired
    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @Operation(summary = "Get Divisions", tags = { "location" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = LocOrgProjection.class))),
            @ApiResponse(responseCode = "404", description = "Division not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @GetMapping(value = "/division", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<LocOrgProjection>> getDivisions() {
        log.info("getDivisions");
        var rs = locationService.getDivisions();
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get Districts", tags = { "location" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = LocOrgProjection.class))),
            @ApiResponse(responseCode = "404", description = "District not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @GetMapping(value = "/district", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<LocOrgProjection>> getDistricts() {
        log.info("getDistricts");
        var rs = locationService.getDistricts();
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get States", tags = { "location" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = StateProjection.class))),
            @ApiResponse(responseCode = "404", description = "District not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @GetMapping(value = "/state", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<StateProjection>> getStates() {
        log.info("getStates");
        var rs = locationService.getStates();
        return ResponseEntity.ok(rs);
    }
}
