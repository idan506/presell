package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class PuLocXrfPK implements Serializable {


  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;

  @Column(name="VEND_SET_NBR")
  private Integer vendSetNbr;

  @Column(name="VEND_ID")
  private String vendId;

  @Column(name="LOC_SID_NBR")
  private Integer locSidNbr;
}
