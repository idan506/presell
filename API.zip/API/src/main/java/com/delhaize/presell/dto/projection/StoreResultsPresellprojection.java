package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

public interface StoreResultsPresellprojection {
    @Value("#{target.dstrcDsc.trim()}")
    String getDstrcDsc();
    @Value("#{target.storeNam.trim()}")
    String getStoreNam ();

    Integer getStoreNbr();
    String getStoreStatCd();



   }
