package com.delhaize.presell.service.impl;

import com.delhaize.presell.dto.PresellLevelDTO;
import com.delhaize.presell.dto.request.PresellLevelRequestDTO;
import com.delhaize.presell.entity.LvlMaint;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.repository.LvlMaintRepository;
import com.delhaize.presell.service.PresellLevelService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Log4j2
@Service
public class PresellLevelServiceImpl implements PresellLevelService {

    private final LvlMaintRepository lvlMaintRepository;

    @Autowired
    public PresellLevelServiceImpl(LvlMaintRepository lvlMaintRepository) {
        this.lvlMaintRepository = lvlMaintRepository;
    }

    @Override
    @Cacheable(value = "presellLevel")
    public List<PresellLevelDTO> getPresellLevel() {
        log.info("-----Get presell level-----");
        return this.lvlMaintRepository.getAllPresellLevel();
    }

    @Transactional
    @Override
    @CacheEvict(value = "presellLevel", allEntries = true)
    public int deletePresellLevel(PresellLevelRequestDTO request) {
        log.info("-----Delete presell level-----");
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(false);
        var psellLvls = request.getPresellLevelDTOs().stream()
                .map(presellLevelDTO -> {
                    // check data sync before executing query
                    if (!isDataSyncPassed.get()) {
                        isDataSyncPassed.set(checkDataSync(presellLevelDTO));
                    }
                    return lvlMaintRepository.findById(presellLevelDTO.getLevelId());
                })
                .filter(Optional::isPresent)
                .map(lvlMaint -> {
                    var entity = lvlMaint.get();
                    entity.setLgclDelFlg("Y");
                    entity.setModUserId(request.getUserId());
                    return entity;
                }).collect(Collectors.toList());
        lvlMaintRepository.saveAll(psellLvls);
        return 1;
    }

    @Transactional
    @Override
    @CacheEvict(value = "presellLevel", allEntries = true)
    public int insertOrUpdatePresellLevel(PresellLevelRequestDTO request) {
        log.info("-----Insert or update presell level-----");
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(false);
        var lvlMaints = request.getPresellLevelDTOs().stream().map(psellLvl -> {
            LvlMaint newEntity;
            if (psellLvl.getLevelId() == 0) {
                newEntity = getLvlMaint(request, psellLvl);
            } else {
                var entity = lvlMaintRepository.findById(psellLvl.getLevelId());
                if (entity.isPresent()) {
                    // check data sync before executing query
                    if (!isDataSyncPassed.get()) {
                        isDataSyncPassed.set(checkDataSync(psellLvl));
                    }
                    newEntity = entity.get();
                    newEntity.setModUserId(request.getUserId());
                    newEntity.setPsellLvlDsc(psellLvl.getLevelDsc());
                } else {
                    newEntity = getLvlMaint(request, psellLvl);
                }
            }
            return newEntity;
        }).collect(Collectors.toList());

        lvlMaintRepository.saveAll(lvlMaints);
        return 1;
    }

    private LvlMaint getLvlMaint(PresellLevelRequestDTO request, PresellLevelDTO psellLvl) {
        log.info("-----Get lvl maint-----");
        LvlMaint newEntity;
        newEntity = new LvlMaint();
        newEntity.setPsellLvlIdNbr(lvlMaintRepository.getMaxSequence() + 1);
        newEntity.setPsellLvlDsc(psellLvl.getLevelDsc());
        newEntity.setModUserId(request.getUserId());
        newEntity.setAddUserId(request.getUserId());
        newEntity.setLgclDelFlg("N");
        log.info(newEntity);
        return newEntity;
    }

    /**
     * Check if the database has been updated by another session, after
     * The data for this session was fetched.
     * For this the current max timestamp is fetched from database
     * and compared with the time stamp stored in the bean during fetch.
     * If the Database has the latest value of timestamp, the current update is rolled back.
     * And a fresh search is shown to the user.
     *
     * @param presellLevelDTO
     */
    private boolean checkDataSync(PresellLevelDTO presellLevelDTO) {
        log.info("-----Check data sync-----");
        Timestamp maxModDB = lvlMaintRepository.getMaxUpdateTimestamp();
        if (maxModDB.after(presellLevelDTO.getFetchTime())) {
            throw ExceptionHandlingHelper.newGenericException(ResponseError.DATA_SYNC_EXCEPTION);
        }
        return true;
    }

}
