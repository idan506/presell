package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class SchdDlvPK implements Serializable {


  @Column(name="STORE_NBR")
  private Integer storeNbr;

  @Column(name="BUS_UNIT_ID")
  private String busUnitId;

  @Column(name="LOAD_NBR")
  private Integer loadNbr;

  @Column(name="SCHD_BTCH_PROC_DT")
  private java.sql.Date schdBtchProcDt;

  @Column(name="PROD_TYP_CD")
  private String prodTypCd;
}
