package com.delhaize.presell.repository.dao;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Repository
public class PresellReportDAOImpl implements PresellReportDAO {

    @PersistenceContext
    EntityManager entityManager;

    private Page<PresellReportDTO> readPage(final TypedQuery<PresellReportDTO> query, TypedQuery<Long> countQuery,
                                            final Pageable pageable) {
        log.info("readPage");
        try {
            if (pageable != null) {
                query.setFirstResult((int) pageable.getOffset());
                query.setMaxResults(pageable.getPageSize());

                final List<PresellReportDTO> content = query.getResultList();

                normalizeResults(content);

                Long total = countQuery.getSingleResult();

                return new PageImpl<>(content, pageable, total);
            } else {
                var content = query.getResultList();
                normalizeResults(content);
                return new PageImpl<>(content);
            }
        } catch (Exception e) {
            log.error(e);
            throw e;
        }
    }

    private void normalizeResults(List<PresellReportDTO> result) {
        log.info("normalizeResults");
        result.forEach(e -> {
            e.setPsellStatCd(Objects.requireNonNull(Status.findByKey(e.getPsellStatCd())).getStatusDsc());
            e.setPlnDistFlg("Y".equalsIgnoreCase(e.getPlnDistFlg()) ? "Yes" : "No");
        });
    }

    private void buildWhereClause(StringBuilder whereClause, Map<String, Object> parameters,
                                  PresellReportSearchCriteria criteria) {
        log.info("buildWhereClause");
        if (criteria.getPresellTitle() != null) {
            whereClause.append(" AND UPPER(TPSL001.psellDsc) LIKE CONCAT('%',:psellDsc,'%') ");
            parameters.put("psellDsc", criteria.getPresellTitle().toUpperCase());
        }

        if (criteria.getBusinessUnit() != null && !criteria.getBusinessUnit().equalsIgnoreCase(PresellConstants.ALL)) {
            whereClause.append(" AND TPSL001.busUnitId = :busUnitId ");
            parameters.put(SearchPresellReportConstants.BUS_UNIT_ID, criteria.getBusinessUnit());
        }

        buildQueryBasedOnStatus(whereClause, parameters, criteria);

        if (criteria.getPresellAuthor() != null) {
            whereClause.append(" AND TPSL001.addUserId = :addUserId ");
            parameters.put("addUserId", criteria.getPresellAuthor());
        }

        if (criteria.getPresellLevelId() != null) {
            whereClause.append(" AND TPSL001.psellLvlIdNbr = :psellLvlIdNbr ");
            parameters.put("psellLvlIdNbr", criteria.getPresellLevelId());
        }
        if (criteria.getFromDueDate() != null) {
            whereClause.append(" AND TPSL001.psellDueDt >= :fpsellDueDt ");
            parameters.put("fpsellDueDt", criteria.getFromDueDate());
        }

        if (criteria.getToDueDate() != null) {
            whereClause.append(" AND TPSL001.psellDueDt <= :tpsellDueDt ");
            parameters.put("tpsellDueDt", criteria.getToDueDate());
        }

        if (criteria.getPlannedDis() != null) {
            whereClause.append(" AND TPSL001.plnDistFlg = :plnDistFlg ");
            parameters.put(SearchPresellReportConstants.PLN_DIST_FLG, criteria.getPlannedDis());
        }

        if (criteria.getStoreNo() != null) {
            whereClause.append(" AND TPSL001.psellIdNbr IN ( ");
            whereClause.append(
                    " SELECT DISTINCT ps.storePk.psellIdNbr FROM PresellStore ps WHERE ps.storePk.storeNbr = :storeNbr )");
            parameters.put("storeNbr", Integer.valueOf(criteria.getStoreNo()));
        }

    }

    private void buildQueryBasedOnStatus(StringBuilder whereClause, Map<String, Object> parameters, PresellReportSearchCriteria criteria) {
        log.info("buildQueryBasedOnStatus");
        if (criteria.getStatus() != null) {
            var statusSTS = "statusSTS";
            var statusClosed = "statusClosed";
            var statusREC = "statusREC";
            if (Status.ALL.equals(criteria.getStatus())) {
                whereClause.append(" AND TPSL001.psellStatCd IN ( :statusSTS, :statusClosed, :statusREC )");
                parameters.put(statusSTS, Status.SEND_TO_STORES.getKey());
                parameters.put(statusClosed, Status.CLOSED.getKey());
                parameters.put(statusREC, Status.REC_FROM_STORES.getKey());
            } else {
                var parameter = "psellStatCd";
                whereClause.append(" AND TPSL001.psellStatCd = :psellStatCd");
                switch (criteria.getStatus()) {
                    case SEND_TO_STORES:
                        parameters.put(parameter, Status.SEND_TO_STORES.getKey());
                        break;
                    case CLOSED:
                        parameters.put(parameter, Status.CLOSED.getKey());
                        break;
                    case REC_FROM_STORES:
                        parameters.put(parameter, Status.REC_FROM_STORES.getKey());
                        break;
                    default:
                        throw new IllegalArgumentException("Invalid Presell Status!");

                }
            }
        }

    }

    private static class SearchPresellReportConstants {

        private static final String PLN_DIST_FLG = "plnDistFlg";

        private static final String BUS_UNIT_ID = "busUnitId";

        private static final String SELECT_PRESELLREPORT_LISTING = "SELECT NEW com.delhaize.presell.dto.PresellReportDTO("
                + "TPSL001.psellIdNbr, " + "TPSL001.psellDsc, " + "TPSL001.busUnitId, " + "TPSL006.psellLvlDsc, "
                + "TPSL001.psellStatCd, " + "TPSL001.psellDueDt, " + "TPSL001.plnDistFlg, " + "TPSL001.addUserId, " 
                + "'author name') " 
                + "FROM Presell  TPSL001 " + "INNER JOIN LvlMaint TPSL006 "
                + "ON (TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr) " + "WHERE 1 = 1 ";

        private static final String COUNT_PRESELLREPORT_LISTING = "SELECT COUNT(*) " + "FROM Presell  TPSL001 "
                + "INNER JOIN LvlMaint TPSL006 " + "ON (TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr) "
                + "WHERE 1 = 1 ";

        private static final Map<String, String> sortKeysWithRoleRT = new HashedMap<>();

        static {
            sortKeysWithRoleRT.put("presellDsc", "TPSL001.psellDsc");
            sortKeysWithRoleRT.put(BUS_UNIT_ID, "TPSL001.busUnitId");
            sortKeysWithRoleRT.put("storeStatCd", "TPSL003.storeStatCd");
            sortKeysWithRoleRT.put("presellLvlDsc", "TPSL006.psellLvlDsc");
            sortKeysWithRoleRT.put("presellDueDt", "TPSL001.psellDueDt");
            sortKeysWithRoleRT.put(PLN_DIST_FLG, "TPSL001.plnDistFlg");
        }

        private static final Map<String, String> sortKeys = new HashedMap<>();

        static {
            sortKeys.put("presellDsc", "TPSL001.psellDsc");
            sortKeys.put(BUS_UNIT_ID, "TPSL001.busUnitId");
            sortKeys.put("presellLvlDsc", "TPSL006.psellLvlDsc");
            sortKeys.put("presellStatCd", "TPSL001.psellStatCd");
            sortKeys.put("presellDueDt", "TPSL001.psellDueDt");
            sortKeys.put(PLN_DIST_FLG, "TPSL001.plnDistFlg");
        }
    }

    @Override
    public Page<PresellReportDTO> searchPresellReport(PresellReportSearchCriteria criteria, Pageable pageable) {
        log.info("searchPresellReport");
        StringBuilder queryString = new StringBuilder(SearchPresellReportConstants.SELECT_PRESELLREPORT_LISTING);
        StringBuilder queryCountString = new StringBuilder(SearchPresellReportConstants.COUNT_PRESELLREPORT_LISTING);
        StringBuilder whereClause = new StringBuilder();
        Map<String, Object> parameters = new HashedMap<>();

        buildWhereClause(whereClause, parameters, criteria);

        queryString.append(whereClause);
        queryCountString.append(whereClause);
        if (pageable != null) {
            queryString.append(" ORDER BY ");
            pageable.getSort().forEach(order ->
                    queryString.append(SearchPresellReportConstants.sortKeys.get(order.getProperty())).append(" ")
                            .append(order.getDirection()).append(", ")
            );
            // remove redundant comma
            queryString.append(" TPSL001.psellIdNbr ").append(pageable.getSort().toList().get(0).getDirection());
        } else {
            queryString.append(" ORDER BY TPSL001.psellIdNbr ASC ");
        }
        log.info("Query" + queryString);
        // prepare the search presell query
        TypedQuery<PresellReportDTO> query = entityManager.createQuery(queryString.toString(), PresellReportDTO.class);
        parameters.forEach(query::setParameter);

        // prepare the count all elements query
        TypedQuery<Long> countQuery = entityManager.createQuery(queryCountString.toString(), Long.class);
        parameters.forEach(countQuery::setParameter);

        return readPage(query, countQuery, pageable);
    }

}
