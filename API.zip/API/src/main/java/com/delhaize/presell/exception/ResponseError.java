package com.delhaize.presell.exception;

import org.springframework.http.HttpStatus;

public enum ResponseError {
    TOKEN_REQUIRED(HttpStatus.BAD_REQUEST, "The bearer token is required!"),
    BEARER_TOKEN_INVALID(HttpStatus.BAD_REQUEST, "The bearer token is invalid."),
    TOKEN_EXPIRED(HttpStatus.UNAUTHORIZED, "Access Denied. Token has expired."),
    CAN_NOT_REACH_KEY_VAULT(HttpStatus.UNAUTHORIZED, "Can not reach key vault. Please try later"),
    TOKEN_NOT_FOR_SI(HttpStatus.UNAUTHORIZED, "Token Authentication Exception. The token used does not belong to the StoreInvoicing app."),
    FETCH_USER_PROFILE_FAILED(HttpStatus.INTERNAL_SERVER_ERROR, "User Profile Exception. There was an error fetching the profile of the logged in user."),
    DECODE_TOKEN_EXCEPTION(HttpStatus.BAD_REQUEST, "Token Authentication Exception. The provided token could not be decoded."),
    USER_UNAUTHORIZED_ERROR(HttpStatus.UNAUTHORIZED, "Access Denied. You are not authorized to access this resource."),
    DATA_SYNC_EXCEPTION(HttpStatus.CONFLICT, "Data sync exception. Fail to perform this action. Please refresh search and try again."),
    EXPORT_EXCEL_FILE_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Data Export Exception. Failed to export the data to excel file"),
    DELETE_PRESELL_LEVEL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to delete presell level."),
    INSERT_OR_UPDATE_PRESELL_LEVEL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to add or update presell level."),
    DELETE_CLASSIFICATION_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to delete classification level."),
    INSERT_OR_UPDATE_CLASSIFICATION_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to add or update classification level."),
    DELETE_PRESELL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to delete presell."),
    SEND_TO_ADDTIONAL_STORE_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Send To Additional Store Error."),
    GET_PRESELL_DETAILS_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to get presell details."),
    GET_PRESELL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Presell entity does not exist!."),
    STORE_ORDER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to get store-order details."),
    ITEM_ORDER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to get Items-order details."),
    SAVE_STORE_PRESELL_LEVELMAPPING_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to save store presell level mapping."),
	SAVE_EDIT_STORE_QUANTITY(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to save edit store quantity."),
	GET_STORE_LIST_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to get store list."),
	GET_STORE_LIST_DOWNLOAD_DETAILS_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to get store list download details."),
	GET_PRESELL_REPORT_DETAILS_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to get presell report details.");
    private final HttpStatus code;
    private final String message;

    ResponseError(HttpStatus code, String message) {
        this.code = code;
        this.message = message;
    }

    public HttpStatus getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }

}
