package com.delhaize.presell.util;

import com.delhaize.presell.constant.PresellConstants;

import java.text.DecimalFormat;

public class CommonFunctions {
    private CommonFunctions() {

    }

    public static boolean arrayNotEmpty(String[] arr) {
        boolean boNotEmpty = false;
        if (arr != null) {
            int iLength = arr.length;
            for (int iIndex = 0; iIndex < iLength; iIndex++) {
                if ((arr[iIndex] != null) && !arr[iIndex].equalsIgnoreCase(PresellConstants.ALL)) {
                    boNotEmpty = true;
                    break;
                }
            }
        }
        return boNotEmpty;
    }

    public static void appendParamsStringValue(String[] arr, StringBuilder strbAppendQuery) {

        int length = arr.length;
        boolean boAppendComma = false;

        for (int count = 0; count < length && arr[count] != null; count++) {
            if (count > 0 && boAppendComma) {
                strbAppendQuery.append(PresellConstants.COMMA);
            }
            if (!arr[count].equalsIgnoreCase(PresellConstants.ALL)) {
                strbAppendQuery.append("'" + arr[count] + "'");
                boAppendComma = true;
            } else {

                continue;
            }
        }
    }

    public static String getPrescisionUptoTwoDecimalPlaces(Double dbDecimall) {
        if (dbDecimall == 0) {
            return "0.00";
        }
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(dbDecimall);
    }

    public static String filterValidCharacterOfToken(String inputStr) {
        StringBuilder validStr = new StringBuilder();
        for (int i = 0; i < inputStr.length(); i++) {
            char c = inputStr.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.')
                validStr.append(c);
        }
        return validStr.toString();
    }

    public static String filterValidCharacterOfUserId(String id) {
        StringBuilder validId = new StringBuilder();
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-')
                validId.append(c);
        }
        return validId.toString();
    }
    
    public static String filterValidCharacterOfUserIdSSO(String id) {
        StringBuilder validId = new StringBuilder();
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
                validId.append(c);
        }
        return validId.toString();
    }
}