package com.delhaize.presell.repository;

import com.delhaize.presell.dto.PresellLevelDTO;
import com.delhaize.presell.entity.LvlMaint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface LvlMaintRepository extends JpaRepository<LvlMaint, Integer> {

    @Query(value = "SELECT DISTINCT new com.delhaize.presell.dto.PresellLevelDTO(psellLvlIdNbr, TRIM(psellLvlDsc)) FROM LvlMaint WHERE lgclDelFlg = 'N'")
    List<PresellLevelDTO> getAllPresellLevel();

    @Query("select max(lm.psellLvlIdNbr) from LvlMaint lm")
    Integer getMaxSequence();

    @Query("select max(lm.modTs) from LvlMaint lm where lm.lgclDelFlg = 'N'")
    Timestamp getMaxUpdateTimestamp();

    @Query(value = "SELECT DISTINCT psellLvlIdNbr AS levelId FROM LvlMaint WHERE lgclDelFlg = 'N'")
    List<Integer> getIntListPresellLevelId();

    @Query(value = "SELECT max(TRIM(psellLvlDsc)) FROM LvlMaint WHERE lgclDelFlg = 'N' AND psellLvlIdNbr = :psellLvlIdNbr")
    String getPresellLevelDscForId(@Param("psellLvlIdNbr") Integer psellLvlIdNbr);
}
