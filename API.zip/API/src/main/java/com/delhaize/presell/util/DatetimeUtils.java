package com.delhaize.presell.util;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.util.timefuncs.Day;
import com.delhaize.presell.util.timefuncs.TimeFunctions;

import lombok.extern.log4j.Log4j2;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.GregorianCalendar;

import static com.delhaize.presell.constant.PresellConstants.MM_DD_YYYY;

@Log4j2
public class DatetimeUtils {

	private DatetimeUtils() {

	}

	public static Timestamp getUTCTimestamp() {
		return Timestamp.from(Instant.now());
	}

	public static Date getCurrentSQLDate() {
		return new Date(System.currentTimeMillis());
	}

	/**
	 * Calculates days between two dates, returning an int.
	 * 
	 * @param presellDueDate
	 * @param currentDate
	 * @return the days between the two dates
	 */
	public static int dayBetween(java.util.Date presellDueDate, java.util.Date currentDate) {

//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
//        String dueDate = df.format(presellDueDate);
//        String curDate = df.format(currentDate);
//        /* Converting date to Java8 Local date*/
//        LocalDate endtDate = LocalDate.parse(dueDate);
//        LocalDate startDate = LocalDate.parse(curDate);
//        // Range = End date - Start date
//        long range = ChronoUnit.DAYS.between(startDate, endtDate);
//        log.info("Number of days between the start date : " + startDate + " and end date : " + endtDate + " is  ==> "
//                + range);
//        return (int) range;

		return Double.valueOf(diffNumberUnits(presellDueDate, currentDate, new Day())).intValue();
	}

	public static Date getInvalidDate() {
		try {
			return new Date(new SimpleDateFormat(MM_DD_YYYY).parse(PresellConstants.DATE_INVALID_FORMAT).getTime());
		} catch (ParseException e) {
			log.error(e);
			return null;
		}
	}

	public static boolean isInvalidDate(java.util.Date date) {
		try {
			return new java.util.Date(
					new SimpleDateFormat(MM_DD_YYYY).parse(PresellConstants.DATE_INVALID_FORMAT).getTime())
							.compareTo(date) == 0;
		} catch (ParseException e) {
			log.error(e);
			return false;
		}
	}

	public static Date convertToSQLDate(java.util.Date utilDate) {
		return new Date(utilDate.getTime());
	}

	public static double diffNumberUnits(java.util.Date dtFromDate, java.util.Date dtToDate, TimeFunctions tf) {
		if (dtFromDate == null || dtToDate == null) {
			throw new IllegalArgumentException("From date or to date is null.");
		}
		GregorianCalendar calStartDt = new GregorianCalendar();
		calStartDt.clear();
		calStartDt.setTime(dtFromDate);
		GregorianCalendar calEndDt = new GregorianCalendar();
		calEndDt.clear();
		calEndDt.setTime(dtToDate);
		long millisecs = calEndDt.getTime().getTime() - calStartDt.getTime().getTime();
		double dblDiff = tf.getNumberOfTimeUnits(millisecs);

		return dblDiff;
	}

}
