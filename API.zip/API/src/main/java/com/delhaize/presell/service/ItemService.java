package com.delhaize.presell.service;

import java.util.List;

import com.delhaize.presell.dto.ItemsDTO;
import com.delhaize.presell.dto.PresellDetailDTO;
import com.delhaize.presell.dto.StoreOrderItemDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.request.AddItemCommentForm;
import com.delhaize.presell.dto.request.ItemSearchCriteria;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;


public interface ItemService {
	List<ItemProjection> getListItemReport(Integer psellIdNbr);
	
	PresellDetailDTO getItemDetails(ItemSearchCriteria criteria, PresellDetailDTO presellDetailDTO);
	
	PresellDetailDTO addDSDItem(PresellDetailDTO presellDetailDTO);
	
	PresellDetailDTO addItemComment(AddItemCommentForm form, PresellDetailDTO presellDetailDTO);

	int insertOrUpdateItemForPresell(PresellSaveRequestDTO request);

	StoreOrderItemDTO getItemOrderDetails(Integer psellIdNbr, Integer storeNbr);
}
