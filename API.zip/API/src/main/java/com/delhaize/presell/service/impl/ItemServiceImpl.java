package com.delhaize.presell.service.impl;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.PresellLogProjection;
import com.delhaize.presell.dto.request.AddItemCommentForm;
import com.delhaize.presell.dto.request.ItemSearchCriteria;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.entity.Items;
import com.delhaize.presell.entity.ItemsPK;
import com.delhaize.presell.entity.Itmsoqmap;
import com.delhaize.presell.entity.ItmsoqmapPK;
import com.delhaize.presell.repository.*;
import com.delhaize.presell.repository.template.SOQBatchJDBCTemplate;
import com.delhaize.presell.service.ItemService;
import com.delhaize.presell.util.CommonFunctions;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.GenericApiException;
import lombok.extern.log4j.Log4j2;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Log4j2
@Service
public class ItemServiceImpl implements ItemService {

    private final ItemsRepository itemsRepository;

    private final DistcsttypRepository distcsttypRepository;

    private final DistCostRepository distCostRepository;

    private final DuCntrRepository duCntrRepository;

    private final BaseItemRepository baseItemRepository;

    private final RtlPrcRepository rtlPrcRepository;

    private final ItmsoqmapRepository itmsoqmapRepository;

    private final PreselLogRepository preselLogRepository;

    private final SOQBatchJDBCTemplate soqBatchJDBCTemplate;
    private final PresellStoreRepository presellStoreRepository;

    private final PresellRepository presellRepository;
    private final LvlMapngRepository lvlMapngRepository;
    private final LvlClassRepository lvlClassRepository;
    private final PresellReportServiceImpl presellReportServiceImpl;

    @Autowired
    public ItemServiceImpl(ItemsRepository itemsRepository, DistcsttypRepository distcsttypRepository,
                           DistCostRepository distCostRepository, DuCntrRepository duCntrRepository,
                           BaseItemRepository baseItemRepository, RtlPrcRepository rtlPrcRepository,
                           ItmsoqmapRepository itmsoqmapRepository, PreselLogRepository preselLogRepository,
                           SOQBatchJDBCTemplate soqBatchJDBCTemplate, PresellRepository presellRepository,
                           LvlMapngRepository lvlMapngRepository, LvlClassRepository lvlClassRepository, PresellReportServiceImpl presellReportServiceImpl, PresellStoreRepository presellStoreRepository) {
        this.itemsRepository = itemsRepository;
        this.distcsttypRepository = distcsttypRepository;
        this.distCostRepository = distCostRepository;
        this.duCntrRepository = duCntrRepository;
        this.baseItemRepository = baseItemRepository;
        this.rtlPrcRepository = rtlPrcRepository;
        this.itmsoqmapRepository = itmsoqmapRepository;
        this.preselLogRepository = preselLogRepository;
        this.soqBatchJDBCTemplate = soqBatchJDBCTemplate;
        this.presellRepository = presellRepository;
        this.lvlMapngRepository = lvlMapngRepository;
        this.lvlClassRepository = lvlClassRepository;
        this.presellReportServiceImpl = presellReportServiceImpl;
        this.presellStoreRepository = presellStoreRepository;
    }

    @Override
    public List<ItemProjection> getListItemReport(Integer psellIdNbr) {
        return itemsRepository.getListItem(psellIdNbr);
    }

    @Override
    public PresellDetailDTO getItemDetails(ItemSearchCriteria criteria, PresellDetailDTO presellDetailDTO) {
        log.info("Get item details");
        List<AddItemsDTO> listItems = presellDetailDTO.getItemDTOList();
        if (listItems == null) {
            listItems = new ArrayList<>();
        }

        // Picking up the Item Number
        String itemNbrs = criteria.getItemNbr();
        String[] arrItemNbr = itemNbrs.split(",");
        List<String> arrItemsSelected = new ArrayList<>();
        for (String s : arrItemNbr) {
            if (s.trim().length() != 0) {
                arrItemsSelected.add(s.trim());
            }
        }

        // Getting Business Unit
        String busUnit = presellDetailDTO.getBusUnitId();

        // Getting Item details
        List<AddItemsDTO> listNotFoundItems = new ArrayList<>();
        for (String itemNbr : arrItemsSelected) {
            AddItemsDTO addItem = fetchItemDetails(busUnit, itemNbr);
            if (addItem != null && addItem.getFailureMessage() == null) {
                addItem.setItemNbr(itemNbr);
                addItem.setStatus(DBStatus.NEW);
                addItem.setCost(PresellConstants.NULL_DECIMAL.toString());
                addItem.setGM(PresellConstants.NULL_DECIMAL.toString());
                addItem.setCntrbPcnt(PresellConstants.NULL_DECIMAL.toString());

                listItems.add(addItem);
                presellDetailDTO.setItemDTOList(listItems);
            } else {
                listNotFoundItems.add(addItem);
                presellDetailDTO.setItemNotFoundList(listNotFoundItems);
            }
        }

        // Calculate Item Count
        if (presellDetailDTO.getItemDTOList() != null
                && !PresellConstants.NULL_INTEGER.equals(presellDetailDTO.getItemDTOList().size())) {
            presellDetailDTO.setItemCount((presellDetailDTO.getItemDTOList().size()));
        }

        return presellDetailDTO;
    }

    public AddItemsDTO fetchItemDetails(String busUnit, String itemNbr) {
        log.info("Fetch item details");
        BigDecimal itemNumber = new BigDecimal(itemNbr);
        AddItemsDTO addItemDTO;
        log.info("------itemsRepository.getItemDetails(itemNumber)-------");
        addItemDTO = itemsRepository.getItemDetails(itemNumber);// 1
        if (addItemDTO == null) {
            addItemDTO = new AddItemsDTO();
            addItemDTO.setFailureMessage("Item Nbr. is no longer Active : ");
            addItemDTO.setItemNbr(itemNbr);
        } else if (addItemDTO.getFailureMessage() == null) {
            log.info("------itemsRepository.getDCIds(busUnit, itemNumber)-------");
            List<DcDTO> listDc = itemsRepository.getDCIds(busUnit, itemNumber);// 2
            if (listDc != null && !listDc.isEmpty()) {
                calcSRP(busUnit, itemNbr, itemNumber, addItemDTO, listDc);
            } else {
                addItemDTO.setFailureMessage("DC not set for Item Nbr : " + itemNbr);
                addItemDTO.setItemNbr(itemNbr);
            }
        }
        return addItemDTO;
    }

    private void calcSRP(String busUnit, String itemNbr, BigDecimal itemNumber, AddItemsDTO addItemDTO,
                         List<DcDTO> listDc) {
        String itemCost = null;
        for (DcDTO dcDTO : listDc) {
            String dcId = dcDTO.getDcId();
            String dcSidNbr = dcDTO.getDcSidNbr();
            String vendorId = null;
            log.info("------itemsRepository.getVendorId(itemNumber, Integer.parseInt(dcSidNbr))-------");
            List<VendorInfoDTO> listVendorId = itemsRepository.getVendorId(itemNumber, Integer.parseInt(dcSidNbr));// 3
            if (!listVendorId.isEmpty()) {
                vendorId = listVendorId.get(0).getVendorId();
                log.info("vendor id: " + vendorId);
            } else {
                // if reporting vendor is not found go and fetch for the next reporting vendor
                continue;
            }

            Date currentDate = new Date(new Date().getTime());
            itemCost = calcItemCostWH(itemNbr, vendorId, dcId, dcSidNbr, currentDate);
            if (itemCost != null) {
                break;
            }
        }
        if (itemCost != null) {
            // do st
            addItemDTO.setCostWithCAP(
                    CommonFunctions.getPrescisionUptoTwoDecimalPlaces(Double.parseDouble(itemCost.trim())));

            /* Fetching SRP for Item */
            String itemSRP = calcItemSRP(itemNbr, busUnit);
            if (itemSRP != null) {
                addItemDTO
                        .setSRP(CommonFunctions.getPrescisionUptoTwoDecimalPlaces(Double.parseDouble(itemSRP.trim())));
            } else {
                addItemDTO.setSRP(PresellConstants.BLANK);
            }
        } else {
            addItemDTO.setFailureMessage("Cost not available for Item");
            addItemDTO.setItemNbr(itemNbr);
            addItemDTO.setCostWithCAP(PresellConstants.NULL_DECIMAL.toString());
        }
    }

    public String calcItemCostWH(String itemNbr, String vendorId, String dcId, String dcSidNbr, Date dateOfCost) {

        List<String> list = null;
        String vendorSetNbr = null;
        String itemCost = null;
        String itemDealAmt = null;
        String netItemCost = null;
        String costMstrId = null;

        vendorSetNbr = getVendorSetNbr(dcId);

        if (vendorId != null && 0 != vendorId.length()) {
            costMstrId = getCostMstrId(itemNbr, vendorId, dcSidNbr, vendorSetNbr, costMstrId);
        } else {
            try {
                BigDecimal itemNumber = new BigDecimal(itemNbr);
                log.info(
                        "------itemsRepository.fetchCostMstrIdForReportVendorId(itemNumber, Integer.parseInt(dcSidNbr),Integer.parseInt(vendorSetNbr))-------");
                list = itemsRepository.fetchCostMstrIdForReportVendorId(itemNumber, Integer.parseInt(dcSidNbr),
                        Integer.parseInt(vendorSetNbr));
                String[] arr = list.get(0).split(",");

                if (arr[0] != null) {
                    costMstrId = arr[0].trim();
                }
                if (arr[1] != null) {
                    vendorId = arr[1].trim();
                }
            } catch (Exception e) {
                log.warn("Cost master id for reporting vendor not found");
            }
        }

        String bracketNbr = getBracketNbr(vendorId, dcSidNbr, dateOfCost, vendorSetNbr);

        if (costMstrId == null || 0 == costMstrId.length()) {
            itemCost = getItemCostDetail(itemNbr, vendorId, dcSidNbr, dateOfCost, vendorSetNbr, bracketNbr);
            itemDealAmt = getDealAmt(itemNbr, vendorId, dcSidNbr, vendorSetNbr, itemDealAmt);
        } else {
            itemCost = getCstMstrCostDetail(vendorId, dcSidNbr, dateOfCost, vendorSetNbr, costMstrId, bracketNbr);
            itemDealAmt = getCstMstrDealDetails(vendorId, dcSidNbr, vendorSetNbr, itemDealAmt, costMstrId);
        }
        if (itemCost == null)
            return null;
        if (Double.parseDouble(itemCost) <= 0.0) {
            return PresellConstants.NULL_DECIMAL.toString();
        }

        return calItemCostWH1(itemNbr, dcSidNbr, itemCost, itemDealAmt, netItemCost);
    }

    private String calItemCostWH1(String itemNbr, String dcSidNbr, String itemCost, String itemDealAmt,
                                  String netItemCost) {
        List<String> list = new ArrayList<>();
        double dbCostWithDeal = getDbCostWithDeal(itemCost, itemDealAmt);

        /* Calculating CAP Factor */
        Double dbNetCAPFactor = 0.0;

        try {
            String cstGrpCd = "DIST";
            log.info("------distcsttypRepository.fetchDistCodeType-------");
            List<DistcsttypDTO> listDistCstType = distcsttypRepository.fetchDistCodeType(cstGrpCd);
            String flag = null;
            String mptcAmt = null;

            for (DistcsttypDTO distcsttypDTO : listDistCstType) {
                String cstType = distcsttypDTO.getDistCstTypCd();
                String cap = "0";
                String cstDaysCnt = "0";
                switch (cstType.trim()) {
                    case "CAPRED":
                    case "CSTCAPI":
                    case "MERCH": {
                        BigDecimal itemNumber = new BigDecimal(itemNbr);
                        log.info("------distCostRepository.fetchCAPFactorCapCstMer-------");
                        list = distCostRepository.fetchCAPFactorCapCstMer(cstType, Integer.parseInt(dcSidNbr), itemNumber);
                        if (!list.isEmpty()) {
                            String[] arr = list.get(0).split(",");
                            cap = arr[0].trim();
                            cstDaysCnt = arr[1].trim();
                        }
                        break;
                    }
                    case "HNDLCAS":
                    case "HNDLCUB":
                    case "OCCUPCY": {
                        BigDecimal itemNumber = new BigDecimal(itemNbr);
                        log.info("------distCostRepository.fetchCAPFactorHndCasCubOcc-------");
                        list = distCostRepository.fetchCAPFactorHndCasCubOcc(cstType, Integer.parseInt(dcSidNbr),
                                itemNumber, Integer.parseInt(dcSidNbr));
                        if (!list.isEmpty()) {
                            String[] arr = list.get(0).split(",");
                            cap = arr[0].trim();
                            cstDaysCnt = arr[1].trim();
                        }
                        break;
                    }
                    case "DELIVRY":
                        log.warn("Cost type == DELIVRY. No processing done for this cost type.");
                        break;
                    default:
                        break;
                }
                checkEmptyCAPAmout(list);

                // Calculating the CAP amt. for each Cost type
                Double dbCAPAmt = null;
                String cstRateCD = distcsttypDTO.getDistCstRateCd();

                switch (cstRateCD.trim()) {
                    case "CAPI":
                        dbCAPAmt = (dbCostWithDeal * Double.parseDouble(cap) * Double.parseDouble(cstDaysCnt)) / 100;

                        break;
                    case "CUBE":
                    case "OCCU":
                        dbCAPAmt = calcDBCapAmt(itemNbr, cap, cstDaysCnt, dbCAPAmt, cstRateCD);
                        break;
                    default:
                        dbCAPAmt = Double.parseDouble(cap);
                        if (cstRateCD.trim().equals("MPCT")) {
                            flag = "Y";
                            mptcAmt = cap;
                        }
                        break;
                }

                dbNetCAPFactor = dbNetCAPFactor + dbCAPAmt;
            }

            Double dbMaxCAP = calcMaxCAPFactor(dbCostWithDeal, flag, mptcAmt);

            dbNetCAPFactor = calCAPWithMaxCAP(dbNetCAPFactor, dbMaxCAP);

            // Obtaining cost with CAP
            Double dbCostWithCAP = dbCostWithDeal + dbNetCAPFactor;
            netItemCost = dbCostWithCAP.toString();

        } catch (Exception e) {
            log.warn("Dist cost type not found");
        }

        return netItemCost;
    }

    private void checkEmptyCAPAmout(List<String> list) {
        if (list.isEmpty()) {
            log.warn("CAP amount not found");
        }
    }

    private Double calcDBCapAmt(String itemNbr, String cap, String cstDaysCnt, Double dbCAPAmt, String cstRateCD) {
        List<String> list;
        double dbSellUnitCube;
        BigDecimal itemNumber = new BigDecimal(itemNbr);
        log.info("------duCntrRepository.fetchSellUnitCube-------");
        list = duCntrRepository.fetchSellUnitCube(itemNumber, 1, 1, "CASE");
        if (!list.isEmpty()) {
            String[] arr = list.get(0).split(",");
            dbSellUnitCube = Double.parseDouble(arr[1]);
            if (cstRateCD.trim().equals("CUBE")) {
                dbCAPAmt = Double.parseDouble(cap) * dbSellUnitCube;
            } else if (cstRateCD.trim().equals("OCCU")) {
                dbCAPAmt = Double.parseDouble(cap) * dbSellUnitCube * Double.parseDouble(cstDaysCnt);
            }
        } else {
            log.warn("Sell unit cube not found");
        }
        return dbCAPAmt;
    }

    private Double calCAPWithMaxCAP(Double dbNetCAPFactor, Double dbMaxCAP) {
        // Comparing calculated CAP with max CAP
        if (dbNetCAPFactor > dbMaxCAP) {
            dbNetCAPFactor = dbMaxCAP;
        } else if (dbNetCAPFactor < 0.0) {
            dbNetCAPFactor = 0.0;
        }
        return dbNetCAPFactor;
    }

    private double getDbCostWithDeal(String itemCost, String itemDealAmt) {
        double dbCostWithDeal;
        if (itemDealAmt != null) {
            dbCostWithDeal = Double.parseDouble(itemCost) + Double.parseDouble(itemDealAmt);
        } else {
            dbCostWithDeal = Double.parseDouble(itemCost);
        }
        return dbCostWithDeal;
    }

    private String getCstMstrDealDetails(String vendorId, String dcSidNbr, String vendorSetNbr, String itemDealAmt,
                                         String costMstrId) {
        List<String> list;
        String alwMultiplier;
        // Get CstMstr Deal Details
        try {
            log.info("------itemsRepository.fetchCstmstrDealDetails-------");
            list = itemsRepository.fetchCstmstrDealDetails(costMstrId, vendorId, Integer.parseInt(vendorSetNbr),
                    Integer.parseInt(dcSidNbr));
            String[] arr = list.get(0).split(",");
            itemDealAmt = arr[0].trim();
            alwMultiplier = arr[2].trim();
            Double dbNetDealAmt = Double.parseDouble(itemDealAmt) * Double.parseDouble(alwMultiplier);
            itemDealAmt = dbNetDealAmt.toString().trim();
        } catch (Exception e) {
            log.warn("Item deal amount not found");
        }
        return itemDealAmt;
    }

    private String getCstMstrCostDetail(String vendorId, String dcSidNbr, Date dateOfCost, String vendorSetNbr,
                                        String costMstrId, String bracketNbr) {
        List<String> list;
        String itemCost = null;
        // Get CstMstr Cost Details
        try {
            log.info("------itemsRepository.fetchCstmstrCostDetails-------");
            list = itemsRepository.fetchCstmstrCostDetails(costMstrId, vendorId, Integer.parseInt(vendorSetNbr),
                    Integer.parseInt(dcSidNbr), Integer.parseInt(bracketNbr));
            if (list != null) {
                log.info("=====================: " + list.size());
                String[] arr = list.get(0).split(",");
                itemCost = arr[1].trim();
                // log.info("=====================: " + list);
                log.info("=====================: " + itemCost);
            }

        } catch (SQLException e) {
            log.warn("Item cost not found:   " + e.getMessage());
            return null;
        } catch (Exception e) {
            log.warn("Item cost not found:   " + e.getMessage());
            return null;
        }
        return itemCost;
    }

    private String getDealAmt(String itemNbr, String vendorId, String dcSidNbr, String vendorSetNbr,
                              String itemDealAmt) {
        List<String> list;
        String alwMultiplier;
        // Get item deal detail
        try {
            BigDecimal itemNumber = new BigDecimal(itemNbr);
            log.info("------itemsRepository.fetchItemDealDetails-------");
            list = itemsRepository.fetchItemDealDetails(itemNumber, vendorId, Integer.parseInt(vendorSetNbr),
                    Integer.parseInt(dcSidNbr));
            String[] arr = list.get(0).split(",");
            itemDealAmt = arr[0].trim();
            alwMultiplier = arr[4].trim();
            Double dbNetDealAmt = Double.parseDouble(itemDealAmt) * Double.parseDouble(alwMultiplier);
            itemDealAmt = dbNetDealAmt.toString().trim();
        } catch (Exception e) {
            log.warn("Item deal amount not found");
        }
        return itemDealAmt;
    }

    private String getItemCostDetail(String itemNbr, String vendorId, String dcSidNbr, Date dateOfCost,
                                     String vendorSetNbr, String bracketNbr) {
        List<String> list;
        String itemCost;
        // Get item cost detail
        try {
            BigDecimal itemNumber = new BigDecimal(itemNbr);
            log.info("------itemsRepository.fetchItemCostDetails-------");
            list = itemsRepository.fetchItemCostDetails(itemNumber, vendorId, Integer.parseInt(vendorSetNbr),
                    Integer.parseInt(bracketNbr), Integer.parseInt(dcSidNbr), dateOfCost);
            String[] arr = list.get(0).split(",");
            itemCost = arr[1].trim();
        } catch (Exception e) {
            log.warn("Item cost not found");
            return null;
        }
        return itemCost;
    }

    private String getBracketNbr(String vendorId, String dcSidNbr, Date dateOfCost, String vendorSetNbr) {
        List<String> list;
        String bracketNbr = null;
        try {
            log.info("------itemsRepository.fetchDefaultBracketNumber-------");
            list = itemsRepository.fetchDefaultBracketNumber(vendorId, Integer.parseInt(vendorSetNbr),
                    Integer.parseInt(dcSidNbr), dateOfCost);
            if (list != null) {
                bracketNbr = list.get(0).trim();
            }
        } catch (Exception e) {
            log.warn("Bracket number not found");
            bracketNbr = "1";
        }
        return bracketNbr;
    }

    private String getCostMstrId(String itemNbr, String vendorId, String dcSidNbr, String vendorSetNbr,
                                 String costMstrId) {
        List<String> list;
        try {
            BigDecimal itemNumber = new BigDecimal(itemNbr);
            log.info("------itemsRepository.fetchCostMstrId-------");
            list = itemsRepository.fetchCostMstrId(itemNumber, vendorId, Integer.parseInt(vendorSetNbr),
                    Integer.parseInt(dcSidNbr));
            if (list.get(0) != null) {
                costMstrId = (list.get(0)).trim();
            }
        } catch (Exception e) {
            log.warn("Vendor cost master id not found");
        }
        return costMstrId;
    }

    private String getVendorSetNbr(String dcId) {
        List<String> list;
        String vendorSetNbr;
        try {
            log.info("------itemsRepository.fetchSidNumber-------");
            list = itemsRepository.fetchSidNumber(dcId);// 4
            String[] arr = list.get(0).split(",");
            vendorSetNbr = arr[4].trim();
        } catch (Exception e) {
            log.warn("Vendor set numbers not found");
            throw new GenericApiException(HttpStatus.NOT_FOUND, "Vendor set numbers not found");
        }
        return vendorSetNbr;
    }

    private Double calcMaxCAPFactor(Double dbCostWithDeal, String flag, String mptcAmt) {
        // Calculating Max CAP factor
        Double dbMaxCAP = null;
        if (flag != null && flag.equals("Y")) {
            dbMaxCAP = (dbCostWithDeal * Double.parseDouble(mptcAmt)) / 100;
        } else {
            dbMaxCAP = 999999999.99;
        }
        return dbMaxCAP;
    }

    public String calcItemSRP(String itemNbr, String busUnit) {
        String itemSRP = null;
        String prcMstrId = null;
        try {
            BigDecimal itemNumber = new BigDecimal(itemNbr);
            log.info("------baseItemRepository.fetchPrcMstrItem-------");
            List<String> mstrItem = baseItemRepository.fetchPrcMstrItem(itemNumber);
            if (!mstrItem.isEmpty()) {
                String[] arr = mstrItem.get(0).split(",");
                prcMstrId = arr[0].trim();
                if ("null".equalsIgnoreCase(prcMstrId))
                    prcMstrId = null;
                log.info("prcMstrId: " + prcMstrId);
            } else {
                log.warn("Price master id not found");
            }
            // log.info("****prcMstrId: " + prcMstrId);
            if (prcMstrId == null) {
                itemNumber = new BigDecimal(itemNbr);
                log.info("------rtlPrcRepository.fetchSrpItem-------");
                List<String> list = rtlPrcRepository.fetchSrpItem(itemNumber);
                itemSRP = list.get(0);
            } else {
                Date currentDate = new Date(new java.util.Date().getTime());
                log.info("------rtlPrcRepository.fetchSrpItemPrcMstr-------");
                List<String> list = rtlPrcRepository.fetchSrpItemPrcMstr(prcMstrId, "H",
                        busUnit.equals(PresellConstants.SWEETBAY) ? 50 : 1, currentDate);
                String[] arr = list.get(0).split(",");
                if (arr[0] != null) {
                    itemSRP = arr[0].trim();
                }
            }

        } catch (Exception e) {
            // SRP is not available
            log.warn("SRP is not available ");
        }
        return itemSRP;
    }

    @Override
    public PresellDetailDTO addDSDItem(PresellDetailDTO presellDetailDTO) {
        log.info("Add DSD item");
        List<AddItemsDTO> listItem = new ArrayList<>();
        if (presellDetailDTO == null) {
            presellDetailDTO = new PresellDetailDTO();

        } else {
            if (presellDetailDTO.getItemDTOList() != null) {
                listItem = presellDetailDTO.getItemDTOList();
            }
        }

        AddItemsDTO addItem = new AddItemsDTO();
        addItem.setItemNbr(PresellConstants.DSD);

        addItem.setSize(PresellConstants.NULL_DECIMAL.toString());
        addItem.setSizeCode(PresellConstants.BLANK);
        addItem.setCost(PresellConstants.NULL_DECIMAL.toString());
        addItem.setCostWithCAP(PresellConstants.NULL_DECIMAL.toString());
        addItem.setPack(PresellConstants.NULL_INTEGER.toString());
        addItem.setGM(PresellConstants.NULL_DECIMAL.toString());
        addItem.setCntrbPcnt(PresellConstants.NULL_DECIMAL.toString());

        addItem.setType(PresellConstants.DSD);
        addItem.setStatus(DBStatus.NEW);

        listItem.add(addItem);

        presellDetailDTO.setItemDTOList(listItem);

        // Calculate Item Count
        if (presellDetailDTO.getItemDTOList() != null
                && !PresellConstants.NULL_INTEGER.equals(presellDetailDTO.getItemDTOList().size())) {
            presellDetailDTO.setItemCount((presellDetailDTO.getItemDTOList().size()));
        }
        return presellDetailDTO;
    }

    @Override
    public PresellDetailDTO addItemComment(AddItemCommentForm form, PresellDetailDTO presellDetailDTO) {
        log.info("Add item comment");
        String userId = form.getUserId();
        String index = form.getSelectedIndex();
        String itemComment = form.getItemComment().trim();

        List<AddItemsDTO> listItem = presellDetailDTO.getItemDTOList();
        AddItemsDTO addItem = listItem.get(Integer.parseInt(index) - 1);
        if (addItem != null) {
            addItem.setComments(itemComment);
            String status = String.valueOf(addItem.getStatus());
            if (!PresellConstants.NEW.equals(status)) {
                updateItemComments(presellDetailDTO.getPsellIdNbr(), addItem, userId);
            }
            listItem.set((Integer.parseInt(index) - 1), addItem);
        }
        return presellDetailDTO;
    }

    private void updateItemComments(int presellId, AddItemsDTO addItem, String userID) {
        log.info("Update item comment");
        try {
            BigDecimal itemNumber = new BigDecimal(addItem.getItemNbr());
            Date currentDate = new Date(new java.util.Date().getTime());
            SimpleDateFormat sdf11 = new SimpleDateFormat(PresellConstants.YYYY_MM_DD);
            java.sql.Date dtShipDt = java.sql.Date.valueOf(sdf11.format(addItem.getShippingDate()));
            itemsRepository.updateItemComment(addItem.getComments(), userID, currentDate, presellId, itemNumber,
                    dtShipDt);
        } catch (Exception e) {
            log.warn("Problem updating item comment: " + addItem + " for presell " + presellId);
        }
    }

    @Override
    @Transactional
    public int insertOrUpdateItemForPresell(PresellSaveRequestDTO request) {
        log.info("insert/update item for presell");
        request.getPresellDetail().getItemDTOList().forEach(item -> {
            if (!item.getAction().equals(DBAction.DELETE)) {
                calcGM(item);
            }

            if (item.getShippingDate() == null) {
                Date shipDate = null;
                try {
                    shipDate = new SimpleDateFormat("MM/dd/yyyy").parse(PresellConstants.DATE_INVALID_FORMAT);
                } catch (ParseException e) {
                    log.error(e);
                }
                item.setShippingDate(shipDate);
            }

            /*
             * Taking appropriate action based on 'strStatus' and 'strAction' attribute for
             * the ItemBean strAction='INSERT' strStatus='NEW' Insert new record for the
             * Item strAction='INSERT' strStatus='OLD' Delete record from the Item + SOQ
             * table and insert new record into Items Table strAction='UPDATE' Updating the
             * Item strAction='DELETE' Deleting item
             */
            if (item.getAction().equals(DBAction.INSERT)) {
                insertItem(request, item);
            } else if (item.getAction().equals(DBAction.UPDATE) || item.getAction().equals(DBAction.INACTION)) {
                updateItem(request, item);
            } else if (item.getAction().equals(DBAction.DELETE) && !item.getStatus().equals(DBStatus.NEW)) {
                log.info("Delete Item");
                Object[] parameters = {request.getPresellDetail().getPsellIdNbr(), new BigDecimal(item.getItemNbr()),
                        item.getShippingDate()};
                deleteItemAndSOQ(parameters);
            }
            insertOrUpdateSOQ(request, item);
        });
        return 0;
    }

    private void insertItem(PresellSaveRequestDTO request, AddItemsDTO item) {
        log.info("Insert Item");
        if (item.getStatus().equals(DBStatus.NEW)) {
            insertNewItem(request, item);
        } else if (item.getStatus().equals(DBStatus.OLD)) {
            log.info("Old Item: Delete it And Insert again.");
            Object[] parameters = {request.getPresellDetail().getPsellIdNbr(), new BigDecimal(item.getItemNbr()),
                    item.getOldShippingDate()};
            deleteItemAndSOQ(parameters);

            Items itemEntity = createItemEntity(request, item);
            itemsRepository.saveAndFlush(itemEntity);
        }
    }

    private void calcGM(AddItemsDTO item) {
        /* Calculating GM% */
        String itemCost = item.getCostWithCAP();
        String itemSRP = item.getSRP();
        String itemPack = "1";

        if (!isDSDItem(item)) {
            itemPack = item.getPack();
        }

        BigDecimal GM = new BigDecimal(0).setScale(2, RoundingMode.CEILING);
        if (itemSRP != null && itemCost != null) {
            // ((itemSRP - itemCost)/itemPack)  / itemSRP * 100
            log.info("((itemSRP({}) - itemCost({}))/itemPack({}))  / itemSRP({}) * 100", itemSRP, itemCost, itemPack, itemSRP);
            GM = BigDecimal.valueOf((Double.parseDouble(itemSRP) - Double.parseDouble(itemCost) / Double.parseDouble(itemPack))
                    / Double.parseDouble(itemSRP) * 100);
        }
        item.setGM(GM.toString());
        log.info("GM: {}", item.getGM());
    }

    private void updateItem(PresellSaveRequestDTO request, AddItemsDTO item) {
        log.info("Update Item");
        var itemPk = new ItemsPK();
        itemPk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        itemPk.setItemNbr(new BigDecimal(item.getItemNbr()));
        itemPk.setShipDt(DatetimeUtils.convertToSQLDate(item.getShippingDate()));

        var itemEntity = itemsRepository.findById(itemPk).orElse(null);
        if (itemEntity != null) {
            setItemSzCzd(item, itemEntity);
            itemEntity.setItemCapCst((item.getCostWithCAP() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                    : new BigDecimal(item.getCostWithCAP())).setScale(2, RoundingMode.HALF_EVEN).setScale(2,
                    RoundingMode.HALF_EVEN));
            itemEntity.setRtlPrc((item.getSRP() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                    : new BigDecimal(item.getSRP())).setScale(2, RoundingMode.HALF_EVEN).setScale(2,
                    RoundingMode.HALF_EVEN));
            itemEntity.setPsellGrmrgAmt((item.getGM() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                    : new BigDecimal(item.getGM())).setScale(2, RoundingMode.HALF_EVEN));
            itemEntity.setItemDsc(item.getDescription() == null ? PresellConstants.BLANK : item.getDescription());
            itemEntity.setItemImgUrl(item.getURL() == null ? PresellConstants.BLANK : item.getURL());
            itemEntity.setItemCntrbPct(
                    BigDecimal.valueOf(PresellConstants.NULL_DECIMAL).setScale(2, RoundingMode.HALF_EVEN));
            itemEntity.setModUserId(request.getUserId());
            itemEntity.setPsellItemCmtTxt(item.getComments() == null ? PresellConstants.BLANK : item.getComments());
            itemsRepository.saveAndFlush(itemEntity);
        }
    }

    private void setItemSzCzd(AddItemsDTO item, Items itemEntity) {
        itemEntity.setItemCst(BigDecimal.valueOf(PresellConstants.NULL_DECIMAL));
        itemEntity.setItemSzCnt(item.getSize() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                : new BigDecimal(item.getSize()));
        itemEntity.setItemSzCd(item.getSizeCode() == null ? PresellConstants.BLANK : item.getSizeCode());
        itemEntity
                .setItemPkQty(item.getPack() == null ? PresellConstants.NULL_INTEGER : Integer.valueOf(item.getPack()));
    }

    private void insertNewItem(PresellSaveRequestDTO request, AddItemsDTO item) {
        log.info("New Item: Insert");
        if (isDSDItem(item)) {
            BigDecimal minItemNbr = itemsRepository.getMinItemIdNbr(request.getPresellDetail().getPsellIdNbr());
            int itemNbr;
            if (minItemNbr == null || minItemNbr.compareTo(new BigDecimal("0")) > 0) {
                itemNbr = -100;
            } else {
                itemNbr = minItemNbr.intValue() - 1;
            }
            item.setItemNbr(String.valueOf(itemNbr));
        }

        BigDecimal itemNbr = new BigDecimal(item.getItemNbr());
        int itemNbrScale = itemNbr.scale();
        if (itemNbrScale < 0) {
            itemNbrScale = 0;
            itemNbr = itemNbr.setScale(itemNbrScale);
        }
        item.setItemNbr(itemNbr.toString());
        Items itemEntity = createItemEntity(request, item);
        itemsRepository.saveAndFlush(itemEntity);
    }

    private boolean isDSDItem(AddItemsDTO item) {
        return "0".equalsIgnoreCase(item.getItemNbr()) && DBStatus.NEW.equals(item.getStatus());
    }

    private void insertOrUpdateSOQ(PresellSaveRequestDTO request, AddItemsDTO item) {
        log.info("Insert/Update SOQ");
        Map<Integer, ItemSOQDTO> soq = new HashMap<>();
        item.getItemSOQ().forEach(e -> soq.put(e.getClassificationId(), e));
        List<Itmsoqmap> insertList = new ArrayList<>();
        List<Itmsoqmap> updateList = new ArrayList<>();
        soq.forEach((clsId, itemSOQDTO) -> {
            if (item.getStatus().equals(DBStatus.NEW) && !item.getAction().equals(DBAction.DELETE)) {
                Itmsoqmap itmsoqmap = new Itmsoqmap();
                var pk = new ItmsoqmapPK();
                pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
                pk.setItemNbr(new BigDecimal(item.getItemNbr()));
                pk.setShipDt(DatetimeUtils.convertToSQLDate(item.getShippingDate()));
                pk.setPsellClsIdNbr(clsId);
                itmsoqmap.setItmsoqmapPk(pk);
                itmsoqmap.setSuggOrderQty(
                        itemSOQDTO.getQuantity() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                                : itemSOQDTO.getQuantity());
                itmsoqmap.setAddUserId(request.getUserId());
                itmsoqmap.setModUserId(request.getUserId());
                insertList.add(itmsoqmap);
            } else if (item.getAction().equals(DBAction.UPDATE) && item.getStatus().equals(DBStatus.OLD)) {
                var pk = new ItmsoqmapPK();
                pk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
                pk.setItemNbr(new BigDecimal(item.getItemNbr()));
                pk.setShipDt(DatetimeUtils.convertToSQLDate(item.getShippingDate()));
                pk.setPsellClsIdNbr(clsId);
                var entity = new Itmsoqmap();
                entity.setItmsoqmapPk(pk);
                entity.setSuggOrderQty(
                        itemSOQDTO.getQuantity() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                                : itemSOQDTO.getQuantity());
                entity.setModUserId(request.getUserId());
                updateList.add(entity);
            }
            // batch insert/update
        });
        soqBatchJDBCTemplate.insertSOQ(insertList);
        soqBatchJDBCTemplate.updateSOQ(updateList);
    }

    private void deleteItemAndSOQ(Object[] parameters) {
        log.info("Delete Item And SOQ");
        itmsoqmapRepository.deleteEntityByPk((Integer) parameters[0], (BigDecimal) parameters[1],
                DatetimeUtils.convertToSQLDate((Date) parameters[2]));

        var itemPk = new ItemsPK();
        itemPk.setPsellIdNbr((Integer) parameters[0]);
        itemPk.setItemNbr((BigDecimal) parameters[1]);
        itemPk.setShipDt(DatetimeUtils.convertToSQLDate((Date) parameters[2]));
        itemsRepository.deleteById(itemPk);
    }

    private Items createItemEntity(PresellSaveRequestDTO request, AddItemsDTO item) {
        var itemEntity = new Items();
        var itemPk = new ItemsPK();
        itemPk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        itemPk.setItemNbr(new BigDecimal(item.getItemNbr()));
        itemPk.setShipDt(DatetimeUtils.convertToSQLDate(item.getShippingDate()));
        itemEntity.setItemsPk(itemPk);
        setItemSzCzd(item, itemEntity);
        itemEntity.setItemCapCst((item.getCostWithCAP() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                : new BigDecimal(item.getCostWithCAP())).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setRtlPrc((item.getSRP() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                : new BigDecimal(item.getSRP())).setScale(2, RoundingMode.HALF_EVEN).setScale(2,
                RoundingMode.HALF_EVEN));
        itemEntity.setItemDsc(item.getDescription() == null ? PresellConstants.BLANK : item.getDescription());
        itemEntity.setPsellItemCmtTxt(item.getComments() == null ? PresellConstants.BLANK : item.getComments());
        itemEntity.setPsellGrmrgAmt((item.getGM() == null ? BigDecimal.valueOf(PresellConstants.NULL_DECIMAL)
                : new BigDecimal(item.getGM())).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setItemImgUrl(item.getURL() == null ? PresellConstants.BLANK : item.getURL());
        itemEntity
                .setItemCntrbPct(BigDecimal.valueOf(PresellConstants.NULL_DECIMAL).setScale(2, RoundingMode.HALF_EVEN));
        itemEntity.setAddUserId(request.getUserId());
        itemEntity.setModUserId(request.getUserId());
        return itemEntity;
    }

    @Override
    public StoreOrderItemDTO getItemOrderDetails(Integer psellIdNbr, Integer storeNbr) {
        log.info("Get item order details");
        List<ItemsDTO> list = new ArrayList<>();
        StoreOrderItemDTO itemsData = new StoreOrderItemDTO();
        String preselLvlID = getPresellLvlClasification(psellIdNbr, storeNbr);
        itemsData.setPreselLvlClasification(preselLvlID);
        List<ItemProjection> listStoreItems = itemsRepository.getListStoreItems(psellIdNbr, storeNbr);
//		Map<String, ItemsDTO> itemList = new LinkedHashMap<>();
        if (listStoreItems.size() != 0) {
            list = getListItems(listStoreItems, null);
        } else {
            List<ItemProjection> listItems = itemsRepository.getItemList(psellIdNbr);
            list = getListItems(listItems, preselLvlID);

        }
        itemsData.setItemList(list);
        List<Integer> storeNbrList = new ArrayList<Integer>();
        storeNbrList.add(PresellConstants.CORP_STORE_NBR);
        storeNbrList.add(storeNbr);
        List<PresellLogProjection> logList = preselLogRepository.getLogDetails(psellIdNbr, storeNbrList);
        log.info("*******logList************" + logList.size());
        itemsData.setLogs(logList);

        return itemsData;

    }

    public List<ItemsDTO> getListItems(List<ItemProjection> listStoreItems, String preselLvlID) {
        log.info("getListItems method ");
        List<ItemsDTO> list = new ArrayList<>();
        Map<BigDecimal, List<ItemProjection>> gropuItems = listStoreItems.stream()
                .collect(Collectors.groupingBy(ItemProjection::getItemNbr));
        gropuItems.forEach((k, v) -> {
            Map<Date, List<ItemProjection>> groupItemByDate = v.stream().collect(Collectors.groupingBy(ItemProjection::getShipDt));
            groupItemByDate.forEach((k1, v1) -> {
                ItemsDTO item;
                ModelMapper modelMap = new ModelMapper();
                item = modelMap.map(v1.get(0), ItemsDTO.class);
                List<SuggOrderQtyDTO> oderList = new ArrayList<>();
                v1.forEach(i -> {
                    SuggOrderQtyDTO odrQty = new SuggOrderQtyDTO();
                    odrQty.setPresellLevelID(i.getPsellClsIdNbr());
                    odrQty.setPresellLevelCode(i.getPsellLvlClsCd());
                    odrQty.setSuggOrderQty(i.getSuggOrderQty().toString());
                    oderList.add(odrQty);
                });
                item.setSuggOrderQtyList(oderList);
                if (preselLvlID != null) {
                    var qty = oderList.stream().filter(e -> e.getPresellLevelCode().equalsIgnoreCase(preselLvlID)).findAny();
                    if (qty.isPresent()) {
                        item.setItemOrderQty(qty.get().getSuggOrderQty());
                        item.setSuggOrderQty(qty.get().getSuggOrderQty());

                    }
                }
                //itemList.put(item.getItemNbr(), item);
                list.add(item);
            });
        });

        // list = new ArrayList<>(itemList.values());
        list.sort(Comparator.comparing(ItemsDTO::getItemNbr));

        return list;
    }

    public String getPresellLvlClasification(Integer presellId, Integer storeNbr) {
        String lvlCd = null;
        int psellLevelID = presellRepository.getLvlId(presellId);
        var clasificationID = lvlMapngRepository.getClsId(psellLevelID, storeNbr);
        if (clasificationID != null) {
            lvlCd = lvlClassRepository.getPreselLvlCd(clasificationID);
        }
        return lvlCd;
    }


}