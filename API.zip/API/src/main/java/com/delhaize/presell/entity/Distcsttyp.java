package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TCST710_DISTCSTTYP")
public class Distcsttyp {


  @Id
  @Column(name="DIST_CST_TYP_CD")
  private String distCstTypCd;

  @Column(name="DIST_CST_TYP_DSC")
  private String distCstTypDsc;

  @Column(name="DIST_CST_RATE_CD")
  private String distCstRateCd;

  @Column(name="DIST_CST_UOM_CD")
  private String distCstUomCd;

  @Column(name="CST_BY_DC_FLG")
  private String cstByDcFlg;

  @Column(name="CST_BY_MDEPT_FLG")
  private String cstByMdeptFlg;

  @Column(name="CST_BY_SELWH_FLG")
  private String cstBySelwhFlg;

  @Column(name="CST_BY_CATG_FLG")
  private String cstByCatgFlg;

  @Column(name="CST_BY_STORE_FLG")
  private String cstByStoreFlg;

  @Column(name="CST_BY_ITEM_FLG")
  private String cstByItemFlg;

  @Column(name="CST_GRP_CD")
  private String cstGrpCd;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    Distcsttyp that = (Distcsttyp) o;
    return distCstTypCd != null && Objects.equals(distCstTypCd, that.distCstTypCd);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
