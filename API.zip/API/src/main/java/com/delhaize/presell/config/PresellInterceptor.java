package com.delhaize.presell.config;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.TokenAuthorization;
import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.util.CommonFunctions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.List;

@Slf4j
@Component
public class PresellInterceptor implements HandlerInterceptor {

    private final TokenAuthorization tokenAuthorization;

    @Autowired
    public PresellInterceptor(TokenAuthorization tokenAuthorization) {
        this.tokenAuthorization = tokenAuthorization;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        log.info("[preHandle][{}] {}", request.getMethod(), request.getRequestURI());
        if (request.getMethod().equals("OPTIONS")) {
            log.info("bypass the preflight request");
            return true;
        }
        HandlerMethod handlerMethod;
        try {
            handlerMethod = (HandlerMethod) handler;
        } catch (ClassCastException e) {
            log.error(e.getMessage());
            return false;
        }
        Method method = handlerMethod.getMethod();
        if (method.getDeclaringClass().isAnnotationPresent(RestController.class)) {
            if (method.isAnnotationPresent(Secured.class)) {
                String token = request.getHeader(HttpHeaders.AUTHORIZATION);
                if (token == null) {
                    throw ExceptionHandlingHelper.newGenericException(ResponseError.TOKEN_REQUIRED);
                }
                token = CommonFunctions.filterValidCharacterOfToken(token.substring(7));
                List<Secured.UserRole> permitRoles = List.of(method.getAnnotation(Secured.class).permitRoles());
                UserSSOInfo userSSOInfo = tokenAuthorization.validateToken(token, permitRoles);
                String validUserId = CommonFunctions.filterValidCharacterOfUserIdSSO(userSSOInfo.getUserId());
                userSSOInfo.setUserId(validUserId);
                request.setAttribute("user", userSSOInfo);
            } else {
                log.warn("This API Endpoint is not secured!");
            }
        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        log.info("[afterCompletion][{}] {}", request.getMethod(), request.getRequestURI());
    }
}
