package com.delhaize.presell.repository.template;

import com.delhaize.presell.entity.PresellStore;
import com.delhaize.presell.entity.StorItems;
import com.delhaize.presell.util.DatetimeUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Log4j2
@Service
public class ItemBatchJDBCTemplate {

    private final JdbcTemplate jdbcTemplate;

    @Value("${spring.jpa.properties.hibernate.default_schema}")
    private String schemaName;

    @Autowired
    public ItemBatchJDBCTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public void batchInsert(List<StorItems> items) {
        if (items.isEmpty()) return;
        log.info("batch insert item list");
        String query =
                "INSERT INTO " + schemaName + ".TPSL004_STOR_ITEMS "
                        + " (PSELL_ID_NBR, "
                        + " STORE_NBR, "
                        + " ITEM_NBR, "
                        + " SHIP_DT, "
                        + " ITEM_ORDER_QTY, "
                        + " ADD_USER_ID, "
                        + " ADD_TS, "
                        + " MOD_USER_ID, "
                        + " MOD_TS) "
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? )";
        jdbcTemplate.batchUpdate(query, new ItemBatchInsertPreparedStatementSetter(items));
    }

    public static class ItemBatchInsertPreparedStatementSetter implements BatchPreparedStatementSetter {

        List<StorItems> items;

        public ItemBatchInsertPreparedStatementSetter(List<StorItems> items) {
            super();
            this.items = items;
        }

        @Override
        public void setValues(PreparedStatement ps, int i) throws SQLException {
            var entity = items.get(i);
            ps.setInt(1, entity.getStorItemsPk().getPsellIdNbr());
            ps.setInt(2, entity.getStorItemsPk().getStoreNbr());
            ps.setBigDecimal(3, entity.getStorItemsPk().getItemNbr());
            ps.setDate(4, entity.getStorItemsPk().getShipDt());
            ps.setBigDecimal(5, entity.getItemOrderQty());
            ps.setString(6, entity.getAddUserId());
            ps.setTimestamp(7, DatetimeUtils.getUTCTimestamp());
            ps.setString(8, entity.getModUserId());
            ps.setTimestamp(9, DatetimeUtils.getUTCTimestamp());
        }

        @Override
        public int getBatchSize() {
            return items.size();
        }
    }
}
