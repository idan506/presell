package com.delhaize.presell.dto;

import com.delhaize.presell.dto.serialization.WhiteSpaceRemovalSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StoresDTO {
    private Integer storeNbr;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String storeNam;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String geoRegnCd;

    private Integer locSidNbr;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String divDsc;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String dstrcDsc;

    private Date schdArrvDt;

}
