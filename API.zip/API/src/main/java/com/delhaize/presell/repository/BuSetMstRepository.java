package com.delhaize.presell.repository;

import com.delhaize.presell.entity.BuSetMst;
import com.delhaize.presell.entity.BuSetMstPK;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BuSetMstRepository extends JpaRepository<BuSetMst, BuSetMstPK> {
}
