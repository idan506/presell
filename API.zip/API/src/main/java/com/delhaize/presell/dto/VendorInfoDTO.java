package com.delhaize.presell.dto;

import java.io.Serializable;

import com.delhaize.presell.annotation.QueryProjection;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class VendorInfoDTO implements Serializable {
	private String vendorId;
	private String vendorName;
}
