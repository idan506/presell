package com.delhaize.presell.controller;


import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.projection.BusUnitProjection;
import com.delhaize.presell.service.BuMstrService;
import com.delhaize.web.exception.EntityNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Log4j2
@CrossOrigin
@RestController
@RequestMapping({"api/v1/business"})
@Tag(name = "business", description = "the presell API")
public class BuMstrController {

    private final BuMstrService buMstrService;

    @Autowired
    public BuMstrController(BuMstrService buMstrService) {
        this.buMstrService = buMstrService;
    }

    @Operation(summary = "Get Business Unit", tags = { "business" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = BusUnitProjection.class))),
            @ApiResponse(responseCode = "404", description = "Business Unit not found", content = @Content)
    })
    @Secured
    @GetMapping(value = "/busUnit", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<BusUnitDTO>> getBusUnit() {
    log.info("getBusUnit");
    var rs = buMstrService.getBusUnit();
    return ResponseEntity.ok(rs);
    }
}
