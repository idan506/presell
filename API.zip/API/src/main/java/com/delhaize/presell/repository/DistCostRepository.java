package com.delhaize.presell.repository;

import com.delhaize.presell.entity.DistCost;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DistCostRepository extends JpaRepository<DistCost, Integer> {
	
	@Query(value = "SELECT TCST010.cstAmt, TCST010.cstDaysCnt "
			+ "FROM DistCost TCST010 "
			+ "WHERE TCST010.distCstTypCd = :cstType "
			+ "AND TCST010.dcSidNbr = :dcSidNbr "
			+ "AND TCST010.mdseDeptNbr = (SELECT TPRD704.mdseDeptNbr "
			+ "FROM ItemCls TPRD704 "
			+ "WHERE TPRD704.itemClsPk.itemNbr = :itemNbr "
			+ "AND TPRD704.itemClsPk.itemSetNbr = 1) ")
	List<String> fetchCAPFactorCapCstMer(@Param("cstType") String cstType, @Param("dcSidNbr") Integer dcSidNbr,
			@Param("itemNbr") BigDecimal itemNbr);
	
	@Query(value = "SELECT TCST010.cstAmt, TCST010.cstDaysCnt "
			+ "FROM DistCost TCST010 "
			+ "WHERE TCST010.distCstTypCd = :cstType "
			+ "AND TCST010.dcSidNbr = :dcSidNbr1 "
			+ "AND TCST010.whseNbr = (SELECT TITM202.selWhseId "
			+ "FROM DuDcXref TITM202 "
			+ "WHERE TITM202.duDcXrefPk.itemNbr = :itemNbr "
			+ "AND TITM202.duDcXrefPk.itemSetNbr = 1 "
			+ "AND TITM202.duDcXrefPk.dcSidNbr = :dcSidNbr2 "
			+ "AND TITM202.duDcXrefPk.distItemSeqNbr = 1) ")
	List<String> fetchCAPFactorHndCasCubOcc(@Param("cstType") String cstType, @Param("dcSidNbr1") Integer dcSidNbr1,
			@Param("itemNbr") BigDecimal itemNbr, @Param("dcSidNbr2") Integer dcSidNbr2);
}
