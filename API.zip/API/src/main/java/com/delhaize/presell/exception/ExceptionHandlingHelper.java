package com.delhaize.presell.exception;

import com.delhaize.web.exception.GenericApiException;
import com.delhaize.web.model.ApiError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Slf4j
public class ExceptionHandlingHelper {

    private ExceptionHandlingHelper() {
    }

    public static boolean isResponseErrorType(ResponseError responseError, Exception e) {
        if (!(e instanceof GenericApiException)) return false;
        var genericExp = (GenericApiException) e;
        return responseError.getMessage().equalsIgnoreCase(genericExp.getErrorResponse().getMessage())
                && responseError.getCode().value() == genericExp.getErrorResponse().getStatus().value();
    }

    public static GenericApiException newGenericException(ResponseError responseError) {
        return createNewGenericException(responseError.getCode(), responseError.getMessage());
    }

    public static GenericApiException newGenericException(ResponseError responseError, String uuid) {
        return createNewGenericException(responseError.getCode(), responseError.getMessage(), uuid);
    }

    public static GenericApiException newGenericException(ResponseError responseError, Exception e) {
        return newGenericException(responseError, e, null);
    }

    public static GenericApiException newGenericException(ResponseError responseError, Exception e, String uuid) {
        if (!(e instanceof GenericApiException)) {
            // runtimeException or entityNotFoundException
            if (uuid == null) {
                return createNewGenericException(responseError.getCode(), responseError.getMessage(), e);
            } else {
                return createNewGenericException(responseError.getCode(), responseError.getMessage(), e, uuid);
            }
        }

        GenericApiException genericApiException = (GenericApiException) e;
        if (uuid != null) {
            // set new id for generic exception
            genericApiException.getErrorResponse().setId(uuid);
        }
        genericApiException.getErrorResponse().setMessage(responseError.getMessage());
        genericApiException.getErrorResponse().setDebugMessage(
                responseError.getMessage() + "\tDebugMessage: " + genericApiException.getErrorResponse().getDebugMessage()
        );
        return genericApiException;
    }

    private static GenericApiException createNewGenericException(HttpStatus status, String message, String uuid) {
        GenericApiException genericExp = createNewGenericException(status, message);
        genericExp.getErrorResponse().setId(uuid);
        return genericExp;
    }

    private static GenericApiException createNewGenericException(HttpStatus status, String message) {
        ApiError apiError = new ApiError(status, message);
        apiError.setDebugMessage(message);
        return new GenericApiException(apiError);
    }

    private static GenericApiException createNewGenericException(HttpStatus status, String message, Throwable ex) {
        ApiError apiError = new ApiError(status, message, ex);
        apiError.setDebugMessage(message + "\tDebugMessage: " + apiError.getDebugMessage());
        return new GenericApiException(apiError);
    }

    private static GenericApiException createNewGenericException(HttpStatus status, String message, Throwable ex, String uuid) {
        GenericApiException genericExp = createNewGenericException(status, message, ex);
        genericExp.getErrorResponse().setId(uuid);
        return genericExp;
    }

}
