package com.delhaize.presell.repository.dao;

import java.util.List;

import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;

public interface PresellLevelMappingDAO {
	List<Integer> getPresellLevelStoreList(StorePresellLevelMappingCriteria criteria);
}
