package com.delhaize.presell.repository;

import com.delhaize.presell.entity.PurchCost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PurchCostRepository extends JpaRepository<PurchCost, Integer> {
}
