package com.delhaize.presell.service;

import com.delhaize.presell.dto.PresellLevelDTO;
import com.delhaize.presell.dto.request.PresellLevelRequestDTO;

import java.util.List;

public interface PresellLevelService {

    List<PresellLevelDTO> getPresellLevel();

    int deletePresellLevel(PresellLevelRequestDTO request);

    int insertOrUpdatePresellLevel(PresellLevelRequestDTO request);

}
