package com.delhaize.presell.service;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.dto.StoresDTO;
import com.delhaize.presell.dto.projection.BusUnitProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface StoreService {
    List<StoresDTO> searchStore(StoreSearchCriteria criteria);

    int insertOrDeleteStore(PresellSaveRequestDTO request);

    int saveNewStoresToPresell(PresellSaveRequestDTO request);

    List<Integer> getStoreNumberList(StorePresellLevelMappingCriteria criteria);

    List<BusUnitDTO> getStoreTypeList();
}
