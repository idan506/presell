package com.delhaize.presell.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.domain.Sort;

@Getter
@Setter
public class PaginationAndSortDTO {

    @Schema(example = "10", description = "the size of page")
    private Integer size = 10;

    @Schema(example = "0", description = "offset for pagination")
    private Integer page = 0;

    @Schema(example = "sortedColumn", description = "sorted column, the valid value is the field name you want to sort in response schema of this api.")
    private String sortBy;

    @Schema(example = "ASC")
    private Sort.Direction order = Sort.Direction.ASC;

}
