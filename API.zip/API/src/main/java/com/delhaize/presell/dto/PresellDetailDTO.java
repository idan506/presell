package com.delhaize.presell.dto;

import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.projection.PresellLogProjection;
import com.delhaize.presell.dto.projection.StoreResultsPresellprojection;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class PresellDetailDTO {

    private int psellIdNbr;

    @Schema(example = "presell title.", required = true)
    private String psellDsc;

    @Schema(example = "")
    private String busUnitId;

    @Schema(example = "2", required = true)
    private Integer psellLvlIdNbr;

    @Schema(example = "rparo")
    private String addUserId;

    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date psellDueDt;

    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date rmndrEmailDt;

    private String plnDistFlg;

    @Schema(example = "SAVED_AS_DRAFT")
    private Status psellStatCd;

    @Schema(example = "presell comment.")
    private String psellCmtTxt;

    @NotNull
    private List<StoreDTO> storeDTOList = new ArrayList<>();

    @NotNull
    private List<AddItemsDTO> itemDTOList = new ArrayList<>();

    @Schema(hidden = true)
    private List<AddItemsDTO> itemNotFoundList;

    @Schema(hidden = true)
    private List<PresellLogProjection> logs;

    private Integer itemCount;

    private Integer storeCount;

    @Schema(hidden = true)
    private List<ItemsDTO> itemList;

    @Schema(hidden = true)
    private List<StoreResultsPresellprojection> hmStoresForAdd;
}
