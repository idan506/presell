package com.delhaize.presell.service.impl;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.StoreProjection;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.entity.LvlMapng;
import com.delhaize.presell.entity.LvlMapngPK;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.repository.LvlMaintRepository;
import com.delhaize.presell.repository.LvlMapngRepository;
import com.delhaize.presell.repository.StoreRepository;
import com.delhaize.presell.repository.dao.PresellLevelMappingDAO;
import com.delhaize.presell.service.PresellLevelMappingService;
import com.delhaize.presell.util.DatetimeUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Log4j2
@Service
public class PresellLevelMappingServiceImpl implements PresellLevelMappingService {

    private final StoreRepository storeRepository;
    private final LvlMapngRepository lvlMapngRepository;
    private final LvlMaintRepository lvlMaintRepository;
    private PresellLevelMappingDAO presellLevelMappingDAO;
    private final PresellLevelServiceImpl presellLevelServiceImpl;


    @Autowired
    public PresellLevelMappingServiceImpl(StoreRepository storeRepository,
                                          PresellLevelMappingDAO presellLevelMappingDAO, LvlMapngRepository lvlMapngRepository,
                                          LvlMaintRepository lvlMaintRepository,PresellLevelServiceImpl presellLevelServiceImpl) {
        this.presellLevelMappingDAO = presellLevelMappingDAO;
        this.storeRepository = storeRepository;
        this.lvlMapngRepository = lvlMapngRepository;
        this.lvlMaintRepository = lvlMaintRepository;
        this.presellLevelServiceImpl=presellLevelServiceImpl;
    }

    @Override
    public List<StorePresellLevelMappingDTO> searchStorePresellLevelMapping(StorePresellLevelMappingCriteria criteria) {
        log.info("-----Search store presell levle mapping-----");
        List<StorePresellLevelMappingDTO> listStoreDetails = new ArrayList<>();
        List<Integer> listStoreNo = presellLevelMappingDAO.getPresellLevelStoreList(criteria);
        HashMap<Integer, Integer> hmPresellLevel = new HashMap<>();
        List<LvlMappingDTO> lvlMaping;
        Integer levelIDNbr;
        Integer classIDNbr;

        if (listStoreNo == null) {
            return Collections.emptyList();
        } else {
            StorePresellLevelMappingDTO storeOrder;
            if (criteria.getStoreNo() != null && !criteria.getStoreNo().equals(PresellConstants.BLANK)) {
                Integer storeNumb = Integer.parseInt(criteria.getStoreNo());
                storeOrder = storeRepository.getStoreDetails(storeNumb);
                storeOrder.setStoreNbr(storeNumb);
                lvlMaping = lvlMapngRepository.getStorePresellLevelMapping(storeNumb);
            } else {
                storeOrder = storeRepository.getStoreDetails(listStoreNo.get(0));
                storeOrder.setStoreNbr(listStoreNo.get(0));
                lvlMaping = lvlMapngRepository.getStorePresellLevelMapping(listStoreNo.get(0));
            }
            List<PresellLevelDTO> level= presellLevelServiceImpl.getPresellLevel();
            for (LvlMappingDTO lvlMappingDTO : lvlMaping) {
                //   for( int j=0;j<level.size();j++){
                for(PresellLevelDTO presellLvl:level) {
                    if (presellLvl.getLevelId().equals(lvlMappingDTO.getLevelId())) {
                        levelIDNbr = lvlMappingDTO.getLevelId();
                        classIDNbr = lvlMappingDTO.getClassId();
                        hmPresellLevel.put(levelIDNbr, classIDNbr);
                        break;
                    }
                }
            }
            storeOrder.setHmStorePresellLevelMap(hmPresellLevel);
            storeOrder.setListStoreNo(listStoreNo);
            listStoreDetails.add(storeOrder);
        }

        return listStoreDetails;
    }

    @Override
    @Transactional
    public int saveStorePresellLevelMaping(StorePresellLevelDTO criteria) {
        log.info("-----Save store presell level mapping-----");
        if (criteria != null) {
            List<LevelDTO> presellLevel = criteria.getPresellLevel();
            if (presellLevel != null) {
                for (LevelDTO levelDTO : presellLevel) {
                    switch (levelDTO.getAction()) {
                        case DELETE:
                            lvlMapngRepository.deletePreselllevel(levelDTO.getStoreNbr(),
                                    levelDTO.getPsellLvlIdNbr());
                            break;
                        case INSERT:
                            var levelMapping = new LvlMapng();
                            var levelMappingPK = new LvlMapngPK();
                            levelMappingPK.setStoreNbr(levelDTO.getStoreNbr());
                            levelMappingPK.setPsellLvlIdNbr(levelDTO.getPsellLvlIdNbr());
                            levelMapping.setPsellClsIdNbr(levelDTO.getPsellClsIdNbr());
                            levelMapping.setAddUserId(criteria.getUserId());
                            levelMapping.setModUserId(criteria.getUserId());
                            levelMapping.setAddTs(DatetimeUtils.getUTCTimestamp());
                            levelMapping.setModTs(DatetimeUtils.getUTCTimestamp());
                            levelMapping.setLvlMapngPk(levelMappingPK);
                            lvlMapngRepository.saveAndFlush(levelMapping);
                            break;
                        case UPDATE:
                            lvlMapngRepository.updatelevelMapping(levelDTO.getStoreNbr(),
                                    levelDTO.getPsellLvlIdNbr(), levelDTO.getPsellClsIdNbr(),
                                    criteria.getUserId(), DatetimeUtils.getUTCTimestamp());
                            break;
                        default:
                            throw new IllegalArgumentException("invalid action");
                    }

                }
            }

        }

        return 1;
    }

    @Override
    public ByteArrayInputStream downloadStorePresellLevelMapping(String fileName) {
        log.info("-----Download store presell level mapping-----");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HSSFWorkbook wb = new HSSFWorkbook();
        try {
            Map<Integer, List<StoreProjection>> listMapping = storeRepository.getListStoreDownloadDetail().stream()
                    .collect(Collectors.groupingBy(StoreProjection::getStoreNbr));
            Map<Integer, StorePresellLevelMappingDTO> listMappingResult = new HashMap<>();
            listMapping.forEach((id, store) -> {
                StoreProjection store1 = store.get(0);
                var objStorePresellLevelMappingBean = new StorePresellLevelMappingDTO();
                objStorePresellLevelMappingBean.setStoreNbr(store1.getStoreNbr());
                objStorePresellLevelMappingBean.setStoreNam(store1.getStoreNam());
                objStorePresellLevelMappingBean.setGeoRegnCd(store1.getGeoRegnCd());
                objStorePresellLevelMappingBean.setLocOrgDsc(store1.getLocOrgDsc());
                var lvlMap = new HashMap<Integer, String>();
                store.forEach(s -> {
                    lvlMap.put(s.getPsellLvlIdNbr(), s.getPsellLvlClsCd());
                });
                objStorePresellLevelMappingBean.setIntListArrayLevelId(lvlMap);
                listMappingResult.put(id,objStorePresellLevelMappingBean);
            });

            List<PresellLevelDTO> listPresellLevel = lvlMaintRepository.getAllPresellLevel();
            int iJ = 0;

            HSSFSheet sheet = wb.createSheet(fileName);
            // create a cell and put a value in it.
            HSSFRow row = sheet.createRow((short) 0);
            // create a cell and put a value in it.
            HSSFCell cell = row.createCell((short) 3);
            cell.setCellValue("Presell Store Level Mapping");

            row = sheet.createRow((short) 1);

            cell = row.createCell((short) 0);

            cell.setCellValue("Store#");

            if (listPresellLevel != null) {
                for (iJ = 0; iJ < listPresellLevel.size(); iJ++) {
                    row.createCell((short) (1 + iJ)).setCellValue(listPresellLevel.get(iJ).getLevelDsc());
                }
            }

            assert listPresellLevel != null;
            log.info("intPresellLevelId: " + listPresellLevel.size());

            row.createCell((short) (iJ + 1)).setCellValue("Store Name");
            row.createCell((short) (iJ + 2)).setCellValue("State");
            row.createCell((short) (iJ + 3)).setCellValue("District");

            createRowForPresellLevelMappingExcelFile(sheet, listMappingResult, listPresellLevel);
            wb.write(out);
        } catch (IOException e) {
            log.error("Error at download excel file: {}", e.getMessage());
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                wb.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    private void createRowForPresellLevelMappingExcelFile(HSSFSheet sheet, Map<Integer, StorePresellLevelMappingDTO> listMappingResult, List<PresellLevelDTO> listPresellLevel) {
        log.info("-----Create row for presell level mapping excel file-----");
        List<StoreProjection> listStore = storeRepository.getListStore();
        StoreProjection objListStore;
        for (int iP = 0; iP < listStore.size(); iP++) {
            objListStore = listStore.get(iP);
            HSSFRow row = sheet.createRow((short) (iP + 2));
            // Create a cell and put a value in it.
            HSSFCell cell = row.createCell((short) 0);
            cell.setCellValue(objListStore.getStoreNbr());
            StorePresellLevelMappingDTO storeMapping = listMappingResult.get(objListStore.getStoreNbr());
            int iN;
            if (storeMapping != null) {
                for (iN = 0; iN < listPresellLevel.size(); iN++) {
                    var lvlIdStr = storeMapping.getIntListArrayLevelId()
                            .get(listPresellLevel.get(iN).getLevelId());
                    row.createCell((short) (iN + 1)).setCellValue(lvlIdStr == null ? "--" : lvlIdStr);
                }
            } else {
                cell.setCellValue(objListStore.getStoreNbr());
                for (iN = 0; iN < listPresellLevel.size(); iN++) {
                    row.createCell((short) (iN + 1)).setCellValue("--");
                }
            }
            row.createCell((short) (iN + 1)).setCellValue(objListStore.getStoreNam().trim());
            row.createCell((short) (iN + 2)).setCellValue(objListStore.getGeoRegnCd().trim());
            row.createCell((short) (iN + 3)).setCellValue(objListStore.getLocOrgDsc().trim());
        }
    }
}
