package com.delhaize.presell.dto;

import com.delhaize.presell.annotation.QueryProjection;
import com.delhaize.presell.dto.serialization.WhiteSpaceRemovalSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class StorePresellLevelMappingDTO implements Serializable {

    private Integer storeNbr;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String storeNam;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String busUnitId;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String busUnitDsc;

    private String storeFlg;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String geoRegnCd;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String locOrgDsc;

    private HashMap<Integer, Integer> hmStorePresellLevelMap;

    private List<Integer> listStoreNo;

    private Map<Integer, String> intListArrayLevelId;
}
