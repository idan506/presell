package com.delhaize.presell.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PresellAuthorDTO {

    private String userID;
    private String userName;
}
