package com.delhaize.presell.dto;

import java.util.List;

import com.delhaize.presell.dto.projection.MissingOrderProjection;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MissingOrderDTO {
	List<MissingOrderProjection> listMissingReports;
	List<MissingOrderProjection> listDraftReports;
}
