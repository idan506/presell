package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPRM001_RTL_PRC")
public class RtlPrc {


  @Id
  @Column(name="PRC_SID_NBR")
  private Integer prcSidNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;

  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="PRC_CMPNT_TYP_CD")
  private String prcCmpntTypCd;

  @Column(name="GRP_TYP_CD")
  private String grpTypCd;

  @Column(name="GRP_CD")
  private Integer grpCd;

  @Column(name="PRC_MSTR_TYP_ID")
  private String prcMstrTypId;

  @Column(name="PRC_MSTR_ID")
  private String prcMstrId;

  @Column(name="EFF_DT")
  private java.sql.Date effDt;

  @Column(name="XPIR_DT")
  private java.sql.Date xpirDt;

  @Column(name="SRP_AMT")
  private java.math.BigDecimal srpAmt;

  @Column(name="RTL_MLT")
  private Integer rtlMlt;

  @Column(name="PRC_STRAT_CD")
  private String prcStratCd;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="ADD_TS")
  private java.sql.Timestamp addTs;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="PA_ACTN_CD")
  private String paActnCd;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    RtlPrc rtlPrc = (RtlPrc) o;
    return prcSidNbr != null && Objects.equals(prcSidNbr, rtlPrc.prcSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
