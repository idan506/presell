package com.delhaize.presell.dto.request;

import com.delhaize.presell.dto.ClassificationDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PresellClassificationRequestDTO {
    private List<ClassificationDTO> classifications;
    private String userId;
}
