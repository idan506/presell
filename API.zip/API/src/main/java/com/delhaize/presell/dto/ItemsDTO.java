package com.delhaize.presell.dto;

import com.delhaize.presell.dto.serialization.IntegerFormattingSerializer;
import com.delhaize.presell.dto.serialization.NumberFormattingSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ItemsDTO {

    private String itemNbr;
    private Date shipDt;
    @JsonSerialize(using = NumberFormattingSerializer.class)
    private String itemCst;
    private String itemSzCnt;
    private String itemSzCd;
    private String itemPkQty;
    @JsonSerialize(using = NumberFormattingSerializer.class)
    private String itemCapCst;
    @JsonSerialize(using = NumberFormattingSerializer.class)
    private String rtlPrc;
    @JsonSerialize(using = NumberFormattingSerializer.class)
    private String psellGrmrgAmt;
    private String itemDsc;
    private String psellItemCmtTxt;
    private String itemImgUrl;
    private String itemCntrbPct;
    private int psellClsIdNbr;
    @JsonSerialize(using = IntegerFormattingSerializer.class)
    private String suggOrderQty;
    private String psellLvlClsCd;
    @JsonSerialize(using = IntegerFormattingSerializer.class)
    private String itemOrderQty;
    private List<SuggOrderQtyDTO> suggOrderQtyList;


}
