package com.delhaize.presell.repository;

import com.delhaize.presell.entity.DuCntr;
import com.delhaize.presell.entity.DuCntrPK;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DuCntrRepository extends JpaRepository<DuCntr, DuCntrPK> {

	@Query(value = "SELECT cntrWgt, cntrVol " + "FROM DuCntr " + "WHERE duCntrPk.itemNbr = :itemNbr "
			+ "AND duCntrPk.itemSetNbr = :itemSetNbr " + "AND duCntrPk.distItemSeqNbr  = :distItemSeqNbr "
			+ "AND duCntrPk.cntrTypCd = :cntrTypCd ")
	List<String> fetchSellUnitCube(@Param("itemNbr") BigDecimal itemNbr, @Param("itemSetNbr") Integer itemSetNbr,
			@Param("distItemSeqNbr") Integer distItemSeqNbr, @Param("cntrTypCd") String cntrTypCd);
}
