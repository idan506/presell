package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class BuSetMstPK implements Serializable {


  @Column(name="BUS_UNIT_ID")
  private String busUnitId;

  @Column(name="EFF_DT")
  private java.sql.Date effDt;
}
