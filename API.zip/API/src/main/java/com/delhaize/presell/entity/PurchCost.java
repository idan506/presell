package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TCST003_PURCH_COST")
public class PurchCost {


  @Id
  @Column(name="PUR_CST_SID_NBR")
  private Integer purCstSidNbr;

  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;

  @Column(name="VEND_SET_NBR")
  private Integer vendSetNbr;

  @Column(name="VEND_ID")
  private String vendId;

  @Column(name="LOC_SID_NBR")
  private Integer locSidNbr;

  @Column(name="BRKT_NBR")
  private Integer brktNbr;

  @Column(name="CST_CMPNT_TYP_NBR")
  private Integer cstCmpntTypNbr;

  @Column(name="CST_MSTR_ID")
  private String cstMstrId;

  @Column(name="EFF_DT")
  private java.sql.Date effDt;

  @Column(name="XPIR_DT")
  private java.sql.Date xpirDt;

  @Column(name="CST_AMT")
  private java.math.BigDecimal cstAmt;

  @Column(name="CRNCY_TYP_CD")
  private String crncyTypCd;

  @Column(name="ALW_TYP_NBR")
  private Integer alwTypNbr;

  @Column(name="ALW_CST_RATE_CD")
  private String alwCstRateCd;

  @Column(name="BBK_COLL_DLAYD_DUR")
  private Integer bbkCollDlaydDur;

  @Column(name="CST_BASIS_CD")
  private String cstBasisCd;

  @Column(name="CST_DSC")
  private String cstDsc;

  @Column(name="SELL_ALW_NEG_FLG")
  private String sellAlwNegFlg;

  @Column(name="TOT_SELL_ALW_AMT")
  private java.math.BigDecimal totSellAlwAmt;

  @Column(name="BBK_PGM_ID")
  private String bbkPgmId;

  @Column(name="BPG_COND_ID")
  private String bpgCondId;

  @Column(name="LAST_MOD_USER_ID")
  private String lastModUserId;

  @Column(name="LAST_MOD_TS")
  private java.sql.Timestamp lastModTs;

  @Column(name="LAST_MOD_PGM_ID")
  private String lastModPgmId;

  @Column(name="BILLED_VEND_ID")
  private String billedVendId;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    PurchCost purchCost = (PurchCost) o;
    return purCstSidNbr != null && Objects.equals(purCstSidNbr, purchCost.purCstSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
