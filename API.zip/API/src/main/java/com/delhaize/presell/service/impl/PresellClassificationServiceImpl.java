package com.delhaize.presell.service.impl;

import com.delhaize.presell.dto.ClassificationDTO;
import com.delhaize.presell.dto.request.PresellClassificationRequestDTO;
import com.delhaize.presell.entity.LvlClass;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.repository.LvlClassRepository;
import com.delhaize.presell.service.PresellClassificationService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Log4j2
@Service
public class PresellClassificationServiceImpl implements PresellClassificationService {

    private final LvlClassRepository lvlClassRepository;

    @Autowired
    public PresellClassificationServiceImpl(LvlClassRepository lvlClassRepository) {
        this.lvlClassRepository = lvlClassRepository;
    }

    @Override
    @Cacheable(value = "classifications")
    public List<ClassificationDTO> getClassification() {
        return lvlClassRepository.getClassifications();
    }

    @Override
    @Transactional
    @CacheEvict(value = "classifications", allEntries = true)
    public int deleteClassification(PresellClassificationRequestDTO request) {
        log.info("-----Delete classification-----");
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(false);
        var lvlClasses = request.getClassifications().stream()
                .map(classificationDTO -> {
                    // check data sync before executing query
                    if (!isDataSyncPassed.get()) {
                        isDataSyncPassed.set(checkDataSync(classificationDTO));
                    }
                    return lvlClassRepository.findById(classificationDTO.getClassificationId());
                })
                .filter(Optional::isPresent)
                .map(lvlClass -> {
                    var entity = lvlClass.get();
                    entity.setLgclDelFlg("Y");
                    entity.setModUserId(request.getUserId());
                    return entity;
                }).collect(Collectors.toList());
        lvlClassRepository.saveAll(lvlClasses);
        return 1;
    }

    @Override
    @Transactional
    @CacheEvict(value = "classifications", allEntries = true)
    public int insertOrUpdateClassification(PresellClassificationRequestDTO request) {
        log.info("-----Insert or Update classification-----");
        AtomicBoolean isDataSyncPassed = new AtomicBoolean();
        isDataSyncPassed.set(false);
        var lvlClasses = request.getClassifications().stream()
                .map(classificationDTO -> {
                    LvlClass entity;
                    if (classificationDTO.getClassificationId() == 0) {
                        entity = getLvlClass(request, classificationDTO);
                    } else {
                        var lvlClass = lvlClassRepository.findById(classificationDTO.getClassificationId());
                        if (lvlClass.isPresent()) {
                            // check data sync before executing query
                            if (!isDataSyncPassed.get()) {
                                isDataSyncPassed.set(checkDataSync(classificationDTO));
                            }
                            entity = lvlClass.get();
                            entity.setPsellLvlClsCd(classificationDTO.getClassificationDsc());
                            entity.setModUserId(request.getUserId());
                        } else {
                            entity = getLvlClass(request, classificationDTO);
                        }
                    }
                    return entity;
                }).collect(Collectors.toList());
        lvlClassRepository.saveAll(lvlClasses);
        return 0;
    }

    private LvlClass getLvlClass(PresellClassificationRequestDTO request, ClassificationDTO classificationDTO) {
        log.info("-----Get level classification-----");
        var lvlClass = new LvlClass();
        try {
            lvlClass.setPsellClsIdNbr(lvlClassRepository.getMaxId() + 1);
            lvlClass.setLgclDelFlg("N");
            lvlClass.setPsellLvlClsCd(classificationDTO.getClassificationDsc());
            lvlClass.setAddUserId(request.getUserId());
            lvlClass.setModUserId(request.getUserId());
        } catch (Exception e) {
            log.error("Error at get lvl classification: {}", e.getMessage());
        }
        return lvlClass;
    }

    /**
     * Check if the database has been updated by another session, after
     * The data for this session was fetched.
     * For this the current max timestamp is fetched from database
     * and compared with the time stamp stored in the bean during fetch.
     * If the Database has the latest value of timestamp, the current update is rolled back.
     * And a fresh search is shown to the user.
     *
     * @param classificationDTO
     */
    private boolean checkDataSync(ClassificationDTO classificationDTO) {
        log.info("-----Check data sync-----");
        Timestamp maxModDB = lvlClassRepository.getMaxModTs();
        if (maxModDB.after(classificationDTO.getFetchTime())) {
            throw ExceptionHandlingHelper.newGenericException(ResponseError.DATA_SYNC_EXCEPTION);
        }
        return true;
    }
}
