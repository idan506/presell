package com.delhaize.presell.repository.dao;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.StoreOrderDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Repository
public class StoreOrderDAOImpl implements StoreOrderDAO {

	@PersistenceContext
	EntityManager entityManager;

	private Page<StoreOrderDTO> readPage(final TypedQuery<StoreOrderDTO> query, TypedQuery<Long> countQuery,
			final Pageable pageable, String role) {
		try {
			if (pageable != null) {
				query.setFirstResult((int) pageable.getOffset());
				query.setMaxResults(pageable.getPageSize());

				final List<StoreOrderDTO> content = query.getResultList();
				log.info("Result List: " + content.size());

				if (role.equals(PresellConstants.USER_GROUP_RETL_ROLE)) {
					normalizeResultsWithRoleRT(content);
				} else {
					normalizeResults(content);
				}

				Long total = countQuery.getSingleResult();
				log.info("total: " + total);

				return new PageImpl<>(content, pageable, total);
			} else {
				var content = query.getResultList();
				normalizeResults(content);
				return new PageImpl<>(content);
			}
		} catch (Exception e) {
			log.error(e);
			throw e;
		}
	}

	private void normalizeResults(List<StoreOrderDTO> result) {
		result.forEach(e -> {
			e.setStoreStatCd(Objects.requireNonNull(Status.findByKey(e.getStoreStatCd())).getStatusDsc());
			e.setPlnDistFlg("Y".equalsIgnoreCase(e.getPlnDistFlg()) ? "Yes" : "No");
		});
	}

	private void normalizeResultsWithRoleRT(List<StoreOrderDTO> result) {
		result.forEach(e -> {
			if (Status.findByKeyForSearchStoreOrder(e.getStoreStatCd()) != null) {
				e.setStoreStatCd((Status.findByKeyForSearchStoreOrder(e.getStoreStatCd())).getStatusDsc());
			} else {
				e.setStoreStatCd("");
			}
			e.setPlnDistFlg("Y".equalsIgnoreCase(e.getPlnDistFlg()) ? "Yes" : "No");
		});
	}

	@Override
	public Page<StoreOrderDTO> searchStoreOrderWithRoleRT(StoreOrderCriteria criteria, Pageable pageable) {
		StringBuilder queryString = new StringBuilder(SearchStoreOrderConstants.SELECT_PRESELL_STOREORDER_LISTING);
		StringBuilder queryCountString = new StringBuilder(SearchStoreOrderConstants.COUNT_PRESELL_STOREORDER_LISTING);
		StringBuilder whereClause = new StringBuilder();
		Map<String, Object> parameters = new HashedMap<>();
		buildWhereClauseWithRoleRT(whereClause, parameters, criteria);

		queryString.append(whereClause);
		queryCountString.append(whereClause);

		if (pageable != null) {
			queryString.append(" ORDER BY ");
			pageable.getSort()
					.forEach(order -> queryString
							.append(SearchStoreOrderConstants.sortKeysWithRoleRT.get(order.getProperty())).append(" ")
							.append(order.getDirection()).append(", "));
			// remove redundant comma
			queryString.append(" TPSL001.psellIdNbr ").append(pageable.getSort().toList().get(0).getDirection());
		} else {
			queryString.append(" ORDER BY TPSL001.psellIdNbr ASC ");
		}

		// prepare the search presell query
		TypedQuery<StoreOrderDTO> query = entityManager.createQuery(queryString.toString(), StoreOrderDTO.class);
		parameters.forEach(query::setParameter);

		// log.info("query: " + queryString);

		// prepare the count all elements query
		TypedQuery<Long> countQuery = entityManager.createQuery(queryCountString.toString(), Long.class);
		parameters.forEach(countQuery::setParameter);

		// log.info("queryCountString: " + queryCountString);

		return readPage(query, countQuery, pageable, criteria.getUserRole());
	}

	private void buildWhereClauseWithRoleRT(StringBuilder whereClause, Map<String, Object> parameters,
			StoreOrderCriteria criteria) {
		if (criteria.getPresellTitle() != null) {
			whereClause.append(" AND UPPER(TPSL001.psellDsc) LIKE CONCAT('%',:psellDsc,'%') ");
			parameters.put("psellDsc", criteria.getPresellTitle().toUpperCase());
		}

//		if (criteria.getStatus() != null && !Status.ALL.equals(criteria.getStatus())) {
//			var parameter = "psellStatCd";
//
//			if (criteria.getStatus().equals(Status.SUBMITTED)) {
//				whereClause.append(" AND TPSL003.storeStatCd IN (:psellStatCd , :psellStatCdPlus) ");
//				parameters.put(parameter, Status.SUBMITTED.getKey());
//				parameters.put("psellStatCdPlus", Status.REC_FROM_STORES.getKey());
//			} else {
//				whereClause.append(" AND TPSL003.storeStatCd = :psellStatCd ");
//				String status;
//				switch (criteria.getStatus()) {
//				case PENDING:
//					status = Status.PENDING.getKey();
//					break;
//				case SAVED_AS_DRAFT:
//					status = Status.SAVED_AS_DRAFT.getKey();
//					break;
//				case CLOSED:
//					status = Status.CLOSED.getKey();
//					break;
//				default:
//					throw new IllegalArgumentException("invalid status!");
//				}
//				parameters.put(parameter, status);
//				log.info("------------------ " + status);
//			}
//		}
		buildQueryBasedOnStatusWithRoleRT(whereClause, parameters, criteria);

		if (criteria.getPresellAuthor() != null) {
			whereClause.append(" AND TPSL001.addUserId = :addUserId ");
			parameters.put("addUserId", criteria.getPresellAuthor());
		}

		if (criteria.getPresellLevelId() != null) {
			whereClause.append(" AND TPSL001.psellLvlIdNbr = :psellLvlIdNbr ");
			parameters.put("psellLvlIdNbr", criteria.getPresellLevelId());
		}

		if (criteria.getFromDueDate() != null) {
			whereClause.append(" AND TPSL001.psellDueDt >= :fpsellDueDt ");
			parameters.put("fpsellDueDt", criteria.getFromDueDate());
		}

		if (criteria.getToDueDate() != null) {
			whereClause.append(" AND TPSL001.psellDueDt <= :tpsellDueDt ");
			parameters.put("tpsellDueDt", criteria.getToDueDate());
		}

		if (criteria.getPlannedDis() != null && !criteria.getPlannedDis().equalsIgnoreCase(PresellConstants.HASH)) {
			whereClause.append(" AND TPSL001.plnDistFlg = :plnDistFlg ");
			parameters.put(SearchStoreOrderConstants.PLN_DIST_FLG, criteria.getPlannedDis());
		}
		if (criteria.getStoreNo() != null) {
			int storeNbr = Integer.parseInt(criteria.getStoreNo());
			whereClause.append(" AND TPSL003.storePk.storeNbr = :storeNbr");
			parameters.put("storeNbr", storeNbr);
		}
	}

	private void buildQueryBasedOnStatusWithRoleRT(StringBuilder whereClause, Map<String, Object> parameters,
			StoreOrderCriteria criteria) {
		if (criteria.getStatus() != null && !Status.ALL.equals(criteria.getStatus())) {
			var parameter = "psellStatCd";

			if (criteria.getStatus().equals(Status.SUBMITTED)) {
				whereClause.append(" AND TPSL003.storeStatCd IN (:psellStatCd , :psellStatCdPlus) ");
				parameters.put(parameter, Status.SUBMITTED.getKey());
				parameters.put("psellStatCdPlus", Status.REC_FROM_STORES.getKey());
			} else {
				whereClause.append(" AND TPSL003.storeStatCd = :psellStatCd ");
				String status;
				switch (criteria.getStatus()) {
				case PENDING:
					status = Status.PENDING.getKey();
					break;
				case SAVED_AS_DRAFT:
					status = Status.SAVED_AS_DRAFT.getKey();
					break;
				case CLOSED:
					status = Status.CLOSED.getKey();
					break;
				default:
					throw new IllegalArgumentException("invalid status!");
				}
				parameters.put(parameter, status);
				log.info("------------------ " + status);
			}
		}
	}

	private static class SearchStoreOrderConstants {

		private static final String PLN_DIST_FLG = "plnDistFlg";

		private static final String SELECT_PRESELL_STOREORDER_LISTING = "SELECT DISTINCT NEW com.delhaize.presell.dto.StoreOrderDTO("
				+ "TPSL001.psellIdNbr, " + "TPSL001.busUnitId, " + "TPSL001.psellDsc, " + "TPSL006.psellLvlDsc, "
				+ "TPSL003.storeStatCd, " + "TPSL001.psellDueDt, " + "TPSL001.plnDistFlg) " + "FROM Presell TPSL001, "
				+ "LvlMaint TPSL006, " + "PresellStore TPSL003 "
				+ "WHERE TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr "
				+ "AND TPSL001.psellIdNbr = TPSL003.storePk.psellIdNbr " + "AND TPSL001.psellStatCd != 'DRF' ";

		private static final String COUNT_PRESELL_STOREORDER_LISTING = "SELECT COUNT(*) " + "FROM Presell TPSL001, "
				+ "LvlMaint TPSL006, " + "PresellStore TPSL003 "
				+ "WHERE TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr "
				+ "AND TPSL001.psellIdNbr = TPSL003.storePk.psellIdNbr " + "AND TPSL001.psellStatCd != 'DRF' ";

		private static final String SELECT_PRESELL_LISTING = "SELECT NEW com.delhaize.presell.dto.StoreOrderDTO("
				+ "TPSL001.psellIdNbr, " + "TPSL001.busUnitId, " + "TPSL001.psellDsc, " + "TPSL006.psellLvlDsc, "
				+ "TPSL001.psellStatCd, " + "TPSL001.psellDueDt, " + "TPSL001.plnDistFlg) " + "FROM Presell  TPSL001 "
				+ "INNER JOIN LvlMaint TPSL006 " + "ON (TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr) "
				+ "WHERE 1 = 1 ";

		private static final String COUNT_PRESELL_LISTING = "SELECT COUNT(*) " + "FROM Presell  TPSL001 "
				+ "INNER JOIN LvlMaint TPSL006 " + "ON (TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr) "
				+ "WHERE 1 = 1 ";

		private static final Map<String, String> sortKeysWithRoleRT = new HashedMap<>();

		static {
			sortKeysWithRoleRT.put("presellDsc", "TPSL001.psellDsc");
			sortKeysWithRoleRT.put("busUnitId", "TPSL001.busUnitId");
			sortKeysWithRoleRT.put("presellStatCd", "TPSL003.storeStatCd");
			sortKeysWithRoleRT.put("presellLvlDsc", "TPSL006.psellLvlDsc");
			sortKeysWithRoleRT.put("presellDueDt", "TPSL001.psellDueDt");
			sortKeysWithRoleRT.put(PLN_DIST_FLG, "TPSL001.plnDistFlg");
		}

		private static final Map<String, String> sortKeys = new HashedMap<>();

		static {
			sortKeys.put("presellDsc", "TPSL001.psellDsc");
			sortKeys.put("busUnitId", "TPSL001.busUnitId");
			sortKeys.put("presellLvlDsc", "TPSL006.psellLvlDsc");
			sortKeys.put("presellStatCd", "TPSL001.psellStatCd");
			sortKeys.put("presellDueDt", "TPSL001.psellDueDt");
			sortKeys.put(PLN_DIST_FLG, "TPSL001.plnDistFlg");
		}
	}

	@Override
	public Page<StoreOrderDTO> searchStoreOrder(StoreOrderCriteria criteria, Pageable pageable) {
		StringBuilder queryString = new StringBuilder(SearchStoreOrderConstants.SELECT_PRESELL_LISTING);
		StringBuilder queryCountString = new StringBuilder(SearchStoreOrderConstants.COUNT_PRESELL_LISTING);
		StringBuilder whereClause = new StringBuilder();
		Map<String, Object> parameters = new HashedMap<>();

		buildWhereClause(whereClause, parameters, criteria);

		queryString.append(whereClause);
		queryCountString.append(whereClause);
		if (pageable != null) {
			queryString.append(" ORDER BY ");
			pageable.getSort()
					.forEach(order -> queryString.append(SearchStoreOrderConstants.sortKeys.get(order.getProperty()))
							.append(" ").append(order.getDirection()).append(", "));
			// remove redundant comma
			queryString.append(" TPSL001.psellIdNbr ").append(pageable.getSort().toList().get(0).getDirection());
		} else {
			queryString.append(" ORDER BY TPSL001.psellIdNbr ASC ");
		}

		log.info("Query" + queryString);

		// prepare the search presell query
		TypedQuery<StoreOrderDTO> query = entityManager.createQuery(queryString.toString(), StoreOrderDTO.class);
		parameters.forEach(query::setParameter);

		// prepare the count all elements query
		TypedQuery<Long> countQuery = entityManager.createQuery(queryCountString.toString(), Long.class);
		parameters.forEach(countQuery::setParameter);

		return readPage(query, countQuery, pageable, criteria.getUserRole());
	}

	private void buildWhereClause(StringBuilder whereClause, Map<String, Object> parameters,
			StoreOrderCriteria criteria) {
		if (criteria.getPresellTitle() != null) {
			whereClause.append(" AND UPPER(TPSL001.psellDsc) LIKE CONCAT('%',:psellDsc,'%') ");
			parameters.put("psellDsc", criteria.getPresellTitle().toUpperCase());
		}
		if (criteria.getStatus() != null && !Status.SUBMITTED.equals(criteria.getStatus())) {
			buildQueryBasedOnStatus(whereClause, parameters, criteria);
		}

		if (criteria.getPresellAuthor() != null) {
			whereClause.append(" AND TPSL001.addUserId = :addUserId ");
			parameters.put("addUserId", criteria.getPresellAuthor());
		}

		if (criteria.getPresellLevelId() != null) {
			whereClause.append(" AND TPSL001.psellLvlIdNbr = :psellLvlIdNbr ");
			parameters.put("psellLvlIdNbr", criteria.getPresellLevelId());
		}
		if (criteria.getFromDueDate() != null) {
			whereClause.append(" AND TPSL001.psellDueDt >= :fpsellDueDt ");
			parameters.put("fpsellDueDt", criteria.getFromDueDate());
		}

		if (criteria.getToDueDate() != null) {
			whereClause.append(" AND TPSL001.psellDueDt <= :tpsellDueDt ");
			parameters.put("tpsellDueDt", criteria.getToDueDate());
		}

		if (criteria.getPlannedDis() != null) {
			whereClause.append(" AND TPSL001.plnDistFlg = :plnDistFlg ");
			parameters.put(SearchStoreOrderConstants.PLN_DIST_FLG, criteria.getPlannedDis());
		}

		if (criteria.getStoreNo() != null) {
			int storeNbr = Integer.parseInt(criteria.getStoreNo());
			whereClause.append(" AND TPSL001.psellIdNbr IN ( ");
			whereClause.append(
					" SELECT DISTINCT ps.storePk.psellIdNbr FROM PresellStore ps WHERE ps.storePk.storeNbr = :storeNbr )");
			parameters.put("storeNbr", storeNbr);

		}
	}

	private void buildQueryBasedOnStatus(StringBuilder whereClause, Map<String, Object> parameters,
			StoreOrderCriteria criteria) {
		var parameter = "psellStatCd";
		if (Status.ALL_EXCLUDING_CLOSED.equals(criteria.getStatus())
				|| Status.ALL_INCLUDING_CLOSED.equals(criteria.getStatus())) {

			if (Status.ALL_EXCLUDING_CLOSED.equals(criteria.getStatus())) {
				if (criteria.getStoreNo() != null) {
					whereClause.append(" AND TPSL001.psellStatCd != :psellStatCd");
					parameters.put(parameter, Status.SAVED_AS_DRAFT.getKey());
				}
				whereClause.append(" AND TPSL001.psellStatCd != :psellStatCd");
				parameters.put(parameter, Status.CLOSED.getKey());
			}
		} else {
			whereClause.append(" AND TPSL001.psellStatCd = :psellStatCd");
			switch (criteria.getStatus()) {
			case PENDING:
				parameters.put(parameter, Status.PENDING.getKey());
				break;
			case REC_FROM_STORES:
				parameters.put(parameter, Status.REC_FROM_STORES.getKey());
				break;
			case CLOSED:
				parameters.put(parameter, Status.CLOSED.getKey());
				break;
			default:
				throw new IllegalArgumentException("invalid status.");
			}
		}
	}
}
