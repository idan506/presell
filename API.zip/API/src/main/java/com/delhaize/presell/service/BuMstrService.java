package com.delhaize.presell.service;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.dto.projection.BusUnitProjection;

import java.util.List;

public interface BuMstrService {
    List<BusUnitDTO> getBusUnit();
}
