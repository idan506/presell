package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.dto.ClassificationDTO;
import com.delhaize.presell.dto.PresellLevelDTO;
import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.projection.ClassificationProjection;
import com.delhaize.presell.dto.request.PresellClassificationRequestDTO;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.PresellClassificationService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;
import com.delhaize.web.model.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;


@CrossOrigin
@Log4j2
@RestController
@RequestMapping("api/v1/classification")
@Tag(name = "classification", description = "the classification API")
public class PresellClassificationController {

    private final PresellClassificationService classificationService;

    @Autowired
    public PresellClassificationController(PresellClassificationService classificationService) {
        this.classificationService = classificationService;
    }

    @Operation(summary = "Get Classifications", tags = { "classification" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = ClassificationDTO.class))),
            @ApiResponse(responseCode = "404", description = "Classification not found", content = @Content)
    })
    @Secured
    @GetMapping(value = "", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<ClassificationDTO>> getClassification() {
        log.info("getClassification");
        var rs = classificationService.getClassification();
        // set the fetch UTC time
        Timestamp currTs = DatetimeUtils.getUTCTimestamp();
        rs.forEach(e -> e.setFetchTime(currTs));
        log.info("The fetch classifications UTC time: {}", currTs);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Delete Classification", tags = { "classification" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Integer.class))),
            @ApiResponse(responseCode = "409", description = "Data Sync Exception", content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @DeleteMapping
    public ResponseEntity<Integer> deleteClassification(@RequestBody PresellClassificationRequestDTO request,
                                                        @RequestAttribute("user") UserSSOInfo user) {
        log.info("deleteClassification");
        log.info("request by {}", user.getUserId());
        try {
            request.setUserId(user.getUserId());
            var rs = classificationService.deleteClassification(request);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            if (ExceptionHandlingHelper.isResponseErrorType(ResponseError.DATA_SYNC_EXCEPTION, e)) {
                throw e;
            }
            throw ExceptionHandlingHelper.newGenericException(ResponseError.DELETE_CLASSIFICATION_ERROR, e);
        }
    }

    @Operation(summary = "Get Business Unit", tags = { "classification" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Integer.class))),
            @ApiResponse(responseCode = "409", description = "Data Sync Exception", content = @Content(schema = @Schema(implementation = ApiError.class)))
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @PostMapping
    public ResponseEntity<Integer> insertOrUpdatePresellLevel(@RequestBody PresellClassificationRequestDTO request,
                                                              @RequestAttribute("user") UserSSOInfo user) {
        log.info("insertOrUpdatePresellLevel");
        log.info("request by {}", user.getUserId());
        try {
            request.setUserId(user.getUserId());
            var rs = classificationService.insertOrUpdateClassification(request);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            if (ExceptionHandlingHelper.isResponseErrorType(ResponseError.DATA_SYNC_EXCEPTION, e)) {
                throw e;
            }
            throw ExceptionHandlingHelper.newGenericException(ResponseError.INSERT_OR_UPDATE_CLASSIFICATION_ERROR, e);
        }
    }

}
