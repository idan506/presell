package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TLOC003_ADDRESS")
public class Address {

  @EmbeddedId
  private AddressPK addressPk;

  @Column(name="CNTCT_LN_1_ADR")
  private String cntctLn1Adr;

  @Column(name="CNTCT_LN_2_ADR")
  private String cntctLn2Adr;

  @Column(name="CNTCT_CITY_NAM")
  private String cntctCityNam;

  @Column(name="CNTCT_ST_CD")
  private String cntctStCd;

  @Column(name="CNTCT_PSTL_CD")
  private String cntctPstlCd;

  @Column(name="CNTCT_CNTRY_NAM")
  private String cntctCntryNam;

  @Column(name="LAT_NBR")
  private java.math.BigDecimal latNbr;

  @Column(name="LON_NBR")
  private java.math.BigDecimal lonNbr;

  @Column(name="TZ_CD")
  private String tzCd;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    Address address = (Address) o;
    return addressPk != null && Objects.equals(addressPk, address.addressPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(addressPk);
  }
}
