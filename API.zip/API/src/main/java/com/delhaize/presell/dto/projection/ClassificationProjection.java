package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

import java.sql.Timestamp;

public interface ClassificationProjection {

    Integer getClassificationId();

    @Value("#{target.classificationDsc.trim()}")
    String getClassificationDsc();

    @Value("#{T(com.delhaize.presell.util.DatetimeUtils).UTCTimestamp}")
    Timestamp getFetchTime();
}
