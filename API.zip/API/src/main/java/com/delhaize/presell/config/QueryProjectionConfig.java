package com.delhaize.presell.config;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.core.convert.support.GenericConversionService;
import org.springframework.util.ObjectUtils;

import com.delhaize.presell.annotation.QueryProjection;
import com.google.common.base.CaseFormat;

import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Configuration
@SuppressWarnings({"java:S3011"})
public class QueryProjectionConfig {

    @Autowired
    private ApplicationContext applicationContext;

    /**
     * Maps @QueryProjection annotated class to corresponding Dynamic Converter
     */
    @PostConstruct
    public void init() {
        applicationContext.getBeansWithAnnotation(QueryProjection.class).values().stream().forEach(object -> {
            Class<? super Object> queryProjectionAnnotatedClass = (Class<? super Object>) object.getClass();
            addConverter(queryProjectionAnnotatedClass);
        });
    }

    public void addConverter(Class<? super Object> queryProjectionAnnotatedClass) {
        QueryProjection queryProjection = queryProjectionAnnotatedClass.getAnnotation(QueryProjection.class);
        log.info("Added: Dynamic Converter to @QueryProjection(nativeQuery=" + queryProjection.nativeQuery() + ") annotated class, class = {}", queryProjectionAnnotatedClass.getName());
        GenericConversionService genericConversionService = ((GenericConversionService) DefaultConversionService.getSharedInstance());
        genericConversionService.addConverter(Map.class, queryProjectionAnnotatedClass, resultSetMap -> {
            try {
                Object queryProjectionObject = queryProjectionAnnotatedClass.getDeclaredConstructor().newInstance();
                if (!ObjectUtils.isEmpty(resultSetMap) && !ObjectUtils.isEmpty(queryProjectionObject)) {
                    Class<?> queryProjectionObjectClass = queryProjectionObject.getClass();
                    Arrays.stream(BeanUtils.getPropertyDescriptors(queryProjectionObjectClass)).forEach(propertyDescriptor ->
                            writeMethodInvoke(queryProjectionAnnotatedClass, queryProjection, resultSetMap, queryProjectionObject, propertyDescriptor)
                    );
                }
                return queryProjectionObject;
            } catch (Exception ex) {
                throw new FatalBeanException("Error adding @QueryProjection annotated class with Dynamic Converter, class = " + queryProjectionAnnotatedClass.getName(), ex);
            }
        });
    }

    private void writeMethodInvoke(Class<? super Object> queryProjectionAnnotatedClass, QueryProjection queryProjection, Map<String, Object> resultSetMap, Object queryProjectionObjectInstance, PropertyDescriptor propertyDescriptor) {
        if (Objects.nonNull(propertyDescriptor.getWriteMethod())) {
            String fieldName = null;
            Object fieldValue = null;
            try {
                fieldName = queryProjection.nativeQuery() ? CaseFormat.LOWER_CAMEL.to(CaseFormat.UPPER_UNDERSCORE, propertyDescriptor.getName()) : propertyDescriptor.getName();
                fieldValue = resultSetMap.get(fieldName);
                if (Objects.nonNull(fieldValue)) {
                    Method writeMethod = propertyDescriptor.getWriteMethod();
                    if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {
                        writeMethod.setAccessible(true);
                    }

                    Class<?> fieldType = queryProjectionObjectInstance.getClass().getDeclaredField(propertyDescriptor.getName()).getType();
                    switch (fieldType.getName()) {
                        case "java.lang.Integer":
                            writeMethod.invoke(queryProjectionObjectInstance, Integer.parseInt(fieldValue.toString()));
                            break;
                        case "java.lang.Long":
                            writeMethod.invoke(queryProjectionObjectInstance, Long.parseLong(fieldValue.toString()));
                            break;
                        case "java.lang.Double":
                            writeMethod.invoke(queryProjectionObjectInstance, Double.parseDouble(fieldValue.toString()));
                            break;
                        case "java.lang.String":
                            writeMethod.invoke(queryProjectionObjectInstance, String.valueOf(fieldValue));
                            break;
                        case "java.time.LocalDate":
                            writeMethod.invoke(queryProjectionObjectInstance, LocalDate.parse(fieldValue.toString()));
                            break;
                        case "java.time.LocalDateTime":
                            writeMethod.invoke(queryProjectionObjectInstance, LocalDateTime.parse(fieldValue.toString()));
                            break;
                        case "java.time.LocalTime":
                            writeMethod.invoke(queryProjectionObjectInstance, LocalTime.parse(fieldValue.toString()));
                            break;
                        default:
                            writeMethod.invoke(queryProjectionObjectInstance, fieldValue);
                    }
                }
            } catch (Exception ex) {
                throw new FatalBeanException("Error fieldName(" + fieldName + ") with fieldValue(" + fieldValue + ") doesn't match data type of query project class(" + queryProjectionAnnotatedClass.getName() + ")", ex);
            }
        }
    }

}