package com.delhaize.presell.service;

import com.delhaize.presell.dto.ClassificationDTO;
import com.delhaize.presell.dto.request.PresellClassificationRequestDTO;

import java.util.List;

public interface PresellClassificationService {
    List<ClassificationDTO> getClassification();
    int deleteClassification(PresellClassificationRequestDTO request);
    int insertOrUpdateClassification(PresellClassificationRequestDTO request);
}
