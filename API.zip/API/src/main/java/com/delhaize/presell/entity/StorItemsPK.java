package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class StorItemsPK implements Serializable {


  @Column(name="PSELL_ID_NBR")
  private Integer psellIdNbr;

  @Column(name="STORE_NBR")
  private Integer storeNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;

  @Column(name="SHIP_DT")
  private java.sql.Date shipDt;
}
