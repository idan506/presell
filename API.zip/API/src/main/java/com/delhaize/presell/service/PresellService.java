package com.delhaize.presell.service;

import com.delhaize.presell.dto.PresellDTO;
import com.delhaize.presell.dto.PresellStoreDetailDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import org.springframework.data.domain.Page;

import javax.validation.Valid;
import java.io.ByteArrayInputStream;
import java.util.List;

public interface PresellService {

    Page<PresellDTO> searchPresell(PresellSearchCriteria criteria, PaginationAndSortDTO paginationAndSortDTO);

    ByteArrayInputStream downloadPresellToXLS(PresellSearchCriteria criteria, String filename);

    List<String> getUserIds();

    String deletePresellList(@Valid List<Integer> request);

    int savePresell(PresellSaveRequestDTO request);

    int sendToAdditionalStores(PresellSaveRequestDTO request);

    PresellStoreDetailDTO getPresellDetails(Integer psellIdNbr);

    ByteArrayInputStream downloadItemList(Integer psellIdNbr, String fileName);
}
