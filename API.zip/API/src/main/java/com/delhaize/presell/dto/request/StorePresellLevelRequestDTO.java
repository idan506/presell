package com.delhaize.presell.dto.request;

import com.delhaize.presell.dto.StorePresellLevelDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class StorePresellLevelRequestDTO {
    private List<StorePresellLevelDTO> storePresellLevelDTOS;
    private String userId;
}
