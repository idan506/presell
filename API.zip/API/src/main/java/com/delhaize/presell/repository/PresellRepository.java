package com.delhaize.presell.repository;

import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.projection.PresellItem;
import com.delhaize.presell.dto.projection.PresellProjection;
import com.delhaize.presell.entity.Presell;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.sql.Timestamp;
import java.util.List;

@Repository
public interface PresellRepository extends JpaRepository<Presell, Integer> {

	@Query("select distinct addUserId from Presell")
	List<String> getUserIDs();

	@Modifying
	@Transactional
	@Query("delete from Presell where psellIdNbr in :psellId")
	void deletPreSellID(@Param("psellId") List<Integer> psellId);

	@Query("select max(psellIdNbr) from Presell")
	int getMaxId();

	@Query(value = "UPDATE {h-schema}TPSL001_PRESELL " + " SET " + " PSELL_STAT_CD = :statCd, "
			+ " MOD_USER_ID = :userId, " + " MOD_TS = :modTs "
			+ " WHERE PSELL_ID_NBR = :psellIdNbr ", nativeQuery = true)
	int updateStatus(String statCd, String userId, Timestamp modTs, Integer psellIdNbr);

	@Query("select p from Presell p where psellIdNbr = :psellId")
	PresellProjection getPresellData(@Param("psellId") int psellId);

	@Query(value = "SELECT " + " TPSL001.psellIdNbr as psellIdNbr," + "TPSL001.psellDsc as psellDsc,"
			+ "TPSL001.busUnitId as busUnitId," + "TPSL006.psellLvlDsc as psellLvlDsc,"
			+ "TPSL001.psellStatCd as psellStatCd," + "TPSL001.psellDueDt as psellDueDt,"
			+ "TPSL001.rmndrEmailDt as rmndrEmailDt," + "TPSL001.psellCmtTxt as psellCmtTxt, "
			+ "TPSL001.plnDistFlg as plnDistFlg, " + "TPSL001.addUserId as addUserId " + "FROM Presell  TPSL001, "
			+ "LvlMaint  TPSL006 " + "WHERE TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr "
			+ "AND TPSL001.psellIdNbr =:psellId ")
	PresellItem getPresell(@Param("psellId") int psellId);

	@Query("select psellLvlIdNbr from Presell where psellIdNbr =:psellId")
	Integer getPresellLvlId(@Param("psellId") int psellId);

	@Query(value = "SELECT TPSL001.psellIdNbr as psellIdNbr, " + "TPSL001.psellDsc as psellDsc, "
			+ "TPSL001.busUnitId as busUnitId, " + "TPSL006.psellLvlDsc as psellLvlDsc, "
			+ "TPSL001.psellStatCd as psellStatCd, " + "TPSL001.psellDueDt as psellDueDt, "
			+ "TPSL001.plnDistFlg as plnDistFlg " + "FROM Presell TPSL001, " + "LvlMaint TPSL006 "
			+ "WHERE TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr " + "AND TPSL001.psellIdNbr =:psellIdNbr ")
	PresellReportDTO getPresellReportDetails(@Param("psellIdNbr") int psellIdNbr);

	@Query(value = "SELECT psellLvlIdNbr FROM Presell WHERE psellIdNbr =:presellId ")

	int getLvlId(@Param("presellId") Integer presellId);

	@Query(nativeQuery = true, value = "select current timestamp from sysibm.sysdummy1 ")
	Timestamp getCurrentDate();

	@Query(value="SELECT DISTINCT addUserId FROM Presell")
	 List <String> getPresellAuthors();
}
