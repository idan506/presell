package com.delhaize.presell.dto.request;

import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.dto.PresellDetailDTO;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class PresellSaveRequestDTO {
    @NotNull
    private PresellDetailDTO presellDetail;
    @NotNull
    private SavePresellAction action;
    @NotNull
    private String userId;
}
