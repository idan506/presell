package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPSL007_LVL_MAPNG")
public class LvlMapng {

  @EmbeddedId
  private LvlMapngPK lvlMapngPk;

  @Column(name="PSELL_CLS_ID_NBR")
  private Integer psellClsIdNbr;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @Column(name="ADD_TS")
  @CreationTimestamp
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  @UpdateTimestamp
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    LvlMapng lvlMapng = (LvlMapng) o;
    return lvlMapngPk != null && Objects.equals(lvlMapngPk, lvlMapng.lvlMapngPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(lvlMapngPk);
  }
}
