package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

public interface StoreProjection {
	Integer getStoreNbr();
	
//	@Value("#{target.storeNam.trim()}")
	String getStoreNam();
	
//	@Value("#{target.geoRegnCd.trim()}")
	String getGeoRegnCd();
	
//	@Value("#{target.locOrgDsc.trim()}")
	String getLocOrgDsc();
	
	Integer getPsellLvlIdNbr();
	
	@Value("#{target.psellLvlClsCd.trim()}")
	String getPsellLvlClsCd();
}
