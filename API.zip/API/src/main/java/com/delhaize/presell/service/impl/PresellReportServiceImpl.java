package com.delhaize.presell.service.impl;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.MissingOrderProjection;
import com.delhaize.presell.dto.projection.StoreItemProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.repository.ItemsRepository;
import com.delhaize.presell.repository.PresellRepository;
import com.delhaize.presell.repository.StorItemsRepository;
import com.delhaize.presell.repository.dao.PresellReportDAO;
import com.delhaize.presell.service.PresellReportService;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.List;

@Log4j2
@Service
public class PresellReportServiceImpl implements PresellReportService {

    private final ItemsRepository itemsRepository;
    private final StorItemsRepository storItemsRepository;
    private final PresellRepository presellRepository;
    private final PresellReportDAO presellReportDAO;

    @Autowired
    public PresellReportServiceImpl(ItemsRepository itemsRepository, StorItemsRepository storItemsRepository,
                                    PresellRepository presellRepository, PresellReportDAO presellReportDAO) {
        this.itemsRepository = itemsRepository;
        this.storItemsRepository = storItemsRepository;
        this.presellRepository = presellRepository;
        this.presellReportDAO = presellReportDAO;
    }

    @Override
    public List<ItemProjection> getListItemReport(Integer psellIdNbr) {
        log.info("getListItemReport:{}", psellIdNbr);
        return itemsRepository.getListItem(psellIdNbr);
    }

    @Override
    public List<StoreItemProjection> getListStoreItemReport(Integer psellIdNbr) {
        log.info("getListStoreItemReport:{}", psellIdNbr);
        return storItemsRepository.getListStoreItem(psellIdNbr);
    }

    @Override
    public MissingOrderDTO getListMissingOrderReport(Integer psellIdNbr) {
        log.info("getListMissingOrderReport:{}", psellIdNbr);
        MissingOrderDTO listResults = new MissingOrderDTO();
        List<MissingOrderProjection> listMissingReports = null;
        List<MissingOrderProjection> listDraftReports = null;
        listMissingReports = storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SEND_TO_STORES);
        if (listMissingReports != null) {
            listResults.setListMissingReports(listMissingReports);
        }

        listDraftReports = storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SAVED_AS_DRAFT);
        if (listDraftReports != null) {
            listResults.setListDraftReports(listDraftReports);
        }

        return listResults;
    }

    @Override
    public ByteArrayInputStream downLoadStorePresellItemReport(Integer psellIdNbr, String fileName) {
        log.info("downLoadStorePresellItemReport:{}{}", psellIdNbr, fileName);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HSSFWorkbook wb = new HSSFWorkbook();
        try {
            List<ItemProjection> listItem = itemsRepository.getListItem(psellIdNbr);
            PresellReportDTO presellReport;

            presellReport = presellRepository.getPresellReportDetails(psellIdNbr);

            HSSFSheet sheet = wb.createSheet(fileName);

            /*
             * Styles and Formatting informatiion added here
             */
            HSSFPrintSetup ps = sheet.getPrintSetup();
            sheet.setAutobreaks(true);

            ps.setFitHeight((short) 1);
            ps.setFitWidth((short) 1);

            HSSFFont styleBold = wb.createFont();
            styleBold.setBold(true);

            HSSFCellStyle styleCaption = wb.createCellStyle();
            styleCaption.setWrapText(false);
            styleCaption.setBorderBottom(BorderStyle.THIN);
            styleCaption.setBorderLeft(BorderStyle.THIN);
            styleCaption.setBorderRight(BorderStyle.THIN);
            styleCaption.setBorderTop(BorderStyle.THIN);
            styleCaption.setAlignment(HorizontalAlignment.CENTER);
            styleCaption.setFont(styleBold);

            HSSFCellStyle cellStyle = wb.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setBorderRight(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);

            HSSFCellStyle cellBoldStyle = wb.createCellStyle();
            cellBoldStyle.setWrapText(true);
            cellBoldStyle.setFont(styleBold);

            /*
             * END OF Styles and Formatting informatiion added here
             */

            sheet.setColumnWidth((short) 0, (short) 4000);
            sheet.setColumnWidth((short) 1, (short) 2500);
            sheet.setColumnWidth((short) 2, (short) 4000);
            sheet.setColumnWidth((short) 3, (short) 4000);
            sheet.setColumnWidth((short) 4, (short) 2500);
            sheet.setColumnWidth((short) 5, (short) 2500);
            sheet.setColumnWidth((short) 6, (short) 4000);
            sheet.setColumnWidth((short) 7, (short) 6000);
            sheet.setColumnWidth((short) 8, (short) 6000);
            sheet.setColumnWidth((short) 9, (short) 6000);

            // Create a cell and put a value in it.
            HSSFRow row = sheet.createRow((short) 0);
            // Create a cell and put a value in it.
            HSSFCell cell = row.createCell((short) 3);
            cell.setCellValue("Presell Item Report");
            cell.setCellStyle(styleCaption);

            // Presell Header Details

            row = sheet.createRow((short) 2);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.PRESELL_TITLE);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPsellDsc());

            cell = row.createCell((short) 3);
            cell.setCellValue(PresellConstants.BUSINESS_UNIT);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 4).setCellValue(presellReport.getBusUnitId());

            row = sheet.createRow((short) 3);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.AUTHOR);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPresellAuthor());

            cell = row.createCell((short) 3);
            cell.setCellValue(PresellConstants.PRESELL_LEVEL);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 4).setCellValue(presellReport.getPsellLvlDsc());

            row = sheet.createRow((short) 4);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.DUE_DATE);
            cell.setCellStyle(cellBoldStyle);
            SimpleDateFormat dateFormat = new SimpleDateFormat(PresellConstants.MM_DD_YYYY);
            row.createCell((short) 1).setCellValue(dateFormat.format(presellReport.getPsellDueDt()));

            cell = row.createCell((short) 3);
            cell.setCellValue(PresellConstants.STATUS);
            cell.setCellStyle(cellBoldStyle);

            if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.SEND_TO_STORES)) {
                row.createCell((short) 4).setCellValue(Status.SEND_TO_STORES.getStatusDsc());
            } else if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.REC_FROM_STORES)) {
                row.createCell((short) 4).setCellValue(Status.REC_FROM_STORES.getStatusDsc());
            } else {
                row.createCell((short) 4).setCellValue(Status.CLOSED.getStatusDsc());
            }
            /* End of Header Details */

            row = sheet.createRow((short) 6);
            cell = row.createCell((short) 0);

            cell.setCellValue("Item#");
            row.createCell((short) 1).setCellValue("Quantity");
            row.createCell((short) 2).setCellValue("Shipment Date");
            row.createCell((short) 3).setCellValue("Pack/Size(z)");
            row.createCell((short) 4).setCellValue("Item Cost");
            row.createCell((short) 5).setCellValue("Item SRP");
            row.createCell((short) 6).setCellValue("Gross Margin(%)");
            row.createCell((short) 7).setCellValue("Description");
            row.createCell((short) 8).setCellValue("Comment");
            row.createCell((short) 9).setCellValue("URL");

            row.getCell((short) 0).setCellStyle(styleCaption);
            row.getCell((short) 1).setCellStyle(styleCaption);
            row.getCell((short) 2).setCellStyle(styleCaption);
            row.getCell((short) 3).setCellStyle(styleCaption);
            row.getCell((short) 4).setCellStyle(styleCaption);
            row.getCell((short) 5).setCellStyle(styleCaption);
            row.getCell((short) 6).setCellStyle(styleCaption);
            row.getCell((short) 7).setCellStyle(styleCaption);
            row.getCell((short) 8).setCellStyle(styleCaption);
            row.getCell((short) 9).setCellStyle(styleCaption);

            for (int p = 0; p < listItem.size(); p++) {
                ItemProjection objItem = listItem.get(p);
                row = sheet.createRow((short) p + 7);

                // Create a cell and put a value in it.
                cell = row.createCell((short) 0);

                if (objItem.getItemNbr().toString().contains("-")) {
                    cell.setCellValue(PresellConstants.DSD);
                } else {
                    cell.setCellValue(objItem.getItemNbr().toString());
                }
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 1);
                cell.setCellValue(objItem.getItemOrderQty().setScale(0, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 2);
                cell.setCellValue(dateFormat.format(objItem.getShipDt()));
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 3);
                cell.setCellValue(objItem.getItemPkQty() + "/" + objItem.getItemSzCnt() + objItem.getItemSzCd());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 4);
                cell.setCellValue(objItem.getItemCapCst().setScale(2, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 5);
                cell.setCellValue(objItem.getRtlPrc().setScale(2, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 6);
                cell.setCellValue(objItem.getPsellGrmrgAmt().setScale(2, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 7);
                cell.setCellValue(objItem.getItemDsc());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 8);
                cell.setCellValue(objItem.getPsellItemCmtTxt());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 9);
                cell.setCellValue(objItem.getItemImgUrl());
                cell.setCellStyle(cellStyle);
            }
            wb.write(out);
        } catch (IOException e) {
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                wb.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    @Override
    public ByteArrayInputStream downLoadStorePresellStoreItemReport(Integer psellIdNbr, String fileName) {
        log.info("downLoadStorePresellStoreItemReport:{}{}", psellIdNbr, fileName);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HSSFWorkbook wb = new HSSFWorkbook();
        try {
            List<StoreItemProjection> listStore = storItemsRepository.getListStoreItem(psellIdNbr);
            PresellReportDTO presellReport;
            presellReport = presellRepository.getPresellReportDetails(psellIdNbr);
            HSSFSheet sheet = wb.createSheet(fileName);

            /*
             * Styles and Formatting informatiion added here
             */
            HSSFPrintSetup ps = sheet.getPrintSetup();
            sheet.setAutobreaks(true);

            ps.setFitHeight((short) 1);
            ps.setFitWidth((short) 1);

            HSSFFont styleBold = wb.createFont();
            styleBold.setBold(true);

            HSSFCellStyle styleCaption = wb.createCellStyle();
            styleCaption.setWrapText(false);
            styleCaption.setBorderBottom(BorderStyle.THIN);
            styleCaption.setBorderLeft(BorderStyle.THIN);
            styleCaption.setBorderRight(BorderStyle.THIN);
            styleCaption.setBorderTop(BorderStyle.THIN);
            styleCaption.setAlignment(HorizontalAlignment.CENTER);
            styleCaption.setFont(styleBold);

            HSSFCellStyle cellStyle = wb.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setBorderRight(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);

            HSSFCellStyle cellBoldStyle = wb.createCellStyle();
            cellBoldStyle.setWrapText(true);
            cellBoldStyle.setFont(styleBold);

            /*
             * END OF Styles and Formatting informatiion added here
             */

            sheet.setColumnWidth((short) 0, (short) 4000);
            sheet.setColumnWidth((short) 1, (short) 4000);
            sheet.setColumnWidth((short) 2, (short) 4000);
            sheet.setColumnWidth((short) 3, (short) 3000);
            sheet.setColumnWidth((short) 4, (short) 4000);
            sheet.setColumnWidth((short) 5, (short) 4000);
            sheet.setColumnWidth((short) 6, (short) 4000);
            sheet.setColumnWidth((short) 7, (short) 3000);
            sheet.setColumnWidth((short) 8, (short) 3000);
            sheet.setColumnWidth((short) 9, (short) 4000);
            sheet.setColumnWidth((short) 10, (short) 6000);
            sheet.setColumnWidth((short) 11, (short) 6000);
            sheet.setColumnWidth((short) 12, (short) 6000);

            // Create a cell and put a value in it.
            HSSFRow row = sheet.createRow((short) 0);
            // Create a cell and put a value in it.
            HSSFCell cell = row.createCell((short) 3);
            cell.setCellValue("Presell Store-Item Report");
            cell.setCellStyle(styleCaption);

            // Presell Header Details

            row = sheet.createRow((short) 2);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.PRESELL_TITLE);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPsellDsc());

            cell = row.createCell((short) 3);
            cell.setCellValue(PresellConstants.BUSINESS_UNIT);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 4).setCellValue(presellReport.getBusUnitId());

            row = sheet.createRow((short) 3);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.AUTHOR);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPresellAuthor());

            cell = row.createCell((short) 3);
            cell.setCellValue(PresellConstants.PRESELL_LEVEL);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 4).setCellValue(presellReport.getPsellLvlDsc());

            row = sheet.createRow((short) 4);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.DUE_DATE);
            cell.setCellStyle(cellBoldStyle);
            SimpleDateFormat dateFormat = new SimpleDateFormat(PresellConstants.MM_DD_YYYY);
            row.createCell((short) 1).setCellValue(dateFormat.format(presellReport.getPsellDueDt()));

            cell = row.createCell((short) 3);
            cell.setCellValue(PresellConstants.STATUS);
            cell.setCellStyle(cellBoldStyle);

            if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.SEND_TO_STORES)) {
                row.createCell((short) 4).setCellValue(Status.SEND_TO_STORES.getStatusDsc());
            } else if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.REC_FROM_STORES)) {
                row.createCell((short) 4).setCellValue(Status.REC_FROM_STORES.getStatusDsc());
            } else {
                row.createCell((short) 4).setCellValue(Status.CLOSED.getStatusDsc());
            }
            /* End of Header Details */

            row = sheet.createRow((short) 6);
            cell = row.createCell((short) 0);

            cell.setCellValue(PresellConstants.STORENO);

            row.createCell((short) 1).setCellValue(PresellConstants.DISTRICT);
            row.createCell((short) 2).setCellValue("Item#");

            row.createCell((short) 3).setCellValue("Quantity");
            row.createCell((short) 4).setCellValue("Classification");
            row.createCell((short) 5).setCellValue("Shipment Date");

            row.createCell((short) 6).setCellValue("Pack/Size(z)");
            row.createCell((short) 7).setCellValue("Item Cost");
            row.createCell((short) 8).setCellValue("Item SRP");
            row.createCell((short) 9).setCellValue("Gross Margin(%)");
            row.createCell((short) 10).setCellValue("Description");
            row.createCell((short) 11).setCellValue("Comment");
            row.createCell((short) 12).setCellValue("URL");

            row.getCell((short) 0).setCellStyle(styleCaption);
            row.getCell((short) 1).setCellStyle(styleCaption);
            row.getCell((short) 2).setCellStyle(styleCaption);
            row.getCell((short) 3).setCellStyle(styleCaption);
            row.getCell((short) 4).setCellStyle(styleCaption);
            row.getCell((short) 5).setCellStyle(styleCaption);
            row.getCell((short) 6).setCellStyle(styleCaption);
            row.getCell((short) 7).setCellStyle(styleCaption);
            row.getCell((short) 8).setCellStyle(styleCaption);
            row.getCell((short) 9).setCellStyle(styleCaption);
            row.getCell((short) 10).setCellStyle(styleCaption);
            row.getCell((short) 11).setCellStyle(styleCaption);
            row.getCell((short) 12).setCellStyle(styleCaption);

            for (int p = 0; p < listStore.size(); p++) {
                StoreItemProjection objStoreItem = listStore.get(p);

                row = sheet.createRow((short) p + 7);

                // Create a cell and put a value in it.

                cell = row.createCell((short) 0);
                cell.setCellValue(objStoreItem.getStoreNbr());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 1);
                cell.setCellValue(objStoreItem.getLocOrgDsc());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 2);
                if (objStoreItem.getItemNbr().toString().contains("-")) {
                    cell.setCellValue(PresellConstants.DSD);
                } else {
                    cell.setCellValue(objStoreItem.getItemNbr().toString());
                }
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 3);
                cell.setCellValue(objStoreItem.getItemOrderQty().setScale(0, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 4);
                cell.setCellValue(objStoreItem.getPsellLvlClsCd());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 5);
                cell.setCellValue(dateFormat.format(objStoreItem.getShipDt()));
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 6);
                cell.setCellValue(
                        objStoreItem.getItemPkQty() + "/" + objStoreItem.getItemSzCnt() + objStoreItem.getItemSzCd());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 7);
                cell.setCellValue(objStoreItem.getItemCapCst().setScale(2, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 8);
                cell.setCellValue(objStoreItem.getRtlPrc().setScale(2, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 9);
                cell.setCellValue(objStoreItem.getPsellGrmrgAmt().setScale(2, RoundingMode.HALF_EVEN).toString());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 10);
                cell.setCellValue(objStoreItem.getItemDsc());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 11);
                cell.setCellValue(objStoreItem.getPsellItemCmtTxt());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 12);
                cell.setCellValue(objStoreItem.getItemImgUrl());
                cell.setCellStyle(cellStyle);
            }
            wb.write(out);
        } catch (IOException e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                wb.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    @Override
    public ByteArrayInputStream downLoadStorePresellMissingOrderReport(Integer psellIdNbr, String fileName) {
        log.info("downLoadStorePresellMissingOrderReport:{}{}", psellIdNbr, fileName);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HSSFWorkbook wb = new HSSFWorkbook();
        try {
            List<MissingOrderProjection> listMissingReports;
            listMissingReports = storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SEND_TO_STORES);

            PresellReportDTO presellReport;
            presellReport = presellRepository.getPresellReportDetails(psellIdNbr);


            HSSFSheet sheet = wb.createSheet(fileName);

            /*
             * Styles and Formatting informatiion added here
             */
            HSSFPrintSetup ps = sheet.getPrintSetup();
            sheet.setAutobreaks(true);

            ps.setFitHeight((short) 1);
            ps.setFitWidth((short) 1);

            HSSFFont styleBold = wb.createFont();
            styleBold.setBold(true);

            HSSFCellStyle styleCaption = wb.createCellStyle();
            styleCaption.setWrapText(false);
            styleCaption.setBorderBottom(BorderStyle.THIN);
            styleCaption.setBorderLeft(BorderStyle.THIN);
            styleCaption.setBorderRight(BorderStyle.THIN);
            styleCaption.setBorderTop(BorderStyle.THIN);
            styleCaption.setAlignment(HorizontalAlignment.CENTER);
            styleCaption.setFont(styleBold);

            HSSFCellStyle cellStyle = wb.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setBorderRight(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);

            HSSFCellStyle cellBoldStyle = wb.createCellStyle();
            cellBoldStyle.setWrapText(true);
            cellBoldStyle.setFont(styleBold);

            /*
             * END OF Styles and Formatting informatiion added here
             */

            // Create a cell and put a value in it.
            HSSFRow row = sheet.createRow((short) 0);
            // Create a cell and put a value in it.
            HSSFCell cell = row.createCell((short) 1);
            cell.setCellValue("Presell Missing Order Report");
            cell.setCellStyle(styleCaption);

            row = sheet.createRow((short) 1);
            row.createCell((short) 0);

            // Presell Header Details

            row = sheet.createRow((short) 2);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.PRESELL_TITLE);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPsellDsc());

            cell = row.createCell((short) 2);
            cell.setCellValue(PresellConstants.BUSINESS_UNIT);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 3).setCellValue(presellReport.getBusUnitId());

            row = sheet.createRow((short) 3);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.AUTHOR);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPresellAuthor());

            cell = row.createCell((short) 2);
            cell.setCellValue(PresellConstants.PRESELL_LEVEL);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 3).setCellValue(presellReport.getPsellLvlDsc());

            row = sheet.createRow((short) 4);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.DUE_DATE);
            cell.setCellStyle(cellBoldStyle);
            SimpleDateFormat dateFormat = new SimpleDateFormat(PresellConstants.MM_DD_YYYY);
            row.createCell((short) 1).setCellValue(dateFormat.format(presellReport.getPsellDueDt()));

            cell = row.createCell((short) 2);
            cell.setCellValue(PresellConstants.STATUS);
            cell.setCellStyle(cellBoldStyle);

            if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.SEND_TO_STORES)) {
                row.createCell((short) 3).setCellValue(Status.SEND_TO_STORES.getStatusDsc());
            } else if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.REC_FROM_STORES)) {
                row.createCell((short) 3).setCellValue(Status.REC_FROM_STORES.getStatusDsc());
            } else {
                row.createCell((short) 3).setCellValue(Status.CLOSED.getStatusDsc());
            }
            /* End of Header Details */

            row = sheet.createRow((short) 5);
            row.createCell((short) 0);

            row = sheet.createRow((short) 6);
            cell = row.createCell((short) 0);

            cell.setCellValue(PresellConstants.STORENO);
            cell.setCellStyle(styleCaption);

            row.createCell((short) 1).setCellValue("Store Name");
            row.createCell((short) 2).setCellValue(PresellConstants.DISTRICT);

            row.getCell((short) 1).setCellStyle(styleCaption);
            row.getCell((short) 2).setCellStyle(styleCaption);

            sheet.setColumnWidth((short) 0, (short) 3000);
            sheet.setColumnWidth((short) 1, (short) 7000);
            sheet.setColumnWidth((short) 2, (short) 6000);

            for (int p = 0; p < listMissingReports.size(); p++) {
                MissingOrderProjection objMissOrder = listMissingReports.get(p);

                row = sheet.createRow((short) p + 7);

                // Create a cell and put a value in it.

                cell = row.createCell((short) 0);
                cell.setCellValue(objMissOrder.getStoreNbr());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 1);
                cell.setCellValue(objMissOrder.getStoreNam());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 2);
                cell.setCellValue(objMissOrder.getLocOrgDsc());
                cell.setCellStyle(cellStyle);
            }
            wb.write(out);
        } catch (IOException e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                wb.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }
    
    @Override
    public ByteArrayInputStream downLoadStorePresellDraftReport(Integer psellIdNbr, String fileName) {
        log.info("downLoadStorePresellDraftReport:{}{}", psellIdNbr, fileName);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HSSFWorkbook wb = new HSSFWorkbook();
        try {
            List<MissingOrderProjection> listMissingReports;
            listMissingReports = storItemsRepository.getListMissingOrder(psellIdNbr, PresellConstants.SAVED_AS_DRAFT);

            PresellReportDTO presellReport;
            presellReport = presellRepository.getPresellReportDetails(psellIdNbr);


            HSSFSheet sheet = wb.createSheet(fileName);

            /*
             * Styles and Formatting informatiion added here
             */
            HSSFPrintSetup ps = sheet.getPrintSetup();
            sheet.setAutobreaks(true);

            ps.setFitHeight((short) 1);
            ps.setFitWidth((short) 1);

            HSSFFont styleBold = wb.createFont();
            styleBold.setBold(true);

            HSSFCellStyle styleCaption = wb.createCellStyle();
            styleCaption.setWrapText(false);
            styleCaption.setBorderBottom(BorderStyle.THIN);
            styleCaption.setBorderLeft(BorderStyle.THIN);
            styleCaption.setBorderRight(BorderStyle.THIN);
            styleCaption.setBorderTop(BorderStyle.THIN);
            styleCaption.setAlignment(HorizontalAlignment.CENTER);
            styleCaption.setFont(styleBold);

            HSSFCellStyle cellStyle = wb.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setBorderRight(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);

            HSSFCellStyle cellBoldStyle = wb.createCellStyle();
            cellBoldStyle.setWrapText(true);
            cellBoldStyle.setFont(styleBold);

            /*
             * END OF Styles and Formatting informatiion added here
             */

            // Create a cell and put a value in it.
            HSSFRow row = sheet.createRow((short) 0);
            // Create a cell and put a value in it.
            HSSFCell cell = row.createCell((short) 1);
            cell.setCellValue("Presell Missing Order Report");
            cell.setCellStyle(styleCaption);

            row = sheet.createRow((short) 1);
            row.createCell((short) 0);

            // Presell Header Details

            row = sheet.createRow((short) 2);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.PRESELL_TITLE);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPsellDsc());

            cell = row.createCell((short) 2);
            cell.setCellValue(PresellConstants.BUSINESS_UNIT);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 3).setCellValue(presellReport.getBusUnitId());

            row = sheet.createRow((short) 3);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.AUTHOR);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 1).setCellValue(presellReport.getPresellAuthor());

            cell = row.createCell((short) 2);
            cell.setCellValue(PresellConstants.PRESELL_LEVEL);
            cell.setCellStyle(cellBoldStyle);
            row.createCell((short) 3).setCellValue(presellReport.getPsellLvlDsc());

            row = sheet.createRow((short) 4);

            cell = row.createCell((short) 0);
            cell.setCellValue(PresellConstants.DUE_DATE);
            cell.setCellStyle(cellBoldStyle);
            SimpleDateFormat dateFormat = new SimpleDateFormat(PresellConstants.MM_DD_YYYY);
            row.createCell((short) 1).setCellValue(dateFormat.format(presellReport.getPsellDueDt()));

            cell = row.createCell((short) 2);
            cell.setCellValue(PresellConstants.STATUS);
            cell.setCellStyle(cellBoldStyle);

            if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.SEND_TO_STORES)) {
                row.createCell((short) 3).setCellValue(Status.SEND_TO_STORES.getStatusDsc());
            } else if (presellReport.getPsellStatCd().equalsIgnoreCase(PresellConstants.REC_FROM_STORES)) {
                row.createCell((short) 3).setCellValue(Status.REC_FROM_STORES.getStatusDsc());
            } else {
                row.createCell((short) 3).setCellValue(Status.CLOSED.getStatusDsc());
            }
            /* End of Header Details */

            row = sheet.createRow((short) 5);
            row.createCell((short) 0);

            row = sheet.createRow((short) 6);
            cell = row.createCell((short) 0);

            cell.setCellValue(PresellConstants.STORENO);
            cell.setCellStyle(styleCaption);

            row.createCell((short) 1).setCellValue("Store Name");
            row.createCell((short) 2).setCellValue(PresellConstants.DISTRICT);

            row.getCell((short) 1).setCellStyle(styleCaption);
            row.getCell((short) 2).setCellStyle(styleCaption);

            sheet.setColumnWidth((short) 0, (short) 3000);
            sheet.setColumnWidth((short) 1, (short) 7000);
            sheet.setColumnWidth((short) 2, (short) 6000);

            for (int p = 0; p < listMissingReports.size(); p++) {
                MissingOrderProjection objMissOrder = listMissingReports.get(p);

                row = sheet.createRow((short) p + 7);

                // Create a cell and put a value in it.

                cell = row.createCell((short) 0);
                cell.setCellValue(objMissOrder.getStoreNbr());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 1);
                cell.setCellValue(objMissOrder.getStoreNam());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 2);
                cell.setCellValue(objMissOrder.getLocOrgDsc());
                cell.setCellStyle(cellStyle);
            }
            wb.write(out);
        } catch (IOException e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                wb.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    @Override
    public PresellReportDTO getPresellReportDetails(Integer psellIdNbr) {
        log.info("getPresellReportDetails");
        PresellReportDTO presellReport = new PresellReportDTO();
        presellReport = presellRepository.getPresellReportDetails(psellIdNbr);
        if (presellReport.getPsellStatCd() != null) {
            String status = presellReport.getPsellStatCd();
            if (status.equalsIgnoreCase(PresellConstants.SEND_TO_STORES)) {
                presellReport.setPsellStatCd(Status.SEND_TO_STORES.getStatusDsc());
            } else if (status.equalsIgnoreCase(PresellConstants.REC_FROM_STORES)) {
                presellReport.setPsellStatCd(Status.REC_FROM_STORES.getStatusDsc());
            } else {
                presellReport.setPsellStatCd(Status.CLOSED.getStatusDsc());
            }
        }
        return presellReport;
    }

    @Override
    public Page<PresellReportDTO> searchPresellReport(PresellReportSearchCriteria criteria,
                                                      PaginationAndSortDTO paginationAndSortDTO) {
        log.info("searchPresellReport");
        Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
                paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
                        : Sort.by(paginationAndSortDTO.getSortBy()).descending());
        return presellReportDAO.searchPresellReport(criteria, pageable);
    }
}
