package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.PresellAuthorDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.service.ItemService;
import com.delhaize.presell.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@Log4j2
@RestController
@RequestMapping("/api/v1/user")
@Tag(name = "user", description = "the user API")
public class UserController {
    private final UserService userService;

    @Autowired
public UserController(UserService userService) {
    this.userService = userService;
}

    @Operation(summary = "Get Presell Author list", tags = {"User Details"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = ItemProjection.class))),
            @ApiResponse(responseCode = "404", description = "Item not found", content = @Content)
    })
    @Secured
    @GetMapping(value = "/getPresellAuthorList", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<PresellAuthorDTO>> getPresellAuthors() {
        log.info("getPresellAuthors :{}");
        var rs = userService.getPresellAuthorsList();
        return ResponseEntity.ok(rs);
    }

}
