package com.delhaize.presell.util.timefuncs;

import java.util.GregorianCalendar;

public class Day implements TimeFunctions {
	/**
	 * method implemented from TimeFunctions to add Time Units, in this case to add
	 * days, to a given GregorianCalendar object
	 */
	public GregorianCalendar addTimeUnits(GregorianCalendar objCal, int intNumberUnits) {
		objCal.add(GregorianCalendar.DAY_OF_YEAR, intNumberUnits);
		return objCal;
	}

	/********************************************************************
	 * method implemented from TimeFunctions such that given a number of
	 * milliseconds, this method returns the number of time units, in this case
	 * days.
	 */
	public double getNumberOfTimeUnits(long millisecs) {
		double noTimeUnits = millisecs / (24 * 60 * 60 * 1000.0);
		return noTimeUnits;
	}

}
