package com.delhaize.presell.service.impl;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.PresellItem;
import com.delhaize.presell.dto.projection.PresellLogProjection;
import com.delhaize.presell.dto.projection.StoreResultsPresellprojection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;
import com.delhaize.presell.entity.*;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.repository.*;
import com.delhaize.presell.repository.dao.StoreOrderDAO;
import com.delhaize.presell.service.StoreOrderService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.delhaize.presell.constant.PresellConstants.MM_DD_YYYY;

@Log4j2
@Service
public class StoreOrderServiceImpl implements StoreOrderService {

    private final StoreOrderDAO storeOrderDAO;
    private final PresellRepository presellRepository;
    private final PresellStoreRepository presellStoreRepository;
    private final ItemServiceImpl itemServiceImpl;
    private final LvlClassRepository lvlClassRepository;
    private final StorItemsRepository storItemsRepository;
    private final PreselLogRepository preselLogRepository;
    private final BuMstrRepository buMstrRepository;
    private final ItemsRepository itemsRepository;
    private SimpleDateFormat MM_DD_YYYY_DATE_FORMAT = new SimpleDateFormat(MM_DD_YYYY);

    @Autowired
    public StoreOrderServiceImpl(StoreOrderDAO storeOrderDAO, PresellRepository presellRepository,
                                 PresellStoreRepository presellStoreRepository, ItemServiceImpl itemServiceImpl,
                                 LvlClassRepository lvlClassRepository, StorItemsRepository storItemsRepository,
                                 PreselLogRepository preselLogRepository, BuMstrRepository buMstrRepository, ItemsRepository itemsRepository) {
        this.storeOrderDAO = storeOrderDAO;
        this.presellRepository = presellRepository;
        this.presellStoreRepository = presellStoreRepository;
        this.itemServiceImpl = itemServiceImpl;
        this.lvlClassRepository = lvlClassRepository;
        this.storItemsRepository = storItemsRepository;
        this.preselLogRepository = preselLogRepository;
        this.buMstrRepository = buMstrRepository;
        this.itemsRepository = itemsRepository;
    }

    @Override
    public Page<StoreOrderDTO> searchStoreOrder(StoreOrderCriteria criteria,
                                                PaginationAndSortDTO paginationAndSortDTO) {
        Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(), paginationAndSortDTO.getSize(),
                paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending()
                        : Sort.by(paginationAndSortDTO.getSortBy()).descending());
        log.info("-----Search store order-----");
        // log.info("----------" + criteria.getUserRole());
        if (criteria.getUserRole().equals(PresellConstants.USER_GROUP_RETL_ROLE)) {
            return storeOrderDAO.searchStoreOrderWithRoleRT(criteria, pageable);
        } else {
            return storeOrderDAO.searchStoreOrder(criteria, pageable);
        }
    }

    @Override
    public PresellStoreDetailDTO getStoreOrderDetails(Integer presellID, Secured.UserRole role, Integer store) {
        log.info("getStoreOrderDetails:{}", presellID);
        PresellStoreDetailDTO presellDetails = new PresellStoreDetailDTO();
        try {
            // Get store order details using presellid first preselldetails
            PresellItem presellData = presellRepository.getPresell(presellID);
            log.info(presellData.getPsellStatCd());
            ModelMapper modelMapper = new ModelMapper();
            presellDetails = modelMapper.map(presellData, PresellStoreDetailDTO.class);
            presellDetails.setBusUnitDsc(buMstrRepository.getbusUnitDsc(presellDetails.getBusUnitId()));
            if (role.equals(Secured.UserRole.RETAIL)) {
                List<StoreResultsPresellDTO> storeDetailsList = new ArrayList<>();
                List<StoreResultsPresellprojection> storeData = presellStoreRepository.getStoreRetailData(presellID, store);
                StoreResultsPresellDTO storeDetails = new StoreResultsPresellDTO();
                storeDetails = modelMapper.map(storeData.get(0), StoreResultsPresellDTO.class);
                if (storeDetails.getStoreStatCd().equalsIgnoreCase(PresellConstants.SEND_TO_STORES)) {
                    storeDetails.setStoreStatCd("Pending");
                } else if (storeDetails.getStoreStatCd().equalsIgnoreCase(PresellConstants.STORE_STATUS_ADS)) {
                    storeDetails.setStoreStatCd("");
                } else {
                    storeDetails.setStoreStatCd((Status.findStatusDsc(storeData.get(0).getStoreStatCd())));
                }
                presellDetails.setStoreNo(storeDetails.getStoreNbr());
                presellDetails.setStoreStatus(storeDetails.getStoreStatCd());
                storeDetailsList.add(storeDetails);
                presellDetails.setHmStoresForAdd(storeDetailsList);
            } else {
                // fetching store name,district and status if user is not Retail user
                List<StoreResultsPresellprojection> storeData = presellStoreRepository.getStoreData(presellID);
//            ModelMapper modelMap = new ModelMapper();
				List<StoreResultsPresellDTO> storelist = new ArrayList<>();
				for (int i = 0; i < storeData.size(); i++) {
					StoreResultsPresellDTO storeResults = new StoreResultsPresellDTO();
					storeResults = modelMapper.map(storeData.get(i), StoreResultsPresellDTO.class);
					if (storeData.get(i).getStoreStatCd().equalsIgnoreCase("STS")) {
						storeResults.setStoreStatCd("Pending");
					} else {
						storeResults.setStoreStatCd((Status.findStatusDsc(storeData.get(i).getStoreStatCd())));
					}
					storelist.add(storeResults);
				}
				presellDetails.setHmStoresForAdd(storelist);
			}
			// store classification for presell
			long currentDBDate = presellRepository.getCurrentDate().getTime();

			// Calculating days remaining for submitting the store order
			int iRemainingDays = DatetimeUtils.dayBetween(new java.util.Date(currentDBDate),
					presellDetails.getPsellDueDt());
			log.info("iRemainingDays: " + iRemainingDays);
			if (iRemainingDays >= 0) {
				presellDetails.setRemainingDays(iRemainingDays);
			} else {
				presellDetails.setRemainingDays(PresellConstants.NULL_INTEGER);
			}
		} catch (Exception e) {
			log.error("Error at get presell details: {}", e.getMessage());
			throw e;
		}
		return presellDetails;
	}

	@Override
	public ByteArrayInputStream downloadStoreItemDetails(Integer psellIdNbr, Integer storeNbr, String fileName) {
		log.info("downloadStoreItemDetails:{}{}", psellIdNbr, storeNbr);
		PresellItem presellData = presellRepository.getPresell(psellIdNbr);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		HSSFWorkbook workbook = new HSSFWorkbook();
		try {
			// log.info(presellData.getPsellStatCd());
			ModelMapper modelMapper = new ModelMapper();
			PresellStoreDetailDTO presell = modelMapper.map(presellData, PresellStoreDetailDTO.class);
			StoreOrderItemDTO list = itemServiceImpl.getItemOrderDetails(psellIdNbr, storeNbr);
			List<ClassificationDTO> classification = lvlClassRepository.getClassifications();
			presell.setClassification(classification);
			presell.setStoreNo(storeNbr);
			presell.setItemList(list.getItemList());
			HSSFSheet sheet = workbook.createSheet(fileName);

			// Set header style
			HSSFCellStyle headerStyle = workbook.createCellStyle();
			HSSFFont headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerStyle.setFont(headerFont);
			headerStyle.setAlignment(HorizontalAlignment.CENTER);
			headerStyle.setWrapText(true);
			headerStyle.setBorderTop(BorderStyle.THIN);
			headerStyle.setBorderBottom(BorderStyle.THIN);
			headerStyle.setBorderLeft(BorderStyle.THIN);
			headerStyle.setBorderRight(BorderStyle.THIN);

			// Set cell style
			HSSFCellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setWrapText(true);
			cellStyle.setBorderTop(BorderStyle.THIN);
			cellStyle.setBorderBottom(BorderStyle.THIN);
			cellStyle.setBorderLeft(BorderStyle.THIN);
			cellStyle.setBorderRight(BorderStyle.THIN);

			HSSFRow row = sheet.createRow((short) 0);
			HSSFCell cell = row.createCell((short) 2);
			cell.setCellValue("Presell Item Details");
			cell.setCellStyle(headerStyle);

			row = sheet.createRow((short) 1);
			row.createCell((short) 0);

			row = sheet.createRow((short) 2);

			cell = row.createCell((short) 1);
			cell.setCellValue("Presell Title");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 2).setCellValue(presell.getPsellDsc());

			cell = row.createCell((short) 4);
			cell.setCellValue("Business Unit");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 5).setCellValue(presell.getBusUnitId());

			row = sheet.createRow((short) 3);

			cell = row.createCell((short) 1);
			cell.setCellValue("Presell Level");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 2).setCellValue(presell.getPsellLvlDsc());

			cell = row.createCell((short) 4);
			cell.setCellValue("Presell Author");
			cell.setCellStyle(headerStyle);

			row = sheet.createRow((short) 4);
			cell = row.createCell((short) 1);
			cell.setCellValue("Due Date");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 2).setCellValue(MM_DD_YYYY_DATE_FORMAT.format(presell.getPsellDueDt()));

			cell = row.createCell((short) 4);
			cell.setCellValue("Reminder Email Date");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 5).setCellValue(MM_DD_YYYY_DATE_FORMAT.format(presell.getRmndrEmailDt()));

			row = sheet.createRow((short) 5);
			cell = row.createCell((short) 1);
			cell.setCellValue("Planned Distribution");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 2).setCellValue(presell.getPlnDistFlg().equals("YES") ? "No" : "Yes");

			cell = row.createCell((short) 4);
			cell.setCellValue("Status");
			cell.setCellStyle(headerStyle);
			if (presell.getPsellStatCd().equalsIgnoreCase(PresellConstants.SEND_TO_STORES)
					|| presell.getPsellStatCd().equalsIgnoreCase(PresellConstants.SAVED_AS_DRAFT)) {
				row.createCell((short) 5).setCellValue(PresellConstants.PENDING);
			} else if (presell.getPsellStatCd().equalsIgnoreCase(PresellConstants.REC_FROM_STORES)
					|| presell.getPsellStatCd().equalsIgnoreCase(PresellConstants.SUBMITTED)) {
				row.createCell((short) 5).setCellValue(Status.SUBMITTED.getStatusDsc());
			} else if (presell.getPsellStatCd().equalsIgnoreCase(PresellConstants.CLOSED_STATUS)) {
				row.createCell((short) 5).setCellValue(Status.CLOSED.getStatusDsc());
			}
			// row.createCell((short) 5).setCellValue(presell.getPsellStatCd());

			row = sheet.createRow((short) 6);
			cell = row.createCell((short) 1);
			cell.setCellValue("Store#");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 2).setCellValue(presell.getStoreNo());

			cell = row.createCell((short) 4);
			cell.setCellValue("Presell Level Classification");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 5).setCellValue(list.getPreselLvlClasification());

			row = sheet.createRow((short) 7);
			cell = row.createCell((short) 1);
			cell.setCellValue("Comments");
			cell.setCellStyle(headerStyle);
			row.createCell((short) 2).setCellValue(presell.getPsellCmtTxt());

			sheet.createRow((short) 8);
			row = sheet.createRow((short) 9);
			row.createCell((short) 0).setCellValue("Item Nbr.");
			row.createCell((short) 1).setCellValue("Shipping Date");
			row.createCell((short) 2).setCellValue("Pack/Size(z)");
			row.createCell((short) 3).setCellValue("Cost");
			row.createCell((short) 4).setCellValue("SRP");
			row.createCell((short) 5).setCellValue("GM(%)");
			row.createCell((short) 6).setCellValue("Quantity");

			HSSFCell cellSOQ = row.createCell((short) 7);
			StringBuilder strSOQ = new StringBuilder("SOQ ");
			for (ClassificationDTO objPresellLevelClassificationBean : classification) {
				strSOQ.append(objPresellLevelClassificationBean.getClassificationDsc()).append("/");
			}
			cellSOQ.setCellValue(strSOQ.toString());
			row.createCell((short) (8)).setCellValue("Description");
			row.createCell((short) (9)).setCellValue("Comment");
			row.createCell((short) (10)).setCellValue("URL");

			int iCnt1 = 10;

			for (ItemsDTO objAdditemsBean : list.getItemList()) {
				row = sheet.createRow((short) iCnt1);
				if (objAdditemsBean.getItemNbr().trim().equals("DSD")
						|| Integer.parseInt(objAdditemsBean.getItemNbr()) < 0) {
					cell = row.createCell((short) 0);
					cell.setCellValue("DSD");
					cell.setCellStyle(cellStyle);

				} else {
					cell = row.createCell((short) 0);
					cell.setCellValue(objAdditemsBean.getItemNbr());
					cell.setCellStyle(cellStyle);
				}

				cell = row.createCell((short) 1);
				cell.setCellValue(MM_DD_YYYY_DATE_FORMAT.format(objAdditemsBean.getShipDt()));
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) 2);
				cell.setCellValue(objAdditemsBean.getItemPkQty() + "/" + objAdditemsBean.getItemSzCnt() + "("
						+ objAdditemsBean.getItemSzCd().trim() + ")");
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) 3);
				cell.setCellValue(objAdditemsBean.getItemCst());
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) 4);
				//
				cell.setCellValue(objAdditemsBean.getRtlPrc());
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) 5);
				cell.setCellValue(objAdditemsBean.getPsellGrmrgAmt());
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) 6);
				cell.setCellValue(objAdditemsBean.getItemOrderQty());
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) (7));
				List<SuggOrderQtyDTO> hmItemSOQ = objAdditemsBean.getSuggOrderQtyList();
				log.info("******" + hmItemSOQ.size());

				strSOQ = buildSOQ(classification, hmItemSOQ);

				cell.setCellValue(strSOQ.toString());
				cell.setCellStyle(cellStyle);
				cell = row.createCell((short) (8));
				cell.setCellValue(objAdditemsBean.getItemDsc());
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) (9));
				cell.setCellValue(objAdditemsBean.getPsellItemCmtTxt());
				cell.setCellStyle(cellStyle);

				cell = row.createCell((short) (10));
				cell.setCellValue(objAdditemsBean.getItemImgUrl());
				cell.setCellStyle(cellStyle);
				iCnt1++;
			}

			workbook.write(out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.error(e);
			throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
		} finally {
			try {
				workbook.close();
			} catch (IOException e) {
				log.error(e);
			}
		}

		return new ByteArrayInputStream(out.toByteArray());
	}

	private StringBuilder buildSOQ(List<ClassificationDTO> classification, List<SuggOrderQtyDTO> hmItemSOQ) {
		log.info("buildSOQ");
		StringBuilder strSOQ = new StringBuilder("");
		for (ClassificationDTO objPresellLevelClassificationBean : classification) {
			for (SuggOrderQtyDTO suggOrderQtyDTO : hmItemSOQ) {
				if (suggOrderQtyDTO.getPresellLevelCode().trim()
						.equals(objPresellLevelClassificationBean.getClassificationDsc().trim())) {
					strSOQ.append(suggOrderQtyDTO.getSuggOrderQty().split("\\.")[0]).append("/");

				}
			}
		}
		return strSOQ;
	}

    @Override
    public int saveEditStoreQuantity(SaveEditStoreQtyDTO criteria) {
        // Calling the Process method update item quantity
        log.info("-----Save edit store quantity-----");
        var items = criteria.getPresellDetail().getItemList();
        items.forEach(item -> {
            // log.info("Update Item Quantity");
            var storItemPk = new StorItemsPK();
            storItemPk.setPsellIdNbr(criteria.getPresellDetail().getPsellIdNbr());
            storItemPk.setStoreNbr(Integer.valueOf(criteria.getPresellDetail().getStoreNo()));
            storItemPk.setItemNbr(new BigDecimal(item.getItemNbr()));
            storItemPk.setShipDt(convertUtilToSql(item.getShipDt()));

            log.info("storItem: " + storItemPk.getStoreNbr());

            var storItemEntity = storItemsRepository.findById(storItemPk).orElse(null);
            if (storItemEntity == null) {
                storItemEntity = new StorItems();
                storItemEntity.setAddUserId(criteria.getUserId());
            }
            storItemEntity.setStorItemsPk(storItemPk);
            storItemEntity.setItemOrderQty(new BigDecimal(item.getItemOrderQty()));
            storItemEntity.setModUserId(criteria.getUserId());
            log.info("storItemEntity: " + storItemEntity.getModUserId());
            storItemsRepository.saveAndFlush(storItemEntity);

        });

        String strMapping = null;
        // Checking for Store Status
        if (criteria.getUserRole().equals(PresellConstants.USER_GROUP_ADMIN_USER)) {
            if (criteria.getPresellDetail().getStoreStatus().trim().equals(PresellConstants.SUBMITTED)) {
                strMapping = PresellConstants.STORE_SUBMIT;
            } else if (criteria.getPresellDetail().getStoreStatus().trim().equals(PresellConstants.SEND_TO_STORES)) {
                strMapping = PresellConstants.STORE_STS;
            }
        }

        String strStatus = null;
        String strLogComment = null;
        log.info("Mappingggggggggggggg " + criteria.getAction());
        switch (Objects.requireNonNull(criteria.getAction())) {
            // TODO why checking redundant value (PresellConstants.SAVE,
            // PresellConstants.SUBMITTED)
            // TODO assignee Cuong
            case PresellConstants.SAVE:
                strStatus = PresellConstants.SAVED_AS_DRAFT;
                strLogComment = PresellConstants.LOG_DRAFT;
                break;
            case PresellConstants.SUBMIT:
                strStatus = PresellConstants.SUBMITTED;
                strLogComment = PresellConstants.LOG_SUBMITTED;
                break;
//            case PresellConstants.SAVE:
//                strStatus = PresellConstants.SAVED_AS_DRAFT;
//                strLogComment = PresellConstants.LOG_DRAFT;
//                break;
//            case PresellConstants.SUBMITTED:
//                strStatus = PresellConstants.SUBMITTED;
//                strLogComment = PresellConstants.SUBMITTED;
//                break;
            case PresellConstants.STORE_SUBMIT:
                strStatus = PresellConstants.SUBMITTED;
                strLogComment = PresellConstants.LOG_DRAFT;
                break;
            case PresellConstants.STORE_STS:
                strStatus = PresellConstants.SEND_TO_STORES;
                strLogComment = PresellConstants.LOG_DRAFT;
                break;
            default:
                break;
        }

        // Update Store
        try {
            var presellStorePk = new PresellStorePK();
            presellStorePk.setStoreNbr(Integer.valueOf(criteria.getPresellDetail().getStoreNo()));
            presellStorePk.setPsellIdNbr(criteria.getPresellDetail().getPsellIdNbr());
            var presellStore = presellStoreRepository.findById(presellStorePk)
                    .orElseThrow(() -> new EntityNotFoundException(PresellStore.class));

            presellStore.setStorePk(presellStorePk);
            presellStore.setStoreStatCd(strStatus);
            presellStore.setAddUserId(criteria.getUserId());
            presellStore.setModUserId(criteria.getUserId());
            presellStore.setModTs(DatetimeUtils.getUTCTimestamp());
            presellStoreRepository.save(presellStore);
        } catch (Exception e) {
            log.error("Update Store Error!{}", e);
        }
        // Insert to Log
        recordActionToLog(criteria, strStatus, strLogComment);
        return 1;
    }

    private void recordActionToLog(SaveEditStoreQtyDTO request, String status, String logComment) {
        try {
            log.info("Insert Action Log.");
            var logEntity = new PreselLog();
            var logPk = new PreselLogPK();
            logPk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
            logPk.setStoreNbr(Integer.valueOf(request.getPresellDetail().getStoreNo()));
            logPk.setAudLogTs(DatetimeUtils.getUTCTimestamp());
            logPk.setAddUserId(request.getUserId());
            logEntity.setPreselLogPk(logPk);
            logEntity.setLogStatCd(status);
            logEntity.setLogCmtTxt(logComment);
            log.info("Status. " + status);
            log.info("Comment. " + logComment);
            preselLogRepository.save(logEntity);
        } catch (Exception e) {
            log.error("Insert Log Error!{}", e);
        }
    }

    private java.sql.Date convertUtilToSql(java.util.Date uDate) {
        log.info("-----Convert util date tp sql date-----");
        return new java.sql.Date(uDate.getTime());
    }
}
