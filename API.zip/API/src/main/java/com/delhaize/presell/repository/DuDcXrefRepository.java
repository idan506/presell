package com.delhaize.presell.repository;

import com.delhaize.presell.entity.DuDcXref;
import com.delhaize.presell.entity.DuDcXrefPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DuDcXrefRepository extends JpaRepository<DuDcXref, DuDcXrefPK> {
}
