package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPRD704_ITEM_CLS")
public class ItemCls {

  @EmbeddedId
  private ItemClsPK itemClsPk;

  @Column(name="MDSE_DEPT_NBR")
  private Integer mdseDeptNbr;

  @Column(name="MDSE_SUB_DEPT_NBR")
  private Integer mdseSubDeptNbr;

  @Column(name="MJR_CATG_ID")
  private String mjrCatgId;

  @Column(name="INTMD_CATG_ID")
  private String intmdCatgId;

  @Column(name="MNR_CATG_ID")
  private String mnrCatgId;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    ItemCls itemCls = (ItemCls) o;
    return itemClsPk != null && Objects.equals(itemClsPk, itemCls.itemClsPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(itemClsPk);
  }
}
