package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TCST002_BRACKET")
public class Bracket {


  @Id
  @Column(name="BRKT_SID_NBR")
  private Integer brktSidNbr;

  @Column(name="VEND_SET_NBR")
  private Integer vendSetNbr;

  @Column(name="VEND_ID")
  private String vendId;

  @Column(name="VEND_SHPNT_SEQ_NBR")
  private Integer vendShpntSeqNbr;

  @Column(name="LOC_SID_NBR")
  private Integer locSidNbr;

  @Column(name="BRKT_EFF_DT")
  private java.sql.Date brktEffDt;

  @Column(name="BRKT_RATE_TYP_CD")
  private String brktRateTypCd;

  @Column(name="VEND_BRKT_ID")
  private String vendBrktId;

  @Column(name="BRKT_MIN_ORDER_QTY")
  private Integer brktMinOrderQty;

  @Column(name="BRKT_MAX_ORDER_QTY")
  private Integer brktMaxOrderQty;

  @Column(name="FULL_TRK_FLG")
  private String fullTrkFlg;

  @Column(name="EST_PERF_LVL_FLG")
  private String estPerfLvlFlg;

  @Column(name="FOB_CD")
  private String fobCd;

  @Column(name="BRKT_NBR")
  private Integer brktNbr;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    Bracket bracket = (Bracket) o;
    return brktSidNbr != null && Objects.equals(brktSidNbr, bracket.brktSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
