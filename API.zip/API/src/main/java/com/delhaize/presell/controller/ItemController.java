package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.PresellDetailDTO;
import com.delhaize.presell.dto.StoreOrderItemDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.request.AddItemCommentForm;
import com.delhaize.presell.dto.request.ItemSearchCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.ItemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@Log4j2
@RestController
@RequestMapping("/api/v1/item")
@Tag(name = "item", description = "the item API")
public class ItemController {

    private final ItemService itemService;

    @Autowired
    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @Operation(summary = "Get List Item Report", tags = {"itemReport"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = ItemProjection.class))),
            @ApiResponse(responseCode = "404", description = "Item not found", content = @Content)
    })
    @Secured
    @GetMapping(value = "/{psellIdNbr}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<ItemProjection>> getListItemReport(@PathVariable Integer psellIdNbr) {
        log.info("getListItemReport :{}",psellIdNbr);
        var rs = itemService.getListItemReport(psellIdNbr);
        return ResponseEntity.ok(rs);
    }


    @Operation(summary = "Add Warhouse item")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = PresellDetailDTO.class))),

    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/addWarhouseItem", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<PresellDetailDTO> addWarhouseItem(ItemSearchCriteria criteria, PresellDetailDTO presellDetailDTO) {
        log.info("addWarhouseItem");
        var rs = itemService.getItemDetails(criteria, presellDetailDTO);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Add DSD item")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = PresellDetailDTO.class))),

    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/addDSDItem", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<PresellDetailDTO> addDSDItem(PresellDetailDTO presellDetailDTO) {
        log.info("addDSDItem");
        var rs = itemService.addDSDItem(presellDetailDTO);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Add Item Comment")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = PresellDetailDTO.class))),

    })
    @Secured
    @GetMapping(value = "/addItemComment", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<PresellDetailDTO> addItemComment(AddItemCommentForm form, PresellDetailDTO presellDetailDTO) {
        log.info("addItemComment");
        var rs = itemService.addItemComment(form, presellDetailDTO);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get Order details", tags = {"itemReport"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = ItemProjection.class))),
            @ApiResponse(responseCode = "404", description = "Item not found", content = @Content)
    })
    @Secured
    @GetMapping(value = "/{psellIdNbr}/{storeNbr}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<StoreOrderItemDTO> getItemOrderDetails(@PathVariable Integer psellIdNbr, @PathVariable Integer storeNbr) {
        log.info("getItemOrderDetails :{}",psellIdNbr);
        try {
            var rs = itemService.getItemOrderDetails(psellIdNbr, storeNbr);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.ITEM_ORDER_ERROR, e);
        }
    }

}
