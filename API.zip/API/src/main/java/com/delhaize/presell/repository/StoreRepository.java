package com.delhaize.presell.repository;

import com.delhaize.presell.dto.StorePresellLevelMappingDTO;
import com.delhaize.presell.dto.projection.StoreProjection;
import com.delhaize.presell.entity.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StoreRepository extends JpaRepository<Store, Integer> {
    @Query(value = "SELECT DISTINCT TLOC100.storeNam as storeNam, "
            + "TLOC001.busUnitId as busUnitId, "
            + "TGEO700.busUnitDsc as busUnitDsc, "
            + "TLOC101.storeFlg as storeFlg, "
            + "TLOC001.geoRegnCd as geoRegnCd, "
            + "COALESCE(TLOC708A.locOrgDsc, ' ') as locOrgDsc "
            + "FROM Store TLOC100 "
            + "LEFT OUTER JOIN StrFlags TLOC101 "
            + "ON (TLOC100.storeSidNbr = TLOC101.strFlagsPk.storeSidNbr "
            + "AND TLOC101.strFlagsPk.flgNam = 'INDEPENDENT-FLAG'), "
            + "Location TLOC001 "
            + "LEFT JOIN LocOrg TLOC708A "
            + "ON (TLOC001.locOrgSidNbr = TLOC708A.locOrgSidNbr), "
            + "BuMstr TGEO700 "
            + "WHERE TLOC100.storeSidNbr = TLOC001.locSidNbr "
            + "AND TLOC001.busUnitId = TGEO700.busUnitId "
            + "AND TLOC001.locTypId   ='ST' "
            + "AND TLOC100.storeNbr = :storeNo")
    StorePresellLevelMappingDTO getStoreDetails(@Param("storeNo") Integer storeNo);

    @Query(value = "SELECT DISTINCT TLOC100.storeNbr as storeNbr, "
            + "TLOC100.storeNam as storeNam, "
            + "TLOC001.geoRegnCd as geoRegnCd, "
            + "COALESCE(TLOC708A.locOrgDsc, ' ') AS locOrgDsc "
            + "FROM Store TLOC100, "
            + "Location TLOC001 "
            + "LEFT JOIN LocOrg TLOC708A "
            + "ON (TLOC001.locOrgSidNbr = TLOC708A.locOrgSidNbr) "
            + "LEFT JOIN LocOrg TLOC708B "
            + "ON (TLOC708B.locOrgSidNbr = TLOC708A.parntHierSidNbr) "
            + "WHERE TLOC001.locSidNbr = TLOC100.storeSidNbr "
            + "AND TLOC001.locTypId = 'ST' ")
    List<StoreProjection> getListStore();

    @Query(value = "SELECT DISTINCT TLOC100.storeNbr as storeNbr, "
//            + "TLOC100.storeNam as storeNam, "
//            + "TLOC001.geoRegnCd as geoRegnCd, "
//            + "COALESCE(TLOC708A.locOrgDsc, ' ') AS locOrgDsc, "
            + "TPSL006.psellLvlIdNbr as psellLvlIdNbr, "
            + "TPSL005.psellLvlClsCd as psellLvlClsCd "
            + "FROM LvlClass TPSL005, "
            + "LvlMaint TPSL006, "
            + "LvlMapng TPSL007, "
            + "Store TLOC100, "
            + "Location TLOC001 "
            + "LEFT JOIN LocOrg TLOC708A "
            + "ON (TLOC001.locOrgSidNbr = TLOC708A.locOrgSidNbr) "
            + "WHERE TPSL007.lvlMapngPk.psellLvlIdNbr = TPSL006.psellLvlIdNbr "
            + "AND TPSL007.psellClsIdNbr  = TPSL005.psellClsIdNbr "
            + "AND TPSL007.lvlMapngPk.storeNbr = TLOC100.storeNbr "
            + "AND TLOC001.locSidNbr = TLOC100.storeSidNbr "
            + "AND TLOC001.locTypId = 'ST' "
            + "ORDER BY TLOC100.storeNbr ")
    List<StoreProjection> getListStoreDownloadDetail();

}
