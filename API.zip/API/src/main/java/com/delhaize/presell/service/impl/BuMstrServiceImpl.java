package com.delhaize.presell.service.impl;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.repository.BuMstrRepository;
import com.delhaize.presell.service.BuMstrService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Log4j2
@Service
public class BuMstrServiceImpl implements BuMstrService {

    private final BuMstrRepository buMstrRepository;

    @Autowired
    public BuMstrServiceImpl(BuMstrRepository buMstrRepository) {
        this.buMstrRepository = buMstrRepository;
    }

    @Override
    @Cacheable(value = "busUnit")
    public List<BusUnitDTO> getBusUnit() {
        log.info("getBusUnit");
        return buMstrRepository.getBusUnits();
    }
}
