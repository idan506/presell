package com.delhaize.presell.repository.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.delhaize.presell.dto.StoresDTO;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.SliceImpl;
import org.springframework.stereotype.Repository;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import com.delhaize.presell.util.CommonFunctions;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Repository
public class StoreDAOImpl implements StoreDAO {

    @PersistenceContext
    EntityManager entityManager;

    //@Override
	/*public Slice<StoresDTO> searchStore(StoreSearchCriteria criteria, Pageable pageable) {

		StringBuilder queryString = new StringBuilder(SearchStoreConstants.SELECT_BU_STORE);
		Map<String, Object> parameters = new HashedMap<>();

		// search store
		if (criteria.getStrBusinessUnit() != null
				&& !criteria.getStrBusinessUnit().equalsIgnoreCase(PresellConstants.BLANK)) {

			queryString.append(" AND TGEO700.parntBusUnitId = :strBusinessUnit ");
			parameters.put("strBusinessUnit", criteria.getStrBusinessUnit());
			
			//search by list district
			if (CommonFunctions.arrayNotEmpty(criteria.getStrDistrict())) {

				queryString.append(" AND TLOC708A.locOrgSidNbr IN (");
				CommonFunctions.appendParamsStringValue(criteria.getStrDistrict(), queryString);
				queryString.append(") ");

			} 
			//search by list division
			else if (CommonFunctions.arrayNotEmpty(criteria.getStrDivision())) {

				queryString.append(" AND TLOC708B.locOrgSidNbr IN(");
				CommonFunctions.appendParamsStringValue(criteria.getStrDivision(), queryString);
				queryString.append(") ");
				
			} 
			//search by list location
			else if (CommonFunctions.arrayNotEmpty(criteria.getStrStoreLoc())) {

				queryString.append(" AND TLOC001.geoRegnCd IN(");
				CommonFunctions.appendParamsStringValue(criteria.getStrStoreLoc(), queryString);
				queryString.append(") ");
				
			} 
			//search by store number
			else if (criteria.getStrStoreNo() != null
					&& !criteria.getStrStoreNo().equalsIgnoreCase(PresellConstants.BLANK)) {

				queryString.append(" AND TLOC100.storeNbr = '" + criteria.getStrStoreNo() + "'");
				log.info("====Query: " + queryString);
			}
			
			//check if store already add to presell
			if (criteria.getStrStoreNosAlreadyAdded() != null
					&& !criteria.getStrStoreNosAlreadyAdded().equalsIgnoreCase(PresellConstants.BLANK)) {

				queryString.append(" AND TLOC100.storeNbr NOT IN (");
				CommonFunctions.appendParamsStringValue(
						criteria.getStrStoreNosAlreadyAdded().split(PresellConstants.COMMA), queryString);
				queryString.append(") ");
			}
		}
		
		//group by
		queryString.append("GROUP BY TORD013.schdDlvPk.storeNbr, TLOC100.storeNam, TLOC001.geoRegnCd,"
				+ " TLOC001.locSidNbr, TLOC708B.locOrgDsc, TLOC708A.locOrgDsc");

		// sorting
		queryString.append(" ORDER BY TORD013.schdDlvPk.storeNbr ASC ");
		
		TypedQuery<StoresDTO> query = entityManager.createQuery(queryString.toString(), StoresDTO.class);
		
		// set parameters
		parameters.forEach(query::setParameter);

		return readSlice(query, pageable);
	}*/

/*	private Slice<StoresDTO> readSlice(final TypedQuery<StoresDTO> query, final Pageable pageable) {
		if (pageable != null) {
			query.setFirstResult((int) pageable.getOffset());
			query.setMaxResults(pageable.getPageSize() + 1);
			List<StoresDTO> content = new ArrayList<>();
			try {
				content = query.getResultList();
			} catch (Exception e) {
				e.printStackTrace();
			}

			boolean hasNext = pageable.isPaged() && content.size() == (pageable.getPageSize() + 1);

			if (hasNext) {
				content.remove(content.size() - 1);
			}

			return new SliceImpl<>(content, pageable, hasNext);
		} else {
			return new SliceImpl<>(query.getResultList());
		}
	}*/

    private static class SearchStoreConstants {
        private static final String SELECT_BU_STORE = "SELECT NEW com.delhaize.presell.dto.StoresDTO("
                + "TORD013.schdDlvPk.storeNbr AS storeNbr, "
                + "TLOC100.storeNam AS storeNam, "
                + "TLOC001.geoRegnCd AS geoRegnCd, "
                + "TLOC001.locSidNbr AS locSidNbr, "
                + "COALESCE(TLOC708B.locOrgDsc, ' ') AS divDsc, "
                + "COALESCE(TLOC708A.locOrgDsc, ' ') AS dstrcDsc, "
                + "MAX(TORD013.schdArrvDt) AS schdArrvDt) "
                + "FROM Store TLOC100, "
                + "SchdDlv TORD013, "
                + "Location TLOC001 "
                + "LEFT JOIN "
                + "LocOrg TLOC708A "
                + "ON (TLOC001.locOrgSidNbr = TLOC708A.locOrgSidNbr) "
                + "LEFT JOIN LocOrg TLOC708B "
                + "ON (TLOC708B.locOrgSidNbr = TLOC708A.parntHierSidNbr), "
                + "BuMstr TGEO700 "
                + "WHERE TLOC100.storeSidNbr = TLOC001.locSidNbr "
                + "AND TLOC001.locTypId ='ST' "
                + "AND TLOC100.storeNbr = TORD013.schdDlvPk.storeNbr "
                + "AND TLOC001.busUnitId = TGEO700.busUnitId "
                + "AND TLOC001.busUnitId = TORD013.schdDlvPk.busUnitId ";
    }

    @Override
    public List<StoresDTO> searchStore(StoreSearchCriteria criteria) {

        StringBuilder queryString = new StringBuilder(SearchStoreConstants.SELECT_BU_STORE);
        Map<String, Object> parameters = new HashedMap<>();

        // search store
        if (criteria.getStrBusinessUnit() != null
                && !criteria.getStrBusinessUnit().equalsIgnoreCase(PresellConstants.BLANK)) {

            queryString.append(" AND TGEO700.parntBusUnitId = :strBusinessUnit ");
            parameters.put("strBusinessUnit", criteria.getStrBusinessUnit());

            //search by list district
            if (CommonFunctions.arrayNotEmpty(criteria.getStrDistrict())) {

                queryString.append(" AND TLOC708A.locOrgSidNbr IN (");
                CommonFunctions.appendParamsStringValue(criteria.getStrDistrict(), queryString);
                queryString.append(") ");

            }
            //search by list division
            else if (CommonFunctions.arrayNotEmpty(criteria.getStrDivision())) {

                queryString.append(" AND TLOC708B.locOrgSidNbr IN(");
                CommonFunctions.appendParamsStringValue(criteria.getStrDivision(), queryString);
                queryString.append(") ");

            }
            //search by list location
            else if (CommonFunctions.arrayNotEmpty(criteria.getStrStoreLoc())) {

                queryString.append(" AND TLOC001.geoRegnCd IN(");
                CommonFunctions.appendParamsStringValue(criteria.getStrStoreLoc(), queryString);
                queryString.append(") ");

            }
            //search by store number
            else if (criteria.getStrStoreNo() != null
                    && !criteria.getStrStoreNo().equalsIgnoreCase(PresellConstants.BLANK)) {

                queryString.append(" AND TLOC100.storeNbr = '" + criteria.getStrStoreNo() + "'");
                log.info("====Query: " + queryString);
            }

            //check if store already add to presell
            if (criteria.getStrStoreNosAlreadyAdded() != null
                    && !criteria.getStrStoreNosAlreadyAdded().equalsIgnoreCase(PresellConstants.BLANK)) {

                queryString.append(" AND TLOC100.storeNbr NOT IN (");
                CommonFunctions.appendParamsStringValue(
                        criteria.getStrStoreNosAlreadyAdded().split(PresellConstants.COMMA), queryString);
                queryString.append(") ");
            }
        }

        //group by
        queryString.append("GROUP BY TORD013.schdDlvPk.storeNbr, TLOC100.storeNam, TLOC001.geoRegnCd,"
                + " TLOC001.locSidNbr, TLOC708B.locOrgDsc, TLOC708A.locOrgDsc");

        // sorting
        queryString.append(" ORDER BY TORD013.schdDlvPk.storeNbr ASC ");

        TypedQuery<StoresDTO> query = entityManager.createQuery(queryString.toString(), StoresDTO.class);

        // set parameters
        parameters.forEach(query::setParameter);
        List<StoresDTO> data = query.getResultList();
        return data;
    }

}
