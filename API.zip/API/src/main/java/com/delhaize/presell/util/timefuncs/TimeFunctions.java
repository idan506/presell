package com.delhaize.presell.util.timefuncs;

import java.util.GregorianCalendar;

public interface TimeFunctions {
	/**
	 * method allows addition of various time units
	 * @param objCal - GregorianCalendar object
	 * @param intNumberUnits - 
	 * @return GregorianCalendar
	 */
	GregorianCalendar addTimeUnits(GregorianCalendar objCal, int intNumberUnits);
	
	/**
	 * method determines the number of time units based on the number of 
	 * milliseconds
	 * @param millisecs
	 * @return double
	 */
	double getNumberOfTimeUnits(long millisecs);
}
