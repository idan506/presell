package com.delhaize.presell.repository.template;

import com.delhaize.presell.entity.Itmsoqmap;
import com.delhaize.presell.util.DatetimeUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Log4j2
@Service
public class SOQBatchJDBCTemplate {

    private final JdbcTemplate jdbcTemplate;

    @Value("${spring.jpa.properties.hibernate.default_schema}")
    private String schemaName;

    @Autowired
    public SOQBatchJDBCTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public void insertSOQ(List<Itmsoqmap> itmsoqmaps) {
        if (itmsoqmaps.isEmpty()) return;
        log.info("Batch insert SOQ {}" , schemaName);
        String query=
                "INSERT INTO " + schemaName + ".TPSL008_ITMSOQMAP "
                        + " ( PSELL_ID_NBR, "
                        + " ITEM_NBR, "
                        + " SHIP_DT, "
                        + " PSELL_CLS_ID_NBR, "
                        + " SUGG_ORDER_QTY, "
                        + " ADD_USER_ID, "
                        + " ADD_TS, "
                        + " MOD_USER_ID, "
                        + " MOD_TS )"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ? )";
        jdbcTemplate.batchUpdate(query, new SOQBatchInsertPreparedStatementSetter(itmsoqmaps));
    }

    @Transactional
    public void updateSOQ(List<Itmsoqmap> itmsoqmaps) {
        if (itmsoqmaps.isEmpty()) return;
        log.info("Batch update SOQ");
        String query=
                "UPDATE " + schemaName + ".TPSL008_ITMSOQMAP "
                        + " SET "
                        + " SUGG_ORDER_QTY = ?, "
                        + " MOD_USER_ID = ?, "
                        + " MOD_TS = ? "
                        + " WHERE PSELL_ID_NBR = ? "
                        + " AND ITEM_NBR = ? "
                        + " AND SHIP_DT = ? "
                        + " AND PSELL_CLS_ID_NBR = ? ";
        jdbcTemplate.batchUpdate(query, new SOQBatchUpdatePreparedStatementSetter(itmsoqmaps));
    }

    public static class SOQBatchInsertPreparedStatementSetter implements BatchPreparedStatementSetter {

        private final List<Itmsoqmap> itmsoqmaps;

        public SOQBatchInsertPreparedStatementSetter(List<Itmsoqmap> itmsoqmaps) {
            super();
            this.itmsoqmaps = itmsoqmaps;
        }

        @Override
        public void setValues(PreparedStatement ps, int i) throws SQLException {
            Itmsoqmap entity = itmsoqmaps.get(i);
            ps.setInt(1, entity.getItmsoqmapPk().getPsellIdNbr());
            ps.setBigDecimal(2, entity.getItmsoqmapPk().getItemNbr());
            ps.setDate(3, entity.getItmsoqmapPk().getShipDt());
            ps.setInt(4, entity.getItmsoqmapPk().getPsellClsIdNbr());
            ps.setBigDecimal(5, entity.getSuggOrderQty());
            ps.setString(6, entity.getAddUserId());
            ps.setTimestamp(7, DatetimeUtils.getUTCTimestamp());
            ps.setString(8, entity.getModUserId());
            ps.setTimestamp(9, DatetimeUtils.getUTCTimestamp());
        }

        @Override
        public int getBatchSize() {
            return itmsoqmaps.size();
        }
    }

    public static class SOQBatchUpdatePreparedStatementSetter implements BatchPreparedStatementSetter {

        private final List<Itmsoqmap> itmsoqmaps;

        public SOQBatchUpdatePreparedStatementSetter(List<Itmsoqmap> itmsoqmaps) {
            super();
            this.itmsoqmaps = itmsoqmaps;
        }

        @Override
        public void setValues(PreparedStatement ps, int i) throws SQLException {
            Itmsoqmap entity = itmsoqmaps.get(i);
            ps.setBigDecimal(1, entity.getSuggOrderQty());
            ps.setString(2, entity.getModUserId());
            ps.setTimestamp(3, DatetimeUtils.getUTCTimestamp());
            ps.setInt(4, entity.getItmsoqmapPk().getPsellIdNbr());
            ps.setBigDecimal(5, entity.getItmsoqmapPk().getItemNbr());
            ps.setDate(6, entity.getItmsoqmapPk().getShipDt());
            ps.setInt(7, entity.getItmsoqmapPk().getPsellClsIdNbr());
        }

        @Override
        public int getBatchSize() {
            return itmsoqmaps.size();
        }
    }

}
