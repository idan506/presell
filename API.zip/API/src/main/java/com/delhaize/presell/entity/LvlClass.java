package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPSL005_LVL_CLASS")
public class LvlClass {


  @Id
  @Column(name="PSELL_CLS_ID_NBR")
  private Integer psellClsIdNbr;

  @Column(name="PSELL_LVL_CLS_CD")
  private String psellLvlClsCd;

  @Column(name="LGCL_DEL_FLG")
  private String lgclDelFlg;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @Column(name="ADD_TS")
  @CreationTimestamp
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  @UpdateTimestamp
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    LvlClass lvlClass = (LvlClass) o;
    return psellClsIdNbr != null && Objects.equals(psellClsIdNbr, lvlClass.psellClsIdNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
