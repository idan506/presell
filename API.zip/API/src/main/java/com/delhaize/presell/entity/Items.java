package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPSL002_ITEMS")
public class Items {

  @EmbeddedId
  private ItemsPK itemsPk;

  @Column(name="ITEM_CST")
  private java.math.BigDecimal itemCst;

  @Column(name="ITEM_SZ_CNT")
  private java.math.BigDecimal itemSzCnt;

  @Column(name="ITEM_SZ_CD")
  private String itemSzCd;

  @Column(name="ITEM_PK_QTY")
  private Integer itemPkQty;

  @Column(name="ITEM_CAP_CST")
  private java.math.BigDecimal itemCapCst;

  @Column(name="RTL_PRC")
  private java.math.BigDecimal rtlPrc;

  @Column(name="PSELL_GRMRG_AMT")
  private java.math.BigDecimal psellGrmrgAmt;

  @Column(name="ITEM_DSC")
  private String itemDsc;

  @Column(name="PSELL_ITEM_CMT_TXT")
  private String psellItemCmtTxt;

  @Column(name="ITEM_IMG_URL")
  private String itemImgUrl;

  @Column(name="ITEM_CNTRB_PCT")
  private java.math.BigDecimal itemCntrbPct;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @CreationTimestamp
  @Column(name="ADD_TS")
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @UpdateTimestamp
  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    Items items = (Items) o;
    return itemsPk != null && Objects.equals(itemsPk, items.itemsPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(itemsPk);
  }
}
