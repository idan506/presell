package com.delhaize.presell.authorization;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class UserSSOInfo {
    Secured.UserRole role;
    String userId;
    Integer storeNbr = 8156;
    Long tokenExpiryTime;
}
