package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.PresellStoreDetailDTO;
import com.delhaize.presell.dto.SaveEditStoreQtyDTO;
import com.delhaize.presell.dto.StoreOrderDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.StoreOrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin
@Log4j2
@RestController
@RequestMapping("/api/v1/store-order")
@Tag(name = "store-order", description = "the store order API")
public class StoreOrderController {

	private StoreOrderService storeOrderService;

	@Autowired
	public StoreOrderController(StoreOrderService storeOrderService) {
		this.storeOrderService = storeOrderService;
	}

	@Operation(summary = "Search Store Order")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = StoreOrderDTO.class))),
			@ApiResponse(responseCode = "404", description = "Store Order not found", content = @Content) })
	@Secured
	@GetMapping(value = "/search", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Page<StoreOrderDTO>> searchStoreOrder(@Valid StoreOrderCriteria criteria,
			PaginationAndSortDTO paginationAndSortDTO, @RequestAttribute("user") UserSSOInfo user) {
		criteria.setUserRole(user.getRole().toString());
		if (criteria.getUserRole().equals(PresellConstants.USER_GROUP_RETL_ROLE)) {
			criteria.setStoreNo(user.getStoreNbr().toString());
		}
		var rs = storeOrderService.searchStoreOrder(criteria, paginationAndSortDTO);
		return ResponseEntity.ok(rs);
	}

	@Operation(summary = "Get Store Order Details")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = StoreOrderController.class))),
			@ApiResponse(responseCode = "404", description = "Store Order not found", content = @Content) })
	@Secured
	@GetMapping(value = "/{psellIdNbr}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<PresellStoreDetailDTO> getStoreOrderDetails(@PathVariable Integer psellIdNbr,@RequestAttribute("user") UserSSOInfo user) {
		try {
			Secured.UserRole role=user.getRole();
			Integer storeNo=0;
			if(role.equals(Secured.UserRole.RETAIL)) {
				storeNo=user.getStoreNbr();
			}
			log.info("psellIdNbr" + psellIdNbr);
			var rs = storeOrderService.getStoreOrderDetails(psellIdNbr,role,storeNo);
			return ResponseEntity.ok(rs);
		} catch (Exception e) {
			log.error(e);
			throw ExceptionHandlingHelper.newGenericException(ResponseError.STORE_ORDER_ERROR, e);
		}
	}

	@Operation(summary = "Download To XLS Item Details ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = ItemProjection.class))),
			@ApiResponse(responseCode = "404", description = "Item not found", content = @Content) })
	@Secured
	@GetMapping(value = "/{psellIdNbr}/{storeNbr}/download", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Resource> downloadStoreItemDetails(@PathVariable Integer psellIdNbr,
			@PathVariable Integer storeNbr) {
		log.info("downloadStoreItemDetails :psellIdNbr:storeNbr{}{}", psellIdNbr, storeNbr);
		try {
			String fileName = String.format("Presell_Item_%o.xls", System.currentTimeMillis());
			InputStreamResource file = new InputStreamResource(
					storeOrderService.downloadStoreItemDetails(psellIdNbr, storeNbr, fileName));

			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
		} catch (Exception e) {

			throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
		}
	}

	@Operation(summary = "Save Edit Store Quantity ")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = PresellStoreDetailDTO.class))) })
	@Secured
	@PostMapping
	public ResponseEntity<Integer> saveEditStoreQuantity(@RequestBody @Valid SaveEditStoreQtyDTO request,
			@RequestAttribute("user") UserSSOInfo user) {
		log.info("saveEditStoreQuantity");
		log.info("request by {}", user.getUserId());
		int result = 0;
		if (request.getAction() != null && (request.getAction().equals(PresellConstants.SAVE)
				|| request.getAction().equals(PresellConstants.SUBMIT))) {

			String strStatus = null;
			// Checking for Store Status
			if (request.getUserRole().equals(PresellConstants.USER_GROUP_ADMIN_USER)) {
				if (request.getPresellDetail().getStoreStatus().trim().equals(PresellConstants.SUBMITTED)) {
					request.setAction(PresellConstants.STORE_SUBMIT);
				} else if (request.getPresellDetail().getStoreStatus().trim().equals(PresellConstants.SEND_TO_STORES)) {
					request.setAction(PresellConstants.STORE_STS);
				}
			}

			if (strStatus == null) {
				strStatus = request.getAction();
			}

			try {
				request.setUserId(user.getUserId());
				var rs = storeOrderService.saveEditStoreQuantity(request);
				return ResponseEntity.ok(rs);
			} catch (Exception e) {
				log.error(e);
				throw ExceptionHandlingHelper.newGenericException(ResponseError.SAVE_EDIT_STORE_QUANTITY, e);
			}
		}
		return ResponseEntity.ok(result);
	}
}
