package com.delhaize.presell.dto.projection;

public interface StoreClassificationProjection {
    Integer getStoreNbr();
    Integer getClassificationIdNbr();
}
