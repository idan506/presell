package com.delhaize.presell.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BusUnitDTO {
    private String busUnitId;
    private String busUnitDsc;
}
