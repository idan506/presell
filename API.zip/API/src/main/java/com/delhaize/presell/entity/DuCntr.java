package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TITM201_DU_CNTR")
public class DuCntr {

  @EmbeddedId
  private DuCntrPK duCntrPk;

  @Column(name="UPC_NBR")
  private java.math.BigDecimal upcNbr;

  @Column(name="GTIN_NBR")
  private java.math.BigDecimal gtinNbr;

  @Column(name="CNTR_WTH")
  private java.math.BigDecimal cntrWth;

  @Column(name="WTH_UOM_CD")
  private String wthUomCd;

  @Column(name="CNTR_LEN")
  private java.math.BigDecimal cntrLen;

  @Column(name="LEN_UOM_CD")
  private String lenUomCd;

  @Column(name="CNTR_DPTH")
  private java.math.BigDecimal cntrDpth;

  @Column(name="DPTH_UOM_CD")
  private String dpthUomCd;

  @Column(name="CNTR_WGT")
  private java.math.BigDecimal cntrWgt;

  @Column(name="WGT_UOM_CD")
  private String wgtUomCd;

  @Column(name="CNTR_VOL")
  private java.math.BigDecimal cntrVol;

  @Column(name="VOL_UOM_CD")
  private String volUomCd;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    DuCntr duCntr = (DuCntr) o;
    return duCntrPk != null && Objects.equals(duCntrPk, duCntr.duCntrPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(duCntrPk);
  }
}
