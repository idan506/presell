package com.delhaize.presell.dto.request;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.delhaize.presell.constant.Status;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreOrderCriteria {

	private String presellTitle;

    private Integer presellLevelId;

    private Status status;

    private String presellAuthor;

    private String storeNo;

    @Schema(example = "01/20/2015")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date fromDueDate;

    @Schema(example = "01/20/2021")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date toDueDate;

    private String plannedDis;
    
    @NotNull
    private String userRole;
}
