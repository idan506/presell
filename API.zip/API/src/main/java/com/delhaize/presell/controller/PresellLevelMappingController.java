package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.dto.StorePresellLevelDTO;
import com.delhaize.presell.dto.StorePresellLevelMappingDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.PresellLevelMappingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@CrossOrigin
@Log4j2
@RestController
@RequestMapping("/api/v1/level-mapping")
@Tag(name = "level-mapping", description = "the presell level mapping API")
public class PresellLevelMappingController {

	private PresellLevelMappingService presellLevelMappingService;

	@Autowired
	public PresellLevelMappingController(PresellLevelMappingService presellLevelMappingService) {
		this.presellLevelMappingService = presellLevelMappingService;
	}

	@Operation(summary = "Search Store Presell Level Mapping")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = StorePresellLevelMappingDTO.class))),
			@ApiResponse(responseCode = "404", description = "Store Presell Level Mapping not found", content = @Content) })
	@Secured(permitRoles = {Secured.UserRole.ADMIN})
	@GetMapping(value = "/search", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<List<StorePresellLevelMappingDTO>> searchStorePresellLevelMapping(
			StorePresellLevelMappingCriteria criteria) {
		log.info("searchStoreOrder");
		var rs = presellLevelMappingService.searchStorePresellLevelMapping(criteria);
		return ResponseEntity.ok(rs);
	}

    @Operation(summary = "Save Store Presell Level Mapping ")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = StorePresellLevelMappingDTO.class))),
            @ApiResponse(responseCode = "404", description = "Store Presell Level Mapping not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @PostMapping
    public ResponseEntity<Integer> saveStorePresellLevelMaping(@RequestBody @Valid StorePresellLevelDTO request,
                                                               @RequestAttribute("user") UserSSOInfo user) {
        log.info("saveStorePresellLevelMaping");
        log.info("request by {}", user.getUserId());
        try {
            request.setUserId(user.getUserId());
            var rs = presellLevelMappingService.saveStorePresellLevelMaping(request);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.SAVE_STORE_PRESELL_LEVELMAPPING_ERROR, e);
        }
    }

	@Operation(summary = "Download To XLS Store Presell Level Mapping (All store)")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class))) })
	@Secured(permitRoles = {Secured.UserRole.ADMIN})
	@GetMapping(value = "/download", produces = { MediaType.APPLICATION_OCTET_STREAM_VALUE })
	public ResponseEntity<Resource> downloadStorePresellLevelMapping() {
		log.info("downloadStorePresellLevelMapping");
		Date dtCurrentDate = new Date();
		String fileName = "Presell_MAP_" + dtCurrentDate.getTime() + ".xls";
		InputStreamResource file = new InputStreamResource(
				presellLevelMappingService.downloadStorePresellLevelMapping(fileName));
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
	}
}
