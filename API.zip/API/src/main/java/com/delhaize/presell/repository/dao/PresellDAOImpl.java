package com.delhaize.presell.repository.dao;

import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.PresellDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import com.delhaize.presell.util.DatetimeUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.delhaize.presell.constant.Status;

@Log4j2
@Repository
public class PresellDAOImpl implements PresellDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public Page<PresellDTO> searchPresell(PresellSearchCriteria criteria, Pageable pageable) {
        log.info("searchPresell");

        StringBuilder queryString = new StringBuilder(SearchPresellConstants.SELECT_PRESELL_LISTING);
        StringBuilder queryCountString = new StringBuilder(SearchPresellConstants.COUNT_PRESELL_LISTING);
        StringBuilder whereClause = new StringBuilder();
        Map<String, Object> parameters = new HashedMap<>();

        buildWhereClause(whereClause, parameters, criteria);

        queryString.append(whereClause);
        queryCountString.append(whereClause);
        if (pageable != null) {
            queryString.append(" ORDER BY ");
            pageable.getSort().forEach(order ->
                    queryString
                            .append(SearchPresellConstants.sortKeys.get(order.getProperty()))
                            .append(" ")
                            .append(order.getDirection())
                            .append(", ")
            );
            // remove redundant comma
            queryString.append(" TPSL001.psellIdNbr ")
                    .append(pageable.getSort().toList().get(0).getDirection());
        } else {
            queryString.append(" ORDER BY TPSL001.psellIdNbr ASC ");
        }

        // prepare the search presell query
        TypedQuery<PresellDTO> query = entityManager.createQuery(queryString.toString(), PresellDTO.class);
        parameters.forEach(query::setParameter);

        // prepare the count all elements query
        TypedQuery<Long> countQuery = entityManager.createQuery(queryCountString.toString(), Long.class);
        parameters.forEach(countQuery::setParameter);

        return readPage(query, countQuery, pageable);
    }

    private void buildWhereClause(StringBuilder whereClause, Map<String, Object> parameters, PresellSearchCriteria criteria) {
        log.info("buildWhereClause");
        if (criteria.getPresellTitle() != null) {
            whereClause.append(" AND UPPER(TPSL001.psellDsc) LIKE CONCAT('%',:psellDsc,'%') ");
            parameters.put("psellDsc", criteria.getPresellTitle().toUpperCase());
        }

        if (criteria.getBusinessUnit() != null
                && !criteria.getBusinessUnit().equalsIgnoreCase(PresellConstants.ALL)) {
            whereClause.append(" AND TPSL001.busUnitId = :busUnitId ");
            parameters.put("busUnitId", criteria.getBusinessUnit());
        }

        buildQueryBasedOnStatus(whereClause, parameters, criteria);

        if (criteria.getPresellAuthor() != null) {
            whereClause.append(" AND TPSL001.addUserId = :addUserId ");
            parameters.put("addUserId", criteria.getPresellAuthor());
        }

        if (criteria.getPresellLevelId() != null) {
            whereClause.append(" AND TPSL001.psellLvlIdNbr = :psellLvlIdNbr ");
            parameters.put("psellLvlIdNbr", criteria.getPresellLevelId());
        }

        if (criteria.getFromDueDate() != null) {
            whereClause.append(" AND TPSL001.psellDueDt >= :fpsellDueDt ");
            parameters.put("fpsellDueDt", criteria.getFromDueDate());
        }

        if (criteria.getToDueDate() != null) {
            whereClause.append(" AND TPSL001.psellDueDt <= :tpsellDueDt ");
            parameters.put("tpsellDueDt", criteria.getToDueDate());
        }

        if (criteria.getPlannedDis() != null) {
            whereClause.append(" AND TPSL001.plnDistFlg = :plnDistFlg ");
            parameters.put("plnDistFlg", criteria.getPlannedDis());
        }

    }

    private void buildQueryBasedOnStatus(StringBuilder whereClause, Map<String, Object> parameters, PresellSearchCriteria criteria) {
        log.info("buildQueryBasedOnStatus");
        if (criteria.getStatus() != null && !Status.SUBMITTED.equals(criteria.getStatus())) {
            var parameter = "psellStatCd";
            if (Status.ALL_EXCLUDING_CLOSED.equals(criteria.getStatus())
                    || Status.ALL_INCLUDING_CLOSED.equals(criteria.getStatus())) {
                if (Status.ALL_EXCLUDING_CLOSED.equals(criteria.getStatus())) {
                    whereClause.append(" AND TPSL001.psellStatCd != :psellStatCd");
                    parameters.put(parameter, Status.CLOSED.getKey());
                }
            } else {
                whereClause.append(" AND TPSL001.psellStatCd = :psellStatCd");
                switch (criteria.getStatus()) {
                    case SAVED_AS_DRAFT:
                        parameters.put(parameter, Status.SAVED_AS_DRAFT.getKey());
                        break;
                    case SEND_TO_STORES:
                        parameters.put(parameter, Status.SEND_TO_STORES.getKey());
                        break;
                    case REC_FROM_STORES:
                        parameters.put(parameter, Status.REC_FROM_STORES.getKey());
                        break;
                    case CLOSED:
                        parameters.put(parameter, Status.CLOSED.getKey());
                        break;
                    default:
                        throw new IllegalArgumentException("Invalid Status");
                }
            }
        }

    }

    private Page<PresellDTO> readPage(final TypedQuery<PresellDTO> query, TypedQuery<Long> countQuery, final Pageable pageable) {
        log.info("readPage");
        try {
            if (pageable != null) {
                query.setFirstResult((int) pageable.getOffset());
                query.setMaxResults(pageable.getPageSize());

                final List<PresellDTO> content = query.getResultList();

                normalizeResults(content);

                Long total = countQuery.getSingleResult();

                return new PageImpl<>(content, pageable, total);
            } else {
                var content = query.getResultList();
                normalizeResults(content);
                return new PageImpl<>(content);
            }
        } catch (Exception e) {
            log.error(e);
            throw e;
        }
    }

    private void normalizeResults(List<PresellDTO> result) {
        log.info("normalizeResults");
        result.forEach(e -> {
            e.setPresellStatCd(Objects.requireNonNull(Status.findByKey(e.getPresellStatCd())).getStatusDsc());
            e.setPlnDistFlg("Y".equalsIgnoreCase(e.getPlnDistFlg()) ? "Yes" : "No");
            e.setAbleToDelete(Objects.equals(Status.findByKey(e.getPresellStatCd()), Status.SEND_TO_STORES));
            e.setPresellDueDt(DatetimeUtils.isInvalidDate(e.getPresellDueDt()) ? null : e.getPresellDueDt());
        });
    }

    private static class SearchPresellConstants {
        private static final String SELECT_PRESELL_LISTING =
                "SELECT NEW com.delhaize.presell.dto.PresellDTO("
                        + "TPSL001.psellIdNbr, "
                        + "TPSL001.psellDsc, "
                        + "TPSL001.busUnitId, "
                        + "TPSL006.psellLvlDsc, "
                        + "TPSL001.psellStatCd, "
                        + "TPSL001.psellDueDt, "
                        + "TPSL001.addUserId, "
                        + "TPSL001.plnDistFlg, false) "
                        + "FROM Presell  TPSL001 "
                        + "INNER JOIN LvlMaint TPSL006 "
                        + "ON (TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr) "
                        + "WHERE 1 = 1 ";

        private static final String COUNT_PRESELL_LISTING =
                "SELECT COUNT(*) "
                        + "FROM Presell  TPSL001 "
                        + "INNER JOIN LvlMaint TPSL006 "
                        + "ON (TPSL001.psellLvlIdNbr = TPSL006.psellLvlIdNbr) "
                        + "WHERE 1 = 1 ";

        private static final Map<String, String> sortKeys = new HashedMap<>();

        static {
            sortKeys.put("presellDsc", "TPSL001.psellDsc");
            sortKeys.put("busUnitId", "TPSL001.busUnitId");
            sortKeys.put("presellLvlDsc", "TPSL006.psellLvlDsc");
            sortKeys.put("presellStatCd", "TPSL001.psellStatCd");
            sortKeys.put("presellDueDt", "TPSL001.psellDueDt");
            sortKeys.put("plnDistFlg", "TPSL001.plnDistFlg");
        }
    }
    
}
