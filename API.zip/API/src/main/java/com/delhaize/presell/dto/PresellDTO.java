package com.delhaize.presell.dto;

import com.delhaize.presell.dto.serialization.JsonDateSerializer;
import com.delhaize.presell.dto.serialization.WhiteSpaceRemovalSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PresellDTO {

    private Integer id;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String presellDsc;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String busUnitId;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String presellLvlDsc;

    private String presellStatCd;

    @JsonSerialize(using = JsonDateSerializer.class)
    private Date presellDueDt;

    @JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
    private String addUserId;

    private String plnDistFlg;

    private boolean ableToDelete = false;
}
