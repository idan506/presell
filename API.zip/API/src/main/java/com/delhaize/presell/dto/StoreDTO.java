package com.delhaize.presell.dto;

import java.util.Date;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.DBStatus;
import com.delhaize.presell.dto.serialization.WhiteSpaceRemovalSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StoreDTO {
	
	private Integer storeNbr;

	@Schema(hidden = true)
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String storeNam;

	@Schema(hidden = true)
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String geoRegnCd;

	@Schema(hidden = true)
	private Integer locSidNbr;

	@Schema(hidden = true)
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String divDsc;

	@Schema(hidden = true)
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String dstrcDsc;

	@Schema(hidden = true)
	private Date schdArrvDt;

	private DBAction action = DBAction.UPDATE;

	private DBStatus status = DBStatus.OLD;

	public void setAction(DBAction action) {
		this.action = action == null ? DBAction.INACTION : action;
	}
}
