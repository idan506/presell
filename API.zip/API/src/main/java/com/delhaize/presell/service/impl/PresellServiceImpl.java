package com.delhaize.presell.service.impl;

import com.delhaize.presell.constant.DBAction;
import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.*;
import com.delhaize.presell.dto.projection.*;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import com.delhaize.presell.entity.*;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.repository.*;
import com.delhaize.presell.repository.dao.PresellDAO;
import com.delhaize.presell.repository.template.ItemBatchJDBCTemplate;
import com.delhaize.presell.repository.template.StoreBatchJDBCTemplate;
import com.delhaize.presell.service.ItemService;
import com.delhaize.presell.service.PresellService;
import com.delhaize.presell.service.StoreService;
import com.delhaize.presell.util.DatetimeUtils;
import com.delhaize.web.exception.EntityNotFoundException;
import lombok.extern.log4j.Log4j2;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.delhaize.presell.constant.PresellConstants.MM_DD_YYYY;
import static com.delhaize.presell.constant.Status.SEND_TO_STORES;

@Log4j2
@Service
public class PresellServiceImpl implements PresellService {

    static String[] HEADERS = {"Presell Title", "Presell Author", "Business Unit", "Status", "Presell Level", "Due Date", "Planned Distribution"};
    static int[] COLUMN_WIDTH = {5000, 4000, 4000, 2000, 4000, 3000, 5000};
    private final PresellDAO presellDAO;
    private final ItmsoqmapRepository itmsoqmapRepository;
    private final StorItemsRepository storItemsRepository;
    private final ItemsRepository itemsRepository;
    private final PresellStoreRepository presellStoreRepository;
    private final PreselLogRepository preselLogRepository;
    private final PresellRepository presellRepository;
    private final LvlMapngRepository lvlMapngRepository;
    private final LvlMaintRepository lvlMaintRepository;
    private final StoreService storeService;
    private final ItemService itemService;
    private final LvlClassRepository lvlClassRepository;
    private final BuMstrRepository buMstrRepository;
    private final StoreBatchJDBCTemplate storeBatchJDBCTemplate;
    private final ItemBatchJDBCTemplate itemBatchJDBCTemplate;
    private final SimpleDateFormat MM_DD_YYYY_DATE_FORMAT = new SimpleDateFormat(MM_DD_YYYY);


    @Autowired
    public PresellServiceImpl(PresellDAO presellDAO, ItmsoqmapRepository itmsoqmapRepository,
                              StorItemsRepository storItemsRepository, ItemsRepository itemsRepository,
                              PresellStoreRepository presellStoreRepository, PreselLogRepository preselLogRepository,
                              PresellRepository presellRepository, LvlMapngRepository lvlMapngRepository,
                              StoreService storeService, ItemService itemService, LvlClassRepository lvlClassRepository,
                              LvlMaintRepository lvlMaintRepository, BuMstrRepository buMstrRepository,
                              StoreBatchJDBCTemplate storeBatchJDBCTemplate, ItemBatchJDBCTemplate itemBatchJDBCTemplate) {
        this.presellDAO = presellDAO;
        this.itmsoqmapRepository = itmsoqmapRepository;
        this.storItemsRepository = storItemsRepository;
        this.itemsRepository = itemsRepository;
        this.presellStoreRepository = presellStoreRepository;
        this.preselLogRepository = preselLogRepository;
        this.presellRepository = presellRepository;
        this.lvlMapngRepository = lvlMapngRepository;
        this.lvlMaintRepository = lvlMaintRepository;
        this.storeService = storeService;
        this.itemService = itemService;
        this.lvlClassRepository = lvlClassRepository;
        this.buMstrRepository = buMstrRepository;
        this.storeBatchJDBCTemplate = storeBatchJDBCTemplate;
        this.itemBatchJDBCTemplate = itemBatchJDBCTemplate;
    }

    @Override
    public Page<PresellDTO> searchPresell(PresellSearchCriteria criteria, PaginationAndSortDTO paginationAndSortDTO) {
        log.info("-----Search presell-----");
        Pageable pageable = PageRequest.of(paginationAndSortDTO.getPage(),
                paginationAndSortDTO.getSize(),
                paginationAndSortDTO.getOrder().isAscending() ? Sort.by(paginationAndSortDTO.getSortBy()).ascending() : Sort.by(paginationAndSortDTO.getSortBy()).descending());
        return presellDAO.searchPresell(criteria,
                pageable);
    }

    @Override
    public ByteArrayInputStream downloadPresellToXLS(PresellSearchCriteria criteria, String filename) {
        log.info("-----Download presell to excel file-----");
        var rs = presellDAO.searchPresell(criteria, null).getContent();
        HSSFWorkbook workbook = new HSSFWorkbook();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            HSSFSheet sheet = workbook.createSheet(filename);

            // Set header style
            HSSFCellStyle headerStyle = workbook.createCellStyle();
            HSSFFont headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setWrapText(true);
            headerStyle.setBorderTop(BorderStyle.THIN);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);

            // Set cell style
            HSSFCellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setBorderTop(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);
            cellStyle.setBorderLeft(BorderStyle.THIN);
            cellStyle.setBorderRight(BorderStyle.THIN);

            HSSFRow row0 = sheet.createRow((short) 0);
            HSSFCell cell00 = row0.createCell((short) 1);
            cell00.setCellValue("Presell Listing");
            cell00.setCellStyle(headerStyle);

            // Header
            HSSFRow headerRow = sheet.createRow(2);
            for (short i = 0; i < HEADERS.length; i++) {
                sheet.setColumnWidth(i, COLUMN_WIDTH[i]);
                HSSFCell cell = headerRow.createCell(i);
                cell.setCellValue(HEADERS[i]);
                cell.setCellStyle(headerStyle);
            }

            short rowIdx = 3;
            for (var presell : rs) {
                HSSFRow row = sheet.createRow(rowIdx++);

                var cell1 = row.createCell((short) 0);
                cell1.setCellStyle(cellStyle);
                cell1.setCellValue(presell.getPresellDsc());
                var cell2 = row.createCell((short) 1);
                cell2.setCellStyle(cellStyle);
                cell2.setCellValue(presell.getAddUserId());
                var cell3 = row.createCell((short) 2);
                cell3.setCellStyle(cellStyle);
                cell3.setCellValue(presell.getBusUnitId());
                var cell4 = row.createCell((short) 3);
                cell4.setCellStyle(cellStyle);
                cell4.setCellValue(presell.getPresellStatCd());
                var cell5 = row.createCell((short) 4);
                cell5.setCellStyle(cellStyle);
                cell5.setCellValue(presell.getPresellLvlDsc());
                var cell6 = row.createCell((short) 5);
                cell6.setCellStyle(cellStyle);
                log.info(presell.getPresellDueDt());
                cell6.setCellValue(presell.getPresellDueDt() == null ? "" : MM_DD_YYYY_DATE_FORMAT.format(presell.getPresellDueDt()));
                var cell7 = row.createCell((short) 6);
                cell7.setCellStyle(cellStyle);
                cell7.setCellValue(presell.getPlnDistFlg());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (Exception e) {
            log.error("Error at download presell to excel file: {}", e.getMessage());
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
    }

    @Override
    public List<String> getUserIds() {
        log.info("-----Get list user id-----");
        return presellRepository.getUserIDs();
    }

    @Override
    @Transactional
    public String deletePresellList(List<Integer> presellList) {
        log.info("-----Delete presell list-----");
        String strResponse = "success";
        if (presellList != null) {
            itmsoqmapRepository.deletPreSellID(presellList);
            storItemsRepository.deletPreSellID(presellList);
            itemsRepository.deletPreSellID(presellList);
            presellStoreRepository.deletPreSellID(presellList);
            preselLogRepository.deletPreSellID(presellList);
            presellRepository.deletPreSellID(presellList);
        }

        return strResponse;
    }

    @Override
    @Transactional
    public int savePresell(PresellSaveRequestDTO request) {
        log.info("-----Save Presell-----");
        Integer presellId = 1;
        var action = request.getAction();
        if (action.equals(SavePresellAction.CLOSED) || isAutoWithoutCheckSaveAction(request)) {
            log.info("Action: {} | {}. Update Presell And Store Status", SavePresellAction.CLOSED, "AutoWithoutCheck");
            updatePresellAndStoreStatus(request);
        } else if (action.equals(SavePresellAction.SAVE_AS_DRAFT) || isAutoSaveAction(request) || action.equals(SavePresellAction.SEND_TO_STORES)) {
            log.info("Action: {} | {} | {}. Insert or update presell", SavePresellAction.SAVE_AS_DRAFT, "Auto", SavePresellAction.SEND_TO_STORES);
            presellId = savePresellAction(request);
        }
        return presellId;
    }

    private Integer savePresellAction(PresellSaveRequestDTO request) {
        log.info("-----Save presell action-----");
        var action = request.getAction();
        var presellDetailDTO = request.getPresellDetail();
        var presell = presellRepository.findById(request.getPresellDetail().getPsellIdNbr()).orElse(null);
        if (presell == null) {
            // insert new presell, update if otherwise
            var nextId = presellRepository.getMaxId();
            presell = new Presell();
            presell.setPsellIdNbr(++nextId);
            presell.setAddUserId(request.getUserId());
        }
        presell.setPsellDsc(presellDetailDTO.getPsellDsc() == null ? "" : presellDetailDTO.getPsellDsc());
        presell.setBusUnitId(presellDetailDTO.getBusUnitId() == null ? "" : presellDetailDTO.getBusUnitId());
        presell.setPsellLvlIdNbr(presellDetailDTO.getPsellLvlIdNbr() == null ? PresellConstants.NULL_INTEGER : presellDetailDTO.getPsellLvlIdNbr());
        setDuedateAndReminderDate(action, presellDetailDTO, presell);
        presell.setPlnDistFlg(presellDetailDTO.getPlnDistFlg() == null ? "" : presellDetailDTO.getPlnDistFlg());
        presell.setPsellCmtTxt(presellDetailDTO.getPsellCmtTxt() == null ? "" : presellDetailDTO.getPsellCmtTxt());
        if (isAutoSaveAction(request) || request.getAction().equals(SavePresellAction.SEND_TO_STORES)) {
            log.info("Action {} | {}. Send Presell To Store.", "Auto", SavePresellAction.SEND_TO_STORES);
            sendPresellToStores(request, presell);
        } else {
            presell.setPsellStatCd(Status.SAVED_AS_DRAFT.getKey());
        }
        presell.setModUserId(request.getUserId());

        presellRepository.saveAndFlush(presell);

        /* Update presell id number */
        request.getPresellDetail().setPsellIdNbr(presell.getPsellIdNbr());

        /* Inserting/updating Items for the Presell*/
        itemService.insertOrUpdateItemForPresell(request);

        /* Inserting/deleting Stores*/
        storeService.insertOrDeleteStore(request);

        /* Saving Store quantities into the Store Item Table */
        if (isAutoSaveAction(request)) {
            saveStoreItems(request);
        }

        logSavePresellAction(request, action);
        return presell.getPsellIdNbr();
    }

    private void setDuedateAndReminderDate(SavePresellAction action, PresellDetailDTO presellDetailDTO, Presell presell) {
        /* Setting DueDate and Reminder E-mail date to current date for auto-order creation */
        if (presellDetailDTO.getPsellDueDt() == null) {
            presell.setPsellDueDt(DatetimeUtils.getInvalidDate());
        } else {
            presell.setPsellDueDt(action.equals(SavePresellAction.CREATE_AUTO_ORDER) ?
                    DatetimeUtils.getCurrentSQLDate() : DatetimeUtils.convertToSQLDate(presellDetailDTO.getPsellDueDt()));
        }
        if (presellDetailDTO.getRmndrEmailDt() == null) {
            presell.setRmndrEmailDt(DatetimeUtils.getInvalidDate());
        } else {
            presell.setRmndrEmailDt(action.equals(SavePresellAction.CREATE_AUTO_ORDER) ?
                    DatetimeUtils.getCurrentSQLDate() : DatetimeUtils.convertToSQLDate(presellDetailDTO.getRmndrEmailDt()));
        }
    }

    private void logSavePresellAction(PresellSaveRequestDTO request, SavePresellAction action) {
        log.info("-----Log save presell action-----");

        String status = null;
        String logComment = null;
        if (isAutoSaveAction(request)) {
            status = Status.REC_FROM_STORES.getKey();
            logComment = PresellConstants.LOG_AUTO;
            log.info("logComment:{}",logComment);
        } else if (action.equals(SavePresellAction.SAVE_AS_DRAFT)) {
            status = PresellConstants.ADMIN_SAVE;
            logComment = PresellConstants.LOG_DRAFT;
        } else if (action.equals(SavePresellAction.SEND_TO_STORES)) {
            status = SEND_TO_STORES.getKey();
            logComment = PresellConstants.LOG_SENDTOSTORES;
        }
        recordActionToLog(request, status, logComment);

    }

    @Override
    @Transactional
    public int sendToAdditionalStores(PresellSaveRequestDTO request) {
        log.info("-----Send presell to addtional stores-----");
        int rs=storeService.saveNewStoresToPresell(request);
        var presell = presellRepository.findById(request.getPresellDetail().getPsellIdNbr()).orElseThrow();
        presell.setPsellDueDt(DatetimeUtils.convertToSQLDate(request.getPresellDetail().getPsellDueDt()));
        presell.setRmndrEmailDt(DatetimeUtils.convertToSQLDate(request.getPresellDetail().getRmndrEmailDt()));
        presell.setModUserId(request.getUserId());
        presellRepository.save(presell);

        if(rs!=0){
            log.info("sendToAdditionalStores:{}", PresellConstants.LOG_SENDTO_ADDITIONALSTORES);
            recordActionToLog(request, SEND_TO_STORES.getKey(), PresellConstants.LOG_SENDTO_ADDITIONALSTORES);
        }else {
            log.info("sendToAdditionalStores:{}", PresellConstants.LOG_SENDTO_AFTER_DUEDATE_CHANGE);
            recordActionToLog(request, SEND_TO_STORES.getKey(), PresellConstants.LOG_SENDTO_AFTER_DUEDATE_CHANGE);

        }
        return 1;
    }

    private void sendPresellToStores(PresellSaveRequestDTO request, Presell presell) {
        log.info("-----Send presell to store-----");

        /* Calling appropriate DAO method to change Presell status */
        if (request.getAction().equals(SavePresellAction.SEND_TO_STORES)) {
            presell.setPsellStatCd(SEND_TO_STORES.getKey());
        } else if (isAutoSaveAction(request)) {
            presell.setPsellStatCd(Status.REC_FROM_STORES.getKey());
        }

    }

    private void updatePresellAndStoreStatus(PresellSaveRequestDTO request) {
        log.info("-----Update presell and store status-----");

        var action = request.getAction();
        if ((action.equals(SavePresellAction.CREATE_AUTO_ORDER)
                && request.getPresellDetail().getPsellStatCd().equals(SEND_TO_STORES))) {
            saveStoreItems(request);
            recordActionToLog(request, Status.REC_FROM_STORES.getKey(), PresellConstants.LOG_AUTO);
            log.info("create order:{}", PresellConstants.LOG_AUTO);
        }
        var presell = presellRepository.findById(request.getPresellDetail().getPsellIdNbr())
                .orElseThrow(() -> new EntityNotFoundException(Presell.class));
        if (action.equals(SavePresellAction.CLOSED)) {
            presell.setPsellStatCd(Status.CLOSED.getKey());
            presell.setModUserId(request.getUserId());
            recordActionToLog(request, Status.CLOSED.getKey(), PresellConstants.LOG_CLOSED);
            log.info("Closed:{}", PresellConstants.LOG_CLOSED);
        } else {
            presell.setPsellStatCd(Status.REC_FROM_STORES.getKey());
            presell.setPsellDueDt(DatetimeUtils.getCurrentSQLDate());
            presell.setRmndrEmailDt(DatetimeUtils.getCurrentSQLDate());
            presell.setModUserId(request.getUserId());

            var updateStores = request.getPresellDetail().getStoreDTOList()
                    .stream().map(store -> {
                        var presellStorePk = new PresellStorePK();
                        presellStorePk.setStoreNbr(store.getStoreNbr());
                        presellStorePk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
                        var presellStore = new PresellStore();
                        presellStore.setStorePk(presellStorePk);
                        presellStore.setStoreStatCd(Status.SUBMITTED.getKey());
                        presellStore.setModUserId(request.getUserId());
                        return presellStore;
                    }).collect(Collectors.toList());
            storeBatchJDBCTemplate.batchUpdate(updateStores);
        }
       // recordActionToLog(request, Status.REC_FROM_STORES.getKey(), PresellConstants.LOG_AUTO);
        log.info("PresellConstants:{}", PresellConstants.LOG_AUTO);
    }

    private void saveStoreItems(PresellSaveRequestDTO request) {
        log.info("-----Save store items-----");

        int presellId = request.getPresellDetail().getPsellIdNbr();

        var stores = request.getPresellDetail().getStoreDTOList();
        if (stores == null || stores.isEmpty()) {
            log.info("Stores is empty, not perform save store item");
            return;
        }

        var storeClsNbr = getStoreClassificationNumber(request.getPresellDetail());
        var storeIds = stores.stream().map(StoreDTO::getStoreNbr).collect(Collectors.toList());
        List<StorItems> insertItemList = new ArrayList<>();
        request.getPresellDetail().getItemDTOList()
                .forEach(item -> {
                    if (!DBAction.DELETE.equals(item.getAction())) {
                        List<Integer> existingStoreIds = storItemsRepository
                                .fetchExistingStores(
                                        presellId,
                                        new BigDecimal(item.getItemNbr()),
                                        DatetimeUtils.convertToSQLDate(item.getShippingDate()),
                                        storeIds);
                        List<StoreDTO> newStores = stores.stream()
                                .filter(store -> !existingStoreIds.contains(store.getStoreNbr()))
                                .collect(Collectors.toList());
                        log.info("insert new item {} with store list {}", item.getItemNbr(), newStores.stream().map(StoreDTO::getStoreNbr).collect(Collectors.toList()));
                        var insertList = newStores.stream().map(store -> {
                            StorItems storeItem = null;
                            var storeItemPk = new StorItemsPK();
                            storeItemPk.setStoreNbr(store.getStoreNbr());
                            storeItemPk.setPsellIdNbr(presellId);
                            storeItemPk.setItemNbr(new BigDecimal(item.getItemNbr()));
                            storeItemPk.setShipDt(DatetimeUtils.convertToSQLDate(item.getShippingDate()));
                            storeItem = new StorItems();
                            Map<Integer, ItemSOQDTO> soq = new HashMap<>();
                            var lastSOQQty = item.getItemSOQ().get(item.getItemSOQ().size() - 1).getQuantity();
                            item.getItemSOQ().forEach(e -> soq.put(e.getClassificationId(), e));
                            storeItem.setStorItemsPk(storeItemPk);
                            storeItem.setItemOrderQty(soq.get(storeClsNbr.get(store.getStoreNbr())) != null ?
                                    soq.get(storeClsNbr.get(store.getStoreNbr())).getQuantity() :
                                    lastSOQQty.setScale(4, RoundingMode.HALF_EVEN));
                            storeItem.setAddUserId(request.getUserId());
                            storeItem.setModUserId(request.getUserId());
                            return storeItem;
                        }).collect(Collectors.toList());
                        insertItemList.addAll(insertList);
                    }
                });
        itemBatchJDBCTemplate.batchInsert(insertItemList);

    }

    private Map<Integer, Integer> getStoreClassificationNumber(PresellDetailDTO presellDetailDTO) {
        log.info("-----Get store classification number-----");
        var rs = new HashMap<Integer, Integer>();

        var stores = presellDetailDTO.getStoreDTOList();
        var storeNbrs = stores.stream().map(StoreDTO::getStoreNbr).collect(Collectors.toList());
        List<StoreClassificationProjection> storeClassificationProjections = lvlMapngRepository.getStoreClassificationNumber(presellDetailDTO.getPsellLvlIdNbr(), storeNbrs);
        Map<Integer, List<StoreClassificationProjection>> storeClassifications = storeClassificationProjections.stream()
                .collect(Collectors.groupingBy(StoreClassificationProjection::getStoreNbr));
        int lowestStoreClsIdNbr = lvlMapngRepository.fetchLowestClassificationIdNbr();

        stores.forEach(store -> {
            if (storeClassifications.get(store.getStoreNbr()) == null ||
                    storeClassifications.get(store.getStoreNbr()).isEmpty()) {
                rs.put(store.getStoreNbr(), lowestStoreClsIdNbr);
            } else {
                rs.put(store.getStoreNbr(), storeClassifications.get(store.getStoreNbr()).get(0).getClassificationIdNbr());
            }
        });

        return rs;
    }

    private void recordActionToLog(PresellSaveRequestDTO request, String status, String logComment) {
        log.info("-----Record action to log-----");

        var logEntity = new PreselLog();
        var logPk = new PreselLogPK();
        logPk.setPsellIdNbr(request.getPresellDetail().getPsellIdNbr());
        logPk.setStoreNbr(PresellConstants.CORP_STORE_NBR);
        logPk.setAudLogTs(DatetimeUtils.getUTCTimestamp());
        logPk.setAddUserId(request.getUserId());
        logEntity.setPreselLogPk(logPk);
        logEntity.setLogStatCd(status);
        logEntity.setLogCmtTxt(logComment);
        preselLogRepository.save(logEntity);

    }

//    private List<StoreDTO> getStoresForAdd(List<StoreDTO> storeDTOList) {
//        log.info("-----Get list stores for add-----");
//        return storeDTOList.stream().filter(e -> e.getAction().equals(DBAction.INSERT)).collect(Collectors.toList());
//    }

    private boolean isAutoSaveAction(PresellSaveRequestDTO request) {
        log.info("-----Check auto save action-----");
        return (request.getAction().equals(SavePresellAction.CREATE_AUTO_ORDER) // auto
                && !request.getPresellDetail().getPsellStatCd().equals(SEND_TO_STORES));
    }

    private boolean isAutoWithoutCheckSaveAction(PresellSaveRequestDTO request) {
        log.info("-----Auto without check save action-----");
        return (request.getAction().equals(SavePresellAction.CREATE_AUTO_ORDER) // auto
                && request.getPresellDetail().getPsellStatCd().equals(SEND_TO_STORES));
    }

    @Override
    public PresellStoreDetailDTO getPresellDetails(Integer presellID) {
        log.info("-----Get presell details-----");
        PresellStoreDetailDTO presellDetails = new PresellStoreDetailDTO();
        List<ItemsDTO> itemList = new ArrayList<>();
        if (presellID != null) {
            //fetching the presellData
            PresellProjection presellData = presellRepository.getPresellData(presellID);
            if (presellData != null) {
                ModelMapper modelMapper = new ModelMapper();
                presellDetails = modelMapper.map(presellData, PresellStoreDetailDTO.class);
                presellDetails.setPsellStatCd(Objects.requireNonNull(Status.findByKey(presellData.getPsellStatCd())).name());
                presellDetails.setBusUnitDsc(buMstrRepository.getbusUnitDsc(presellDetails.getBusUnitId()));
                presellDetails.setPsellDueDt(DatetimeUtils.isInvalidDate(presellDetails.getPsellDueDt()) ? null : presellDetails.getPsellDueDt());
                presellDetails.setRmndrEmailDt(DatetimeUtils.isInvalidDate(presellDetails.getRmndrEmailDt()) ? null : presellDetails.getRmndrEmailDt());
                //fetching the items
                List<ItemProjection> ilist = itemsRepository.getItemList(presellID);
                Map<BigDecimal, List<ItemProjection>> groupItemById = ilist.stream().collect(Collectors.groupingBy(ItemProjection::getItemNbr));
                groupItemById.forEach((k, v) -> {
                    Map<Date, List<ItemProjection>> groupItemByDate = v.stream().collect(Collectors.groupingBy(ItemProjection::getShipDt));
                    groupItemByDate.forEach((k1, v1) -> {
                        ModelMapper modelMap = new ModelMapper();
                        ItemsDTO item = modelMap.map(v1.get(0), ItemsDTO.class);
                        List<SuggOrderQtyDTO> oderList = new ArrayList<>();
                        v1.forEach(i -> {
                            SuggOrderQtyDTO odrQty = new SuggOrderQtyDTO();
                            odrQty.setPresellLevelID(i.getPsellClsIdNbr());
                            odrQty.setPresellLevelCode(i.getPsellLvlClsCd());
                            odrQty.setSuggOrderQty(i.getSuggOrderQty().toString());
                            oderList.add(odrQty);
                        });
                        item.setSuggOrderQtyList(oderList);
                        item.setShipDt(DatetimeUtils.isInvalidDate(item.getShipDt()) ? null : item.getShipDt());
                        itemList.add(item);
                    });
                });
                itemList.sort(Comparator.comparing(ItemsDTO::getItemNbr));
                presellDetails.setItemList(itemList);
//fetching the Stores
                List<StoreResultsPresellprojection> storeData = presellStoreRepository.getStoreData(presellID);
                log.info("*******storeData************" + storeData.size());
                //presellDetails.setHmStoresForAdd(storeData);
//                ModelMapper modelMap = new ModelMapper();
                List<StoreResultsPresellDTO> storelist = new ArrayList<>();
                for (int i = 0; i < storeData.size(); i++) {
                    StoreResultsPresellDTO storeResults;
                    storeResults = modelMapper.map(storeData.get(i), StoreResultsPresellDTO.class);
                    storelist.add(storeResults);
                }
                presellDetails.setHmStoresForAdd(storelist);
                /* Fetching Log details*/
                int storeNum = 200;
                List<PresellLogProjection> logList = preselLogRepository.getLogData(presellID, storeNum);
                log.info("*******logList************" + logList.size());
                presellDetails.setLogs(logList);
                //Calculate Store count
                if (!PresellConstants.NULL_INTEGER.equals(presellDetails.getHmStoresForAdd().size())) {
                    presellDetails.setStoreCount(presellDetails.getHmStoresForAdd().size());
                    log.info("*******Store count************" + presellDetails.getHmStoresForAdd().size());
                }
                //Calculate Item  Count
                if (presellDetails.getItemList() != null && !PresellConstants.NULL_INTEGER.equals(presellDetails.getItemList().size())) {
                    presellDetails.setItemCount(presellDetails.getItemList().size());
                    log.info("*******Item count************" + presellDetails.getItemList().size());
                }
            } else {
                log.error("Presell entity does not exist!");
                throw new EntityNotFoundException(PresellStoreDetailDTO.class, presellID.toString());
            }
        }

        return presellDetails;
    }

    @Override
    public ByteArrayInputStream downloadItemList(Integer psellIdNbr, String fileName) {
        log.info("-----Download item list-----");
        // TODO Auto-generated method stub
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HSSFWorkbook workbook = new HSSFWorkbook();
        try {
            PresellStoreDetailDTO presell = getPresellDetails(psellIdNbr);
            List<ClassificationDTO> classification = lvlClassRepository.getClassifications();
            presell.setClassification(classification);

            HSSFSheet sheet = workbook.createSheet(fileName);

            // Set header style
            HSSFCellStyle headerStyle = workbook.createCellStyle();
            HSSFFont headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setWrapText(true);
            headerStyle.setBorderTop(BorderStyle.THIN);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);

            // Set cell style
            HSSFCellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setWrapText(true);
            cellStyle.setBorderTop(BorderStyle.THIN);
            cellStyle.setBorderBottom(BorderStyle.THIN);
            cellStyle.setBorderLeft(BorderStyle.THIN);
            cellStyle.setBorderRight(BorderStyle.THIN);

            HSSFRow row = sheet.createRow((short) 0);
            HSSFCell cell = row.createCell((short) 2);
            cell.setCellValue("Presell Item Details");
            cell.setCellStyle(headerStyle);


            int iSize = classification.size();
            row = sheet.createRow((short) 1);
            row.createCell((short) 0);

            row = sheet.createRow((short) 2);

            cell = row.createCell((short) 1);
            cell.setCellValue("Presell Title");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 2).setCellValue(presell.getPsellDsc());

            cell = row.createCell((short) 4);
            cell.setCellValue("Business Unit");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 5).setCellValue(presell.getBusUnitId());

            row = sheet.createRow((short) 3);

            cell = row.createCell((short) 1);
            cell.setCellValue("Presell Level");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 2).setCellValue(lvlMaintRepository.getPresellLevelDscForId(presell.getPsellLvlIdNbr()));

            cell = row.createCell((short) 4);
            cell.setCellValue("Presell Author");
            cell.setCellStyle(headerStyle);

            row = sheet.createRow((short) 4);
            cell = row.createCell((short) 1);
            cell.setCellValue("Due Date");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 2).setCellValue(presell.getPsellDueDt() == null ? "" : MM_DD_YYYY_DATE_FORMAT.format(presell.getPsellDueDt()));

            cell = row.createCell((short) 4);
            cell.setCellValue("Reminder Email Date");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 5).setCellValue(presell.getRmndrEmailDt() == null ? "" : MM_DD_YYYY_DATE_FORMAT.format(presell.getRmndrEmailDt()));

            row = sheet.createRow((short) 5);
            cell = row.createCell((short) 1);
            cell.setCellValue("Planned Distribution");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 2).setCellValue(presell.getPlnDistFlg().equals("YES") ? "No" : "Yes");

            cell = row.createCell((short) 4);
            cell.setCellValue("Status");
            cell.setCellStyle(headerStyle);
            setPresellStatusToCell(presell, row);

            row = sheet.createRow((short) 7);
            cell = row.createCell((short) 1);
            cell.setCellValue("Comments");
            cell.setCellStyle(headerStyle);
            row.createCell((short) 2).setCellValue(presell.getPsellCmtTxt());

            row = sheet.createRow((short) 8);
            row.createCell((short) 0);

            row = sheet.createRow((short) 9);
            row.createCell((short) 0).setCellValue("Item Nbr.");
            row.createCell((short) 1).setCellValue("Shipping Date");
            row.createCell((short) 2).setCellValue("Pack/Size(z)");
            row.createCell((short) 3).setCellValue("Cost");
            row.createCell((short) 4).setCellValue("SRP");
            row.createCell((short) 5).setCellValue("GM(%)");

            HSSFCell cellSOQ = row.createCell((short) 6);
            cellSOQ.setCellValue("SOQ");

            row.createCell((short) (7 + iSize - 1)).setCellValue("Description");
            row.createCell((short) (8 + iSize - 1)).setCellValue("Comment");
            row.createCell((short) (9 + iSize - 1)).setCellValue("URL");

            row.getCell((short) 0).setCellStyle(headerStyle);
            row.getCell((short) 1).setCellStyle(headerStyle);
            row.getCell((short) 2).setCellStyle(headerStyle);
            row.getCell((short) 3).setCellStyle(headerStyle);
            row.getCell((short) 4).setCellStyle(headerStyle);
            row.getCell((short) 5).setCellStyle(headerStyle);
            row.getCell((short) 6).setCellStyle(headerStyle);
            row.getCell((short) (7 + iSize - 1)).setCellStyle(headerStyle);
            row.getCell((short) (8 + iSize - 1)).setCellStyle(headerStyle);
            row.getCell((short) (9 + iSize - 1)).setCellStyle(headerStyle);

            row = sheet.createRow((short) 10);
            int iCnt = 0;
            for (ClassificationDTO objPresellLevelClassificationBean : classification) {
                row.createCell((short) (6 + iCnt)).setCellValue(objPresellLevelClassificationBean.getClassificationDsc());
                row.getCell((short) (6 + iCnt)).setCellStyle(headerStyle);
                ++iCnt;
            }

            iCnt = 11;
            for (ItemsDTO objAdditemsBean : presell.getItemList()) {
                row = sheet.createRow((short) iCnt);
                if (objAdditemsBean.getItemNbr().trim().equals("DSD")
                        || Integer.parseInt(objAdditemsBean.getItemNbr()) < 0) {
                    cell = row.createCell((short) 0);
                    cell.setCellValue("DSD");
                    cell.setCellStyle(cellStyle);
                } else {
                    cell = row.createCell((short) 0);
                    cell.setCellValue(objAdditemsBean.getItemNbr());
                    cell.setCellStyle(cellStyle);
                }
                cell = row.createCell((short) 1);
                cell.setCellValue(objAdditemsBean.getShipDt() == null ? "" : MM_DD_YYYY_DATE_FORMAT.format(objAdditemsBean.getShipDt()));
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 2);
                cell.setCellValue(objAdditemsBean.getItemPkQty() + "/" + objAdditemsBean.getItemSzCnt() + "("
                        + objAdditemsBean.getItemSzCd().trim() + ")");
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 3);
                cell.setCellValue(String.valueOf(Double.parseDouble(objAdditemsBean.getItemCst())));
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 4);
                cell.setCellValue(String.valueOf(Double.parseDouble(objAdditemsBean.getRtlPrc())));
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) 5);
                cell.setCellValue(String.valueOf(Double.parseDouble(objAdditemsBean.getPsellGrmrgAmt())));
                cell.setCellStyle(cellStyle);

                List<SuggOrderQtyDTO> hmItemSOQ = objAdditemsBean.getSuggOrderQtyList();
                log.info("******" + hmItemSOQ.size());
                int iCount = createCellClassificationDataForExcelFile(row, cellStyle, classification, hmItemSOQ);

                cell = row.createCell((short) (7 + iCount - 1));
                cell.setCellValue(objAdditemsBean.getItemDsc());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) (8 + iCount - 1));
                cell.setCellValue(objAdditemsBean.getPsellItemCmtTxt());
                cell.setCellStyle(cellStyle);

                cell = row.createCell((short) (9 + iCount - 1));
                cell.setCellValue(objAdditemsBean.getItemImgUrl());
                cell.setCellStyle(cellStyle);
                ++iCnt;
            }

            workbook.write(out);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.error("Error at download item list: {}", e.getMessage());
            throw ExceptionHandlingHelper.newGenericException(ResponseError.EXPORT_EXCEL_FILE_ERROR, e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }

    private void setPresellStatusToCell(PresellStoreDetailDTO presell, HSSFRow row) {
        log.info("presell status: {}", presell.getPsellStatCd());
        Status presellStatus = Status.valueOf(presell.getPsellStatCd());
        if (presellStatus != null) {
            switch (presellStatus) {
                case SEND_TO_STORES:
                case SAVED_AS_DRAFT:
                    row.createCell((short) 5).setCellValue(Status.PENDING.getStatusDsc());
                    break;
                case SUBMITTED:
                case REC_FROM_STORES:
                    row.createCell((short) 5).setCellValue(Status.SUBMITTED.getStatusDsc());
                    break;
                case CLOSED:
                    row.createCell((short) 5).setCellValue(Status.CLOSED.getStatusDsc());
                    break;
                default:
                    row.createCell((short) 5).setCellValue("");
                    break;
            }
        }
    }

    private int createCellClassificationDataForExcelFile(HSSFRow row, HSSFCellStyle cellStyle, List<ClassificationDTO> classification, List<SuggOrderQtyDTO> hmItemSOQ) {
        log.info("-----Create cell classification data for excel file-----");
        int iCount = 0;
        for (ClassificationDTO objPresellLevelClassificationBean : classification) {
            for (SuggOrderQtyDTO suggOrderQtyDTO : hmItemSOQ) {
                if (suggOrderQtyDTO.getPresellLevelCode().trim()
                        .equals(objPresellLevelClassificationBean.getClassificationDsc().trim())) {
                    HSSFCell cell = row.createCell((short) (6 + iCount));
                    cell.setCellValue(suggOrderQtyDTO.getSuggOrderQty().split("\\.")[0]);
                    cell.setCellStyle(cellStyle);
                }
            }

            ++iCount;
        }
        return iCount;
    }
}
