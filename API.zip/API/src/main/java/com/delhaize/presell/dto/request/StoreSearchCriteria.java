package com.delhaize.presell.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreSearchCriteria {

    private String strStoreNo;

    private String strBusinessUnit;

    private String[] strDivision;//<List>  multiple select

    private String[] strDistrict;//<List>  multiple select

    private String[] strStoreLoc;//<List>  multiple select

    private String strStoreNosAlreadyAdded; //Comma seperated list

}
