package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPSL800_PRESEL_LOG")
public class PreselLog {

  @EmbeddedId
  private PreselLogPK preselLogPk;

  @Column(name="LOG_STAT_CD")
  private String logStatCd;

  @Column(name="LOG_CMT_TXT")
  private String logCmtTxt;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    PreselLog preselLog = (PreselLog) o;
    return preselLogPk != null && Objects.equals(preselLogPk, preselLog.preselLogPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(preselLogPk);
  }
}
