package com.delhaize.presell.repository;

import com.delhaize.presell.entity.StrFlags;
import com.delhaize.presell.entity.StrFlagsPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StrFlagsRepository extends JpaRepository<StrFlags, StrFlagsPK> {
}
