package com.delhaize.presell.constant;

public final class PresellConstants {
	private PresellConstants() {
	}

	public static final String ALL = "ALL";
	public static final String BLANK = "";
	public static final String COMMA = ",";
	public static final String QUESTION = "?";
	public static final String HASH = "-";
	public static final String NEW = "NEW";
	public static final String IND = "IND";
	public static final String Y_VALUE = "Y";
	public static final String N_VALUE = "N";

	public static final String LOG_AUTO = "Created Auto Order";
	public static final String LOG_DRAFT = "Saved As Draft";
	public static final String LOG_SENDTOSTORES = "Sent To Stores";
	public static final String LOG_SENDTO_ADDITIONALSTORES = "Sent To Additional Stores";
	public static final String LOG_SENDTO_AFTER_DUEDATE_CHANGE = "Sent To Stores After Due Date Changes";
	public static final String LOG_CLOSED = "Presell Closed";
	public static final String LOG_REC_FROM_STORES = "Received from Stores";
	public static final String LOG_SUBMITTED = "Submitted";
	public static final Integer CORP_STORE_NBR = 200;
	public static final Integer NULL_INTEGER = 0;
	public static final Double NULL_DECIMAL = 0.0;

	public static final String SWEETBAY = "KNK";

	/* ADMIN_SAVE status occurs when the Prsell is created by the ADMIN User */
	public static final String ADMIN_SAVE = "ADS";

	public static final String DSD = "DSD";
	public static final String MM_DD_YYYY = "MM/dd/yyyy";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DATE_INVALID_FORMAT = "01/01/1001";

	public static final String USER_GROUP_RETL_USER = "PRESELL_RETAIL";
	public static final String USER_GROUP_RETL_ROLE = "RETAIL";
	public static final String USER_GROUP_ADMIN_USER = "PRESELL_ADMIN";
	public static final String USER_GROUP_MERC_USER = "PRESELL_MERCHUSER";

	public static final String SUBMITTED = "SUB";
	public static final String SEND_TO_STORES = "STS";
	public static final String REC_FROM_STORES = "REC";
	public static final String CLOSED_STATUS="CLS";

	public static final String STORE_SUBMIT = "StoreSubmit";
	public static final String STORE_STS = "StoreSTS";

	public static final String SAVE = "save";
	public static final String SUBMIT = "submitted";

	public static final String SAVED_AS_DRAFT = "DRF";
	public static final String PENDING = "Pending";
	// Excel Column Name
	public static final String PRESELL_TITLE = "Presell Title";

	public static final String BUSINESS_UNIT = "Business Unit";

	public static final String AUTHOR = "Author";

	public static final String PRESELL_LEVEL = "Presell Level";

	public static final String DUE_DATE = "Due Date";

	public static final String STATUS = "Status";

	public static final String ITEM_DSD = "DSD";

	public static final String STORE_STATUS_ADS = "ADS";

	public static final String PRESELL_REPORT = "Presell_Rpt_";

	public static final String ATTACHED_FILENAME = "attachment; filename=";

	public static final String STORENO = "Store#";

	public static final String DISTRICT = "District";



}
