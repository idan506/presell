package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TGEO050_BU_SET_MST")
public class BuSetMst {

  @EmbeddedId
  private BuSetMstPK buSetMstPk;

  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="VEND_SET_NBR")
  private Integer vendSetNbr;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    BuSetMst buSetMst = (BuSetMst) o;
    return buSetMstPk != null && Objects.equals(buSetMstPk, buSetMst.buSetMstPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(buSetMstPk);
  }
}
