package com.delhaize.presell.dto.request;

import javax.validation.constraints.NotNull;
import com.delhaize.presell.dto.StorePresellLevelMappingDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreOrderSaveRequestDTO {
	@NotNull
	private StorePresellLevelMappingDTO store;
	
	@NotNull
	private String userId;
}
