package com.delhaize.presell.repository;

import com.delhaize.presell.entity.PuLocXrf;
import com.delhaize.presell.entity.PuLocXrfPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PuLocXrfRepository extends JpaRepository<PuLocXrf, PuLocXrfPK> {
}
