package com.delhaize.presell.repository;

import com.delhaize.presell.dto.projection.LocOrgProjection;
import com.delhaize.presell.entity.LocOrg;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocOrgRepository extends JpaRepository<LocOrg, Integer> {

    @Query("select distinct l.locOrgSidNbr as locOrgSidNbr, l.locOrgDsc as locOrgDsc from LocOrg l where l.locOrgTypId = :locOrgTypId")
    List<LocOrgProjection> fetchLocations(String locOrgTypId);

}
