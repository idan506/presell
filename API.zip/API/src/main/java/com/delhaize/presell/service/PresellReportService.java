package com.delhaize.presell.service;

import com.delhaize.presell.dto.MissingOrderDTO;
import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.StoreItemProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import org.springframework.data.domain.Page;

import java.io.ByteArrayInputStream;
import java.util.List;

public interface PresellReportService {

    Page<PresellReportDTO> searchPresellReport(PresellReportSearchCriteria criteria,
                                               PaginationAndSortDTO paginationAndSortDTO);

    List<ItemProjection> getListItemReport(Integer psellIdNbr);

    List<StoreItemProjection> getListStoreItemReport(Integer psellIdNbr);

    MissingOrderDTO getListMissingOrderReport(Integer psellIdNbr);

    ByteArrayInputStream downLoadStorePresellItemReport(Integer psellIdNbr, String fileName);

    ByteArrayInputStream downLoadStorePresellStoreItemReport(Integer psellIdNbr, String fileName);
    
    ByteArrayInputStream downLoadStorePresellMissingOrderReport(Integer psellIdNbr, String fileName);

    ByteArrayInputStream downLoadStorePresellDraftReport(Integer psellIdNbr, String fileName);

    PresellReportDTO getPresellReportDetails(Integer psellIdNbr);
}
