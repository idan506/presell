package com.delhaize.presell.dto.projection;

import java.sql.Timestamp;

public interface PresellLogProjection {
    Timestamp getAudLogTs();
    String getAddUserId();
    String getLogStatCd();
    String getLogCmtTxt();

}
