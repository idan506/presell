package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TLOC101_STR_FLAGS")
public class StrFlags {

  @EmbeddedId
  private StrFlagsPK strFlagsPk;

  @Column(name="STORE_FLG")
  private String storeFlg;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    StrFlags strFlags = (StrFlags) o;
    return strFlagsPk != null && Objects.equals(strFlagsPk, strFlags.strFlagsPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(strFlagsPk);
  }
}
