package com.delhaize.presell.dto;

import com.delhaize.presell.dto.projection.PresellLogProjection;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StoreOrderItemDTO {
    private String preselLvlClasification;
    private List<ItemsDTO> itemList;
    private List<PresellLogProjection> logs;
}
