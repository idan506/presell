package com.delhaize.presell.dto.projection;

import com.delhaize.presell.dto.serialization.JsonDateSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.springframework.beans.factory.annotation.Value;

public interface StoreItemProjection {
	
	Integer getStoreNbr();

	java.math.BigDecimal getItemNbr();

	java.math.BigDecimal getItemOrderQty();
	@JsonSerialize(using = JsonDateSerializer.class)
	java.sql.Date getShipDt();

	@Value("#{target.itemDsc.trim()}")
	String getItemDsc();

	java.math.BigDecimal getItemCapCst();

	java.math.BigDecimal getItemSzCnt();

	@Value("#{target.itemSzCd.trim()}")
	String getItemSzCd();

	Integer getItemPkQty();

	java.math.BigDecimal getRtlPrc();

	java.math.BigDecimal getPsellGrmrgAmt();
	
	@Value("#{target.psellItemCmtTxt.trim()}")
	String getPsellItemCmtTxt();
	
	@Value("#{target.itemImgUrl.trim()}")
	String getItemImgUrl();
	
	String getPsellLvlClsCd();
	
	@Value("#{target.locOrgDsc.trim()}")
	String getLocOrgDsc();

}
