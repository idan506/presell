package com.delhaize.presell.repository;

import com.delhaize.presell.dto.projection.StoreResultsPresellprojection;
import com.delhaize.presell.entity.PresellStore;
import com.delhaize.presell.entity.PresellStorePK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface PresellStoreRepository extends JpaRepository<PresellStore, PresellStorePK> {

    @Modifying
    @Transactional
    @Query("delete from PresellStore where storePk.psellIdNbr in :psellId")
    void deletPreSellID(@Param("psellId") List<Integer> psellId);

    @Query(value = " SELECT DISTINCT "
            + " TPSL003.STORE_NBR as storeNbr, "
            + " TPSL003.STORE_STAT_CD as storeStatCd, "
            + " TLOC100.STORE_NAM as storeNam, "
            + " COALESCE(TLOC708.LOC_ORG_DSC, ' ') AS dstrcDsc"
            + " FROM "
            + " {h-schema}TLOC100_STORE    TLOC100, "
            + " {h-schema}TPSL003_STORE TPSL003, "
//    		 + " TLOC101_STR_FLAGS  TLOC101, "
            + " {h-schema}TLOC001_LOCATION TLOC001 "
            + " LEFT JOIN "
            + " {h-schema}TLOC708_LOC_ORG TLOC708 "
            + " ON (TLOC001.LOC_ORG_SID_NBR =TLOC708.LOC_ORG_SID_NBR)"
            + " WHERE "
            + " TLOC001.LOC_SID_NBR = TLOC100.STORE_SID_NBR "
            + " AND TPSL003.STORE_NBR = TLOC100.STORE_NBR "
//    		 + " AND TLOC100.SCAN_GRP_NBR  IS NOT NULL " commented because it will skip newly added stores
            + " AND TPSL003.PSELL_ID_NBR = ?"
            + " ORDER BY TPSL003.STORE_NBR "
            + " WITH UR ", nativeQuery = true)
    List<StoreResultsPresellprojection> getStoreData(@Param("presellID") int presellID);

    @Query(value="select ps.storeStatCd from PresellStore ps where storePk.psellIdNbr=:psellIdNbr and storePk.storeNbr =:storeNbr")
    String StoreStatus(@Param("psellIdNbr")Integer psellIdNbr,@Param("storeNbr")Integer storeNbr);

    @Query(value = " SELECT DISTINCT "
            + " TPSL003.STORE_NBR as storeNbr, "
            + " TPSL003.STORE_STAT_CD as storeStatCd, "
            + " TLOC100.STORE_NAM as storeNam, "
            + " COALESCE(TLOC708.LOC_ORG_DSC, ' ') AS dstrcDsc"
            + " FROM "
            + " {h-schema}TLOC100_STORE    TLOC100, "
            + " {h-schema}TPSL003_STORE TPSL003, "
//    		 + " TLOC101_STR_FLAGS  TLOC101, "
            + " {h-schema}TLOC001_LOCATION TLOC001 "
            + " LEFT JOIN "
            + " {h-schema}TLOC708_LOC_ORG TLOC708 "
            + " ON (TLOC001.LOC_ORG_SID_NBR =TLOC708.LOC_ORG_SID_NBR)"
            + " WHERE "
            + " TLOC001.LOC_SID_NBR = TLOC100.STORE_SID_NBR "
            + " AND TPSL003.STORE_NBR = TLOC100.STORE_NBR "
//    		 + " AND TLOC100.SCAN_GRP_NBR  IS NOT NULL " commented because it will skip newly added stores
            + " AND TPSL003.PSELL_ID_NBR = ?"
            + " AND TPSL003.STORE_NBR= ? ", nativeQuery = true)
    List<StoreResultsPresellprojection> getStoreRetailData(@Param("presellID") int presellID,@Param("store")Integer store);
}
