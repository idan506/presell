package com.delhaize.presell.service;

import com.delhaize.presell.dto.projection.LocOrgProjection;
import com.delhaize.presell.dto.projection.StateProjection;

import java.util.List;

public interface LocationService {
    List<LocOrgProjection> getDivisions();

    List<LocOrgProjection> getDistricts();

    List<StateProjection> getStates();
}
