package com.delhaize.presell.service.impl;

import com.delhaize.presell.dto.PresellAuthorDTO;
import com.delhaize.presell.repository.PresellRepository;
import com.delhaize.presell.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

private PresellRepository presellRepository;
@Autowired
public UserServiceImpl(PresellRepository presellRepository){
    this.presellRepository=presellRepository;
}
    @Override
    public List<PresellAuthorDTO> getPresellAuthorsList() {
        List<PresellAuthorDTO> presell=new ArrayList<>();
        List<String> listPresellAuthors=presellRepository.getPresellAuthors();
        int counter=0;
        for(int i=0;i<listPresellAuthors.size();i++){

            PresellAuthorDTO auther=new PresellAuthorDTO();
            auther.setUserID(listPresellAuthors.get(i));
            auther.setUserName("Testing"+counter++);
            presell.add(auther);
        }
        return presell;
    }
}
