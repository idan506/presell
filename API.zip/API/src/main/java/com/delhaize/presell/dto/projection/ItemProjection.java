package com.delhaize.presell.dto.projection;

import com.delhaize.presell.dto.serialization.JsonDateSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.springframework.beans.factory.annotation.Value;

public interface ItemProjection {
	
	java.math.BigDecimal getItemNbr();
	
	java.math.BigDecimal getItemOrderQty();
	
	@Value("#{target.itemDsc.trim()}")
	String getItemDsc();
	@JsonSerialize(using = JsonDateSerializer.class)
	java.sql.Date getShipDt();
	
	java.math.BigDecimal getItemCapCst();
	
	java.math.BigDecimal getItemSzCnt();
	
	@Value("#{target.itemSzCd.trim()}")
	String getItemSzCd();
	
	Integer getItemPkQty();
	
	java.math.BigDecimal getRtlPrc();
	
	java.math.BigDecimal getPsellGrmrgAmt();
	
	@Value("#{target.psellItemCmtTxt.trim()}")
	String getPsellItemCmtTxt();
	
	@Value("#{target.itemImgUrl.trim()}")
	String getItemImgUrl();

	Integer getPsellClsIdNbr();

	String getPsellLvlClsCd();

	java.math.BigDecimal getSuggOrderQty();
}
