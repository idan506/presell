package com.delhaize.presell.dto;

import com.delhaize.presell.util.DatetimeUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PresellLevelDTO {

    @NotNull
    private String levelDsc;

    @NotNull
    private Integer levelId;

    @NotNull
    private Timestamp fetchTime;

    public PresellLevelDTO(Integer levelId, String levelDsc) {
        this.levelId = levelId;
        this.levelDsc = levelDsc;
        this.fetchTime = DatetimeUtils.getUTCTimestamp();
    }
}
