package com.delhaize.presell.dto;

import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
public class LogDTO {
    private String presellId;
    private String user;
    private String storeNbr;
    private Timestamp timestamp;
    private String status;
    private String logComment;
}
