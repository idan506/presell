package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

public interface StateProjection {

    @Value("#{target.state.trim()}")
    String getState();

}
