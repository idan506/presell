package com.delhaize.presell.repository;

import com.delhaize.presell.entity.BaseItem;
import com.delhaize.presell.entity.BaseItemPK;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BaseItemRepository extends JpaRepository<BaseItem, BaseItemPK> {
	@Query(value = "SELECT prcMstrId, prcMstrTypId "
			+ "FROM BaseItem "
			+ "WHERE baseItemPk.itemNbr = :itemNbr "
			+ "AND baseItemPk.itemSetNbr = 1 ")
	List<String> fetchPrcMstrItem(@Param("itemNbr") BigDecimal itemNbr);

}
