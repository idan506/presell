package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPSL004_STOR_ITEMS")
public class StorItems {

  @EmbeddedId
  private StorItemsPK storItemsPk;

  @Column(name="ITEM_ORDER_QTY")
  private java.math.BigDecimal itemOrderQty;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @CreationTimestamp
  @Column(name="ADD_TS")
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @UpdateTimestamp
  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    StorItems storItems = (StorItems) o;
    return storItemsPk != null && Objects.equals(storItemsPk, storItems.storItemsPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(storItemsPk);
  }
}
