package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TITM200_DIST_UNIT")
public class DistUnit {

  @EmbeddedId
  private DistUnitPK distUnitPk;

  @Column(name="ORDER_GUID_CD")
  private String orderGuidCd;

  @Column(name="CUT_TM_DUR")
  private java.math.BigDecimal cutTmDur;

  @Column(name="WRAP_TM_DUR")
  private java.math.BigDecimal wrapTmDur;

  @Column(name="STK_TM_DUR")
  private java.math.BigDecimal stkTmDur;

  @Column(name="PRDT_LN_ID")
  private String prdtLnId;

  @Column(name="CST_MTHD_CD")
  private String cstMthdCd;

  @Column(name="CST_UOM_CD")
  private String cstUomCd;

  @Column(name="MGMT_PLN_GRP_ID")
  private String mgmtPlnGrpId;

  @Column(name="ORDER_SUM_SEQ_NBR")
  private Integer orderSumSeqNbr;

  @Column(name="ITEM_SNL_CD")
  private String itemSnlCd;

  @Column(name="MDSE_CLS_CD")
  private String mdseClsCd;

  @Column(name="ITEM_RTN_CD")
  private String itemRtnCd;

  @Column(name="CMPST_TYP_CD")
  private String cmpstTypCd;

  @Column(name="MIN_RTL_DAYS_CNT")
  private Integer minRtlDaysCnt;

  @Column(name="RCV_ON_WGT_CD")
  private String rcvOnWgtCd;

  @Column(name="ITEM_PK_QTY")
  private Integer itemPkQty;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    DistUnit distUnit = (DistUnit) o;
    return distUnitPk != null && Objects.equals(distUnitPk, distUnit.distUnitPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(distUnitPk);
  }
}
