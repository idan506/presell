package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TCST010_DIST_COST")
public class DistCost {


  @Id
  @Column(name="DIST_CST_SID_NBR")
  private Integer distCstSidNbr;

  @Column(name="DIST_CST_TYP_CD")
  private String distCstTypCd;

  @Column(name="PRDT_CLS_TYP_NBR")
  private Integer prdtClsTypNbr;

  @Column(name="MDSE_DEPT_NBR")
  private Integer mdseDeptNbr;

  @Column(name="MJR_CATG_ID")
  private String mjrCatgId;

  @Column(name="DC_SID_NBR")
  private Integer dcSidNbr;

  @Column(name="WHSE_NBR")
  private Integer whseNbr;

  @Column(name="STORE_SID_NBR")
  private Integer storeSidNbr;

  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;

  @Column(name="EFF_DT")
  private java.sql.Date effDt;

  @Column(name="XPIR_DT")
  private java.sql.Date xpirDt;

  @Column(name="CST_AMT")
  private java.math.BigDecimal cstAmt;

  @Column(name="CRNCY_TYP_CD")
  private String crncyTypCd;

  @Column(name="CST_DAYS_CNT")
  private Integer cstDaysCnt;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    DistCost distCost = (DistCost) o;
    return distCstSidNbr != null && Objects.equals(distCstSidNbr, distCost.distCstSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
