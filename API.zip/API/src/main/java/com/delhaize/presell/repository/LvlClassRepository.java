package com.delhaize.presell.repository;

import com.delhaize.presell.dto.ClassificationDTO;
import com.delhaize.presell.entity.LvlClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface LvlClassRepository extends JpaRepository<LvlClass, Integer> {

    @Query("select new com.delhaize.presell.dto.ClassificationDTO(lc.psellClsIdNbr, trim(lc.psellLvlClsCd)) " +
            "from LvlClass lc " +
            "where lc.lgclDelFlg = 'N' order by lc.psellLvlClsCd asc")
    List<ClassificationDTO> getClassifications();

    @Query("select max(lc.modTs) from LvlClass lc where lc.lgclDelFlg = 'N'")
    Timestamp getMaxModTs();

    @Query("select max(lc.psellClsIdNbr) from LvlClass lc")
    Integer getMaxId();
    
    @Query("SELECT DISTINCT lc.psellLvlClsCd as classificationDsc " +
            "from LvlClass lc " +
            "where lc.lgclDelFlg = 'N' order by lc.psellLvlClsCd asc")
    List<String> getStrListArrayClassification();

    @Query(value="SELECT lc.psellLvlClsCd FROM LvlClass lc  "
            +" WHERE psellClsIdNbr=:classficationID  and lc.lgclDelFlg = 'N' ")
    String getPreselLvlCd(@Param("classficationID")Integer classficationID);
}
