package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TLOC100_STORE")
public class Store {


  @Id
  @Column(name="STORE_SID_NBR")
  private Integer storeSidNbr;

  @Column(name="STORE_NBR")
  private Integer storeNbr;

  @Column(name="STORE_NAM")
  private String storeNam;

  @Column(name="STORE_SHRT_NAM")
  private String storeShrtNam;

  @Column(name="AFFL_CD")
  private String afflCd;

  @Column(name="SCAN_EFF_DT")
  private java.sql.Date scanEffDt;

  @Column(name="SCAN_GRP_NBR")
  private Integer scanGrpNbr;

  @Column(name="TAX_NBR")
  private java.math.BigDecimal taxNbr;

  @Column(name="STAT_CD")
  private String statCd;

  @Column(name="FMT_CD")
  private String fmtCd;

  @Column(name="CHKSD_LBL_CNT")
  private Integer chksdLblCnt;

  @Column(name="SRP_EFF_DOW_NBR")
  private Integer srpEffDowNbr;

  @Column(name="DEA_ID")
  private String deaId;

  @Column(name="DEA_XPIR_DT")
  private java.sql.Date deaXpirDt;

  @Column(name="AR_LOC_ID")
  private String arLocId;

  @Column(name="PROMO_CD")
  private String promoCd;

  @Column(name="BAKE_CLS_CD")
  private String bakeClsCd;

  @Column(name="RCV_SYS_CD")
  private String rcvSysCd;

  @Column(name="LQR_AGCY_NBR")
  private Integer lqrAgcyNbr;

  @Column(name="RPM_GOAL_NBR")
  private Integer rpmGoalNbr;

  @Column(name="SETUP_DT")
  private java.sql.Date setupDt;

  @Column(name="GL_OPEN_DT")
  private java.sql.Date glOpenDt;

  @Column(name="PHYS_CLSE_DT")
  private java.sql.Date physClseDt;

  @Column(name="FIN_CLSE_DT")
  private java.sql.Date finClseDt;

  @Column(name="SYS_XPIR_DT")
  private java.sql.Date sysXpirDt;

  @Column(name="TOT_LANE_NBR")
  private Integer totLaneNbr;

  @Column(name="TOT_TRMNL_NBR")
  private Integer totTrmnlNbr;

  @Column(name="STORE_LAST_CMPR_DT")
  private java.sql.Date storeLastCmprDt;

  @Column(name="INV_SYS_CD")
  private String invSysCd;

  @Column(name="INV_SYS_DT")
  private java.sql.Date invSysDt;

  @Column(name="TOT_SQFT_NBR")
  private Integer totSqftNbr;

  @Column(name="SELL_SQFT_NBR")
  private Integer sellSqftNbr;

  @Column(name="TAG_PROC_CD")
  private String tagProcCd;

  @Column(name="PHAR_OPEN_DT")
  private java.sql.Date pharOpenDt;

  @Column(name="PHAR_CLSE_DT")
  private java.sql.Date pharClseDt;

  @Column(name="PHAR_RMTN_STRT_DT")
  private java.sql.Date pharRmtnStrtDt;

  @Column(name="PHAR_ST_LIC_ID")
  private String pharStLicId;

  @Column(name="MIGR_DATA_SRC_CD")
  private String migrDataSrcCd;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="STORE_RCV_GRP_CD")
  private String storeRcvGrpCd;

  @Column(name="COD_EFF_DT")
  private java.sql.Date codEffDt;

  @Column(name="PHYS_OPEN_DT")
  private java.sql.Date physOpenDt;

  @Column(name="CNSMR_STORE_NAM")
  private String cnsmrStoreNam;

  @Column(name="CNSMR_STORE_URL")
  private String cnsmrStoreUrl;

  @Column(name="TAX_CNTY_ID")
  private String taxCntyId;

  @Column(name="PRC_BNNR_ID")
  private String prcBnnrId;

  @Column(name="TAG_DLV_CD")
  private String tagDlvCd;

  @Column(name="DC_SID_NBR")
  private Integer dcSidNbr;

  @Column(name="WINE_LIC_ID")
  private String wineLicId;

  @Column(name="BNNR_ID")
  private Integer bnnrId;

  @Column(name="CORP_ID")
  private Integer corpId;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    Store store = (Store) o;
    return storeSidNbr != null && Objects.equals(storeSidNbr, store.storeSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
