package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.constant.PresellConstants;
import com.delhaize.presell.dto.MissingOrderDTO;
import com.delhaize.presell.dto.PresellReportDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.dto.projection.StoreItemProjection;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellReportSearchCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.PresellReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.MessageFormat;
import java.util.Date;
import java.util.List;

@Log4j2
@CrossOrigin
@RestController
@RequestMapping("/api/v1/report")
@Tag(name = "report", description = "the presell report API")
public class PresellReportController {

    private static final String MEDIA_EXCEL_TYPE = "application/vnd.ms-excel";

    private PresellReportService presellReportService;

    @Autowired
    public PresellReportController(PresellReportService presellReportService) {
        this.presellReportService = presellReportService;
    }

    @Operation(summary = "Search Presell Report")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = PresellReportDTO.class))),
            @ApiResponse(responseCode = "404", description = "Presell Report not found", content = @Content)})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/search", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Page<PresellReportDTO>> searchPresellReport(PresellReportSearchCriteria criteria,
                                                                      PaginationAndSortDTO paginationAndSortDTO) {
        log.info("searchPresellReport");
        var rs = presellReportService.searchPresellReport(criteria, paginationAndSortDTO);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get Presell Report Details", tags = {"presellReport"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = PresellReportDTO.class))),
            @ApiResponse(responseCode = "404", description = "Presell Report not found", content = @Content)})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<PresellReportDTO> getPresellReportDetails(@PathVariable Integer psellIdNbr) {
        log.info("getPresellReportDetails:{}",psellIdNbr);
        try {
            log.info("TESTING_controller");
            var rs = presellReportService.getPresellReportDetails(psellIdNbr);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.GET_PRESELL_REPORT_DETAILS_ERROR, e);
        }
    }

    @Operation(summary = "Get List Item Report", tags = {"itemReport"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = ItemProjection.class))),
            @ApiResponse(responseCode = "404", description = "Item not found", content = @Content)})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}/item", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<ItemProjection>> getListItemReport(@PathVariable Integer psellIdNbr) {
        log.info("getListItemReport:{}",psellIdNbr);
        var rs = presellReportService.getListItemReport(psellIdNbr);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get List Store Item Report", tags = {"storeItemReport"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = StoreItemProjection.class))),
            @ApiResponse(responseCode = "404", description = "Store Item not found", content = @Content)})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}/storeItem", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<StoreItemProjection>> getListStoreItemReport(@PathVariable Integer psellIdNbr) {
        log.info("getListStoreItemReport:{}",psellIdNbr);
        var rs = presellReportService.getListStoreItemReport(psellIdNbr);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get Missing Order Report", tags = {"missingOrderReport"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = MissingOrderDTO.class))),
            @ApiResponse(responseCode = "404", description = "Store Item not found", content = @Content)})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/{psellIdNbr}/missingOrder", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<MissingOrderDTO> getListMissingOrderReport(@PathVariable Integer psellIdNbr) {
        log.info("getListMissingOrderReport:{}",psellIdNbr);
        var rs = presellReportService.getListMissingOrderReport(psellIdNbr);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Download To XLS Store Presell Report (By Item)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}/itemDownload", produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    public ResponseEntity<Resource> downloadToXLSPresellReportByItem(@PathVariable Integer psellIdNbr) {
        log.info("downloadToXLSPresellReportByItem:{}",psellIdNbr);
        Date dtCurrentDate = new Date();
        String fileName = String.format(PresellConstants.PRESELL_REPORT+"%d.xls", dtCurrentDate.getTime());
        InputStreamResource file = new InputStreamResource(
                presellReportService.downLoadStorePresellItemReport(psellIdNbr, fileName));
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, MessageFormat.format("attachment; filename={0}", fileName))
                .contentType(MediaType.parseMediaType(MEDIA_EXCEL_TYPE)).body(file);
    }

    @Operation(summary = "Download To XLS Store Presell Report (By Store Item)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}/storeItemDownload", produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    public ResponseEntity<Resource> downloadToXLSPresellReportByStoreItem(@PathVariable Integer psellIdNbr) {
        log.info("downloadToXLSPresellReportByStoreItem:{}",psellIdNbr);
        Date dtCurrentDate = new Date();
        String fileName = PresellConstants.PRESELL_REPORT + dtCurrentDate.getTime() + ".xls";
        InputStreamResource file = new InputStreamResource(
                presellReportService.downLoadStorePresellStoreItemReport(psellIdNbr, fileName));
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, PresellConstants.ATTACHED_FILENAME + fileName)
                .contentType(MediaType.parseMediaType(MEDIA_EXCEL_TYPE)).body(file);
    }

    @Operation(summary = "Download To XLS Store Presell Report (By Missing Order)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}/missingOrderDownload", produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    public ResponseEntity<Resource> downloadToXLSPresellReportByMissingOrder(@PathVariable Integer psellIdNbr) {
        log.info("downloadToXLSPresellReportByMissingOrder:{}", psellIdNbr);
        Date dtCurrentDate = new Date();
        String fileName = PresellConstants.PRESELL_REPORT + dtCurrentDate.getTime() + ".xls";
        InputStreamResource file = new InputStreamResource(
                presellReportService.downLoadStorePresellMissingOrderReport(psellIdNbr, fileName));
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, PresellConstants.ATTACHED_FILENAME + fileName)
                .contentType(MediaType.parseMediaType(MEDIA_EXCEL_TYPE)).body(file);
    }
    
    @Operation(summary = "Download To XLS Store Presell Report (By Draft Order)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))})
	@Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
	@GetMapping(value = "/{psellIdNbr}/draftOrderDownload", produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    public ResponseEntity<Resource> downloadToXLSPresellReportByDraftOrder(@PathVariable Integer psellIdNbr) {
        log.info("downloadToXLSPresellReportByDraftOrder:{}", psellIdNbr);
        Date dtCurrentDate = new Date();
        String fileName = PresellConstants.PRESELL_REPORT+ dtCurrentDate.getTime() + ".xls";
        InputStreamResource file = new InputStreamResource(
                presellReportService.downLoadStorePresellDraftReport(psellIdNbr, fileName));
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, PresellConstants.ATTACHED_FILENAME + fileName)
                .contentType(MediaType.parseMediaType(MEDIA_EXCEL_TYPE)).body(file);
    }

}
