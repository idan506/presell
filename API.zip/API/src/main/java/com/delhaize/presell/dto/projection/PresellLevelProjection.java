package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

import java.sql.Timestamp;

public interface PresellLevelProjection {

	Integer getLevelId();

	@Value("#{target.levelDsc.trim()}")
	String getLevelDsc();

	@Value("#{T(com.delhaize.presell.util.DatetimeUtils).UTCTimestamp}")
	Timestamp getFetchTime();
}
