package com.delhaize.presell.repository.template;

import com.delhaize.presell.entity.PresellStore;
import com.delhaize.presell.entity.PresellStorePK;
import com.delhaize.presell.util.DatetimeUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Log4j2
@Service
public class StoreBatchJDBCTemplate {

    private final JdbcTemplate jdbcTemplate;

    @Value("${spring.jpa.properties.hibernate.default_schema}")
    private String schemaName;

    @Autowired
    public StoreBatchJDBCTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public void batchInsert(List<PresellStore> presellStores) {
        if (presellStores.isEmpty()) return;
        log.info("batch insert store list to presell");
        String query =
                "INSERT INTO "+ getTableName()
                        + " (PSELL_ID_NBR, "
                        + " STORE_NBR, "
                        + " STORE_STAT_CD, "
                        + " ADD_USER_ID, "
                        + " ADD_TS, "
                        + " MOD_USER_ID, "
                        + " MOD_TS )"
                        + " VALUES (?, ?, ?, ?, ?, ?, ? )";
        jdbcTemplate.batchUpdate(query, new StoreBatchInsertPreparedStatementSetter(presellStores));
    }

    @Transactional
    public void batchUpdate(List<PresellStore> presellStores) {
        if (presellStores.isEmpty()) return;
        log.info("batch update store list to presell");
        String query =
                "UPDATE "+ getTableName()
                        + " SET "
                        + " STORE_STAT_CD = ?, "
                        + " MOD_USER_ID = ?, "
                        + " MOD_TS = ? "
                        + " WHERE PSELL_ID_NBR = ? "
                        + " AND STORE_NBR = ? ";
        jdbcTemplate.batchUpdate(query, new StoreBatchUpdatePreparedStatementSetter(presellStores));
    }

    @Transactional
    public void batchDelete(List<PresellStorePK> presellStorePKS) {
        if (presellStorePKS.isEmpty()) return;
        log.info("batch delete store list from presell");
        String query =
                "DELETE "
                        + " FROM "+ getTableName()
                        + " WHERE PSELL_ID_NBR = ? "
                        + " AND STORE_NBR = ? ";
        jdbcTemplate.batchUpdate(query, new StoreBatchDeletePreparedStatementSetter(presellStorePKS));
    }

    private String getTableName() {
        return schemaName + ".TPSL003_STORE ";
    }

    public static class StoreBatchInsertPreparedStatementSetter implements BatchPreparedStatementSetter {

        private final List<PresellStore> presellStores;

        public StoreBatchInsertPreparedStatementSetter(List<PresellStore> presellStores) {
            super();
            this.presellStores = presellStores;
        }

        @Override
        public void setValues(PreparedStatement ps, int i) throws SQLException {
            var entity = presellStores.get(i);
            ps.setInt(1, entity.getStorePk().getPsellIdNbr());
            ps.setInt(2, entity.getStorePk().getStoreNbr());
            ps.setString(3, entity.getStoreStatCd());
            ps.setString(4, entity.getAddUserId());
            ps.setTimestamp(5, DatetimeUtils.getUTCTimestamp());
            ps.setString(6, entity.getModUserId());
            ps.setTimestamp(7, DatetimeUtils.getUTCTimestamp());
        }

        @Override
        public int getBatchSize() {
            return presellStores.size();
        }
    }

    public static class StoreBatchUpdatePreparedStatementSetter implements BatchPreparedStatementSetter {

        private final List<PresellStore> presellStores;

        public StoreBatchUpdatePreparedStatementSetter(List<PresellStore> presellStores) {
            super();
            this.presellStores = presellStores;
        }

        @Override
        public void setValues(PreparedStatement ps, int i) throws SQLException {
            var entity = presellStores.get(i);
            ps.setString(1, entity.getStoreStatCd());
            ps.setString(2, entity.getModUserId());
            ps.setTimestamp(3, DatetimeUtils.getUTCTimestamp());
            ps.setInt(4, entity.getStorePk().getPsellIdNbr());
            ps.setInt(5, entity.getStorePk().getStoreNbr());
        }

        @Override
        public int getBatchSize() {
            return presellStores.size();
        }
    }

    public static class StoreBatchDeletePreparedStatementSetter implements BatchPreparedStatementSetter {

        private final List<PresellStorePK> presellStorePKS;

        public StoreBatchDeletePreparedStatementSetter(List<PresellStorePK> presellStorePKS) {
            super();
            this.presellStorePKS = presellStorePKS;
        }

        @Override
        public void setValues(PreparedStatement ps, int i) throws SQLException {
            var pk = presellStorePKS.get(i);
            ps.setInt(1, pk.getPsellIdNbr());
            ps.setInt(2, pk.getStoreNbr());
        }

        @Override
        public int getBatchSize() {
            return presellStorePKS.size();
        }
    }
}
