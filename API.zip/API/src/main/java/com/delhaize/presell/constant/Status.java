package com.delhaize.presell.constant;

import java.util.Arrays;
import java.util.List;

public enum Status {
    SAVED_AS_DRAFT("DRF", "Draft"),
    ALL_INCLUDING_CLOSED(null, "All including Closed"),
    SEND_TO_STORES("STS", "Sent To Stores"),
    REC_FROM_STORES("REC", "Received From Stores"),
    CLOSED("CLS", "Closed"),
    ALL_EXCLUDING_CLOSED(null, "All excluding Closed"),
    SUBMITTED("SUB", "Submitted"),
    PENDING("STS", "Pending"),
    ALL(null, "All"),
    INDEPENDENT("IND","Independent");

    private final String key;
    private final String statusDsc;

    Status(String key, String statusDsc) {
        this.key = key;
        this.statusDsc = statusDsc;
    }

    public String getStatusDsc() {
        return statusDsc;
    }

    public String getKey() {
        return this.key;
    }

    public static Status findByKey(String key) {
        for (var k : values()){
            if (k.getKey() != null && k.getKey().equalsIgnoreCase(key)) {
                return k;
            }
        }
        return null;
    }

    public static String findStatusDsc(String key) {
        for (var k : values()){
            if (k.getKey()!= null && k.getKey().equalsIgnoreCase(key)) {
               String stat=k.getStatusDsc();
                return stat;
            }
        }
        return null;
    }
    
    public static Status findByKeyForSearchStoreOrder(String key) {
    	List<Status> statusList = getForStoreOrderByRetail();
        for (var k : statusList){
            if (k.getKey() != null && k.getKey().equalsIgnoreCase(key)) {
                return k;
            }
        }
        return null;
    }

    public static List<Status> getForPresell() {
        return Arrays.asList(
            SAVED_AS_DRAFT,
            ALL_INCLUDING_CLOSED,
            SEND_TO_STORES,
            REC_FROM_STORES,
            CLOSED,
            ALL_EXCLUDING_CLOSED
        );
    }

    public static List<Status> getForStoreOrder() {
        return Arrays.asList(
                PENDING,
                REC_FROM_STORES,
                CLOSED,
                ALL_EXCLUDING_CLOSED,
                ALL_INCLUDING_CLOSED
        );
    }

    public static List<Status> getForPresellReport() {
        return Arrays.asList(
                ALL,
                SEND_TO_STORES,
                REC_FROM_STORES,
                CLOSED
        );
    }

    public static List<Status> getForStoreOrderByRetail() {
        return Arrays.asList(
                PENDING,
                SUBMITTED,
                SAVED_AS_DRAFT,
                ALL
        );
    }

    @Override
    public String toString() {
        return statusDsc;
    }
}
