package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TITM154_PU_LOC_XRF")
public class PuLocXrf {

  @EmbeddedId
  private PuLocXrfPK puLocXrfPk;

  @Column(name="SHIP_PLLT_TYP_CD")
  private String shipPlltTypCd;

  @Column(name="AUTH_EFF_DT")
  private java.sql.Date authEffDt;

  @Column(name="AUTH_XPIR_DT")
  private java.sql.Date authXpirDt;

  @Column(name="ACT_CST_MSTR_ID")
  private String actCstMstrId;

  @Column(name="WEB_ITEM_FLG")
  private String webItemFlg;

  @Column(name="ASSC_RO_SID_NBR")
  private Integer asscRoSidNbr;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    PuLocXrf puLocXrf = (PuLocXrf) o;
    return puLocXrfPk != null && Objects.equals(puLocXrfPk, puLocXrf.puLocXrfPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(puLocXrfPk);
  }
}
