package com.delhaize.presell.service;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.PresellStoreDetailDTO;
import com.delhaize.presell.dto.SaveEditStoreQtyDTO;

import org.springframework.data.domain.Page;

import com.delhaize.presell.dto.StoreOrderDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.StoreOrderCriteria;

import java.io.ByteArrayInputStream;

public interface StoreOrderService {
	
	Page<StoreOrderDTO> searchStoreOrder(StoreOrderCriteria criteria, PaginationAndSortDTO paginationAndSortDTO);

    PresellStoreDetailDTO getStoreOrderDetails(Integer psellIdNbr, Secured.UserRole role, Integer storeNo);

    ByteArrayInputStream downloadStoreItemDetails(Integer psellIdNbr, Integer storeNbr, String fileName);
    
    int saveEditStoreQuantity(SaveEditStoreQtyDTO criteria);
}
