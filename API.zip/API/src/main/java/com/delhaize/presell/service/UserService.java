package com.delhaize.presell.service;

import com.delhaize.presell.dto.PresellAuthorDTO;

import java.util.List;

public interface UserService {

    List<PresellAuthorDTO> getPresellAuthorsList();
}
