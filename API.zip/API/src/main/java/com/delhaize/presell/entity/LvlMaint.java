package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TPSL006_LVL_MAINT")
public class LvlMaint {


  @Id
  @Column(name="PSELL_LVL_ID_NBR")
  private Integer psellLvlIdNbr;

  @Column(name="PSELL_LVL_DSC")
  private String psellLvlDsc;

  @Column(name="LGCL_DEL_FLG")
  private String lgclDelFlg;

  @Column(name="ADD_USER_ID")
  private String addUserId;

  @Column(name="ADD_TS")
  @CreationTimestamp
  private java.sql.Timestamp addTs;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_TS")
  @UpdateTimestamp
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    LvlMaint lvlMaint = (LvlMaint) o;
    return psellLvlIdNbr != null && Objects.equals(psellLvlIdNbr, lvlMaint.psellLvlIdNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
