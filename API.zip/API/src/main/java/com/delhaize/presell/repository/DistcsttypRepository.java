package com.delhaize.presell.repository;

import com.delhaize.presell.dto.DistcsttypDTO;
import com.delhaize.presell.entity.Distcsttyp;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DistcsttypRepository extends JpaRepository<Distcsttyp, String> {
	@Query(value = "SELECT distCstTypCd as distCstTypCd, "
			+ "distCstTypDsc as distCstTypDsc, "
			+ "distCstRateCd as distCstRateCd, "
			+ "cstByDcFlg as cstByDcFlg, "
			+ "cstByMdeptFlg as cstByMdeptFlg, "
			+ "cstBySelwhFlg as cstBySelwhFlg, "
			+ "cstByCatgFlg as cstByCatgFlg, "
			+ "cstByStoreFlg as cstByStoreFlg, "
			+ "cstByItemFlg as cstByItemFlg "
			+ "FROM Distcsttyp "
			+ "WHERE cstGrpCd = :cstGrpCd "
			+ "ORDER BY distCstTypCd DESC ")
	List<DistcsttypDTO> fetchDistCodeType(@Param("cstGrpCd") String cstGrpCd);
}
