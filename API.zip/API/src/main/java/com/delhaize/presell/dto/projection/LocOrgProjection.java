package com.delhaize.presell.dto.projection;


import org.springframework.beans.factory.annotation.Value;

public interface LocOrgProjection {

    Integer getLocOrgSidNbr();

    @Value("#{target.locOrgDsc.trim()}")
    String getLocOrgDsc();

}
