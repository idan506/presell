package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

public interface BusUnitProjection {

    @Value("#{target.busUnitId.trim()}")
    String getBusUnitId();

    @Value("#{target.busUnitDsc.trim()}")
    String getBusUnitDsc();

}
