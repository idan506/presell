package com.delhaize.presell.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
public class StorePresellLevelDTO {

    private String userId;

    @NotNull
    private Integer storeNo;

    @NotNull
    private List<LevelDTO> presellLevel;


}
