package com.delhaize.presell.controller;

import com.delhaize.presell.dto.*;
import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.StoreDTO;
import com.delhaize.presell.dto.StorePresellLevelMappingDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.StoreService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@CrossOrigin
@Log4j2
@RestController
@RequestMapping("/api/v1/store")
@Tag(name = "store", description = "the store API")
public class StoreController {

    private StoreService storeService;

    @Autowired
    public StoreController(StoreService storeService) {
        this.storeService = storeService;
    }

    @Operation(summary = "Search Store")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = StoreDTO.class))),
            @ApiResponse(responseCode = "404", description = "Store not found", content = @Content)
    })

    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @PostMapping(value="/search",produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<StoresDTO>> searchStore(@Valid @RequestBody StoreSearchCriteria criteria) {
        log.info("searchStore");
        var rs = storeService.searchStore(criteria);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Get Store Number List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = StorePresellLevelMappingDTO.class))),
            @ApiResponse(responseCode = "404", description = "Store Presell Level Mapping not found", content = @Content)
    })
    @Secured
    @GetMapping
    public ResponseEntity<List<Integer>> getStoreNumberList(StorePresellLevelMappingCriteria criteria) {
        log.info("getStoreNumberList");
        try {
            log.info("criteria:" + criteria.getStoreNo()+""+criteria.getStoreType());
            var rs = storeService.getStoreNumberList(criteria);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.GET_STORE_LIST_ERROR, e);
        }

    }
    @Operation(summary = "Get Store Type List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = StorePresellLevelMappingDTO.class))),
            @ApiResponse(responseCode = "404", description = "Store Presell Level Mapping not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @GetMapping(value = "/storeType", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<BusUnitDTO>> getStoreTypeList() {
        log.info("getStoreTypeList");
        try {
            log.info("getStoreTypeList");
            var rs = storeService.getStoreTypeList();
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.GET_STORE_LIST_ERROR, e);
        }
    }
}
