package com.delhaize.presell.repository;

import com.delhaize.presell.dto.projection.MissingOrderProjection;
import com.delhaize.presell.dto.projection.StoreItemProjection;
import com.delhaize.presell.entity.StorItems;
import com.delhaize.presell.entity.StorItemsPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

@Repository
public interface StorItemsRepository extends JpaRepository<StorItems, StorItemsPK> {

    @Modifying
    @Transactional
    @Query("delete from StorItems where storItemsPk.psellIdNbr in :psellId")
    void deletPreSellID(@Param("psellId") List<Integer> psellId);

    @Query(nativeQuery = true, value = "SELECT TPSL010.STORE_NBR AS storeNbr, "
            + "ITEM_NBR as itemNbr, "
            + "ITEM_ORDER_QTY as itemOrderQty, "
            + "SHIP_DT as shipDt, "
            + "ITEM_DSC as itemDsc, "
            + "ITEM_CAP_CST as itemCapCst, "
            + "ITEM_SZ_CNT as itemSzCnt, "
            + "ITEM_SZ_CD as itemSzCd, "
            + "ITEM_PK_QTY as itemPkQty, "
            + "RTL_PRC as rtlPrc, "
            + "PSELL_GRMRG_AMT as psellGrmrgAmt, "
            + "PSELL_ITEM_CMT_TXT as psellItemCmtTxt, "
            + "ITEM_IMG_URL as itemImgUrl , "
            + "TPSL005.PSELL_LVL_CLS_CD as psellLvlClsCd , "
            + "LOC_ORG_DSC as locOrgDsc "
            + "FROM (SELECT TPSL001.PSELL_LVL_ID_NBR PSELL_LVL_ID_NBR, "
            + "TPSL004.STORE_NBR STORE_NBR, "
            + "TPSL004.ITEM_NBR ITEM_NBR, "
            + "TPSL004.ITEM_ORDER_QTY ITEM_ORDER_QTY, "
            + "TPSL004.SHIP_DT SHIP_DT, "
            + "TPSL002.ITEM_DSC ITEM_DSC, "
            + "TPSL002.ITEM_CAP_CST, "
            + "TPSL002.ITEM_SZ_CNT, "
            + "TPSL002.ITEM_SZ_CD, "
            + "TPSL002.ITEM_PK_QTY, "
            + "TPSL002.RTL_PRC, "
            + "TPSL002.PSELL_GRMRG_AMT, "
            + "TPSL002.PSELL_ITEM_CMT_TXT, "
            + "TPSL002.ITEM_IMG_URL, "
            + "TLOC708A.LOC_ORG_DSC LOC_ORG_DSC "
            + "FROM QUAQ.TPSL001_PRESELL TPSL001, "
            + "QUAQ.TPSL002_ITEMS TPSL002, "
            + "QUAQ.TPSL004_STOR_ITEMS TPSL004, "
            + "QUAQ.TLOC100_STORE TLOC100, "
            + "QUAQ.TLOC001_LOCATION TLOC001 "
            + "LEFT JOIN QUAQ.TLOC708_LOC_ORG TLOC708A "
            + "ON (TLOC001.LOC_ORG_SID_NBR =TLOC708A.LOC_ORG_SID_NBR) "
            + "WHERE TPSL004.ITEM_NBR = TPSL002.ITEM_NBR "
            + "AND TPSL004.PSELL_ID_NBR = TPSL002.PSELL_ID_NBR "
            + "AND TPSL004.PSELL_ID_NBR  = TPSL001.PSELL_ID_NBR "
            + "AND TPSL001.PSELL_ID_NBR = TPSL002.PSELL_ID_NBR "
            + "AND TPSL004.STORE_NBR = TLOC100.STORE_NBR "
            + "AND TLOC100.STORE_SID_NBR = TLOC001.LOC_SID_NBR "
            + "AND TPSL004.SHIP_DT = TPSL002.SHIP_DT "
            + "AND TPSL001.PSELL_ID_NBR = :psellIdNbr ) AS TPSL010 "
            + "LEFT OUTER JOIN QUAQ.TPSL007_LVL_MAPNG TPSL007 "
            + "ON( TPSL010.STORE_NBR = TPSL007.STORE_NBR "
            + "AND TPSL010.PSELL_LVL_ID_NBR = TPSL007.PSELL_LVL_ID_NBR) "
            + "LEFT OUTER JOIN QUAQ.TPSL005_LVL_CLASS TPSL005 "
            + "ON (TPSL007.PSELL_CLS_ID_NBR = TPSL005.PSELL_CLS_ID_NBR) "
            + "ORDER BY TPSL010.STORE_NBR, TPSL010.ITEM_NBR, "
            + "TPSL010.ITEM_ORDER_QTY WITH UR")
    List<StoreItemProjection> getListStoreItem(@Param("psellIdNbr") Integer psellIdNbr);

    @Query(value = "SELECT TPSL003.storePk.storeNbr as storeNbr, "
            + "TLOC100.storeNam as storeNam, "
            + "COALESCE(TLOC708.locOrgDsc, ' ') AS locOrgDsc "
            + "FROM PresellStore TPSL003, "
            + "Store TLOC100, "
            + "Location TLOC001 "
            + "LEFT JOIN LocOrg TLOC708 "
            + "ON (TLOC001.locOrgSidNbr = TLOC708.locOrgSidNbr) "
            + "WHERE TPSL003.storePk.storeNbr = TLOC100.storeNbr "
            + "AND TLOC100.storeSidNbr = TLOC001.locSidNbr "
            + "AND TLOC001.locTypId = 'ST' "
            + "AND TPSL003.storePk.psellIdNbr = :psellIdNbr "
            + "AND TPSL003.storeStatCd = :status "
            + "ORDER BY TPSL003.storePk.storeNbr ")
    List<MissingOrderProjection> getListMissingOrder(@Param("psellIdNbr") Integer psellIdNbr,
                                                     @Param("status") String status);

    @Query("select si.storItemsPk.storeNbr from StorItems si " +
            "where si.storItemsPk.psellIdNbr = :psellIdNbr " +
            "and si.storItemsPk.itemNbr = :itemNbr " +
            "and si.storItemsPk.shipDt = :shipDt " +
            "and si.storItemsPk.storeNbr in :storeNbrs")
    List<Integer> fetchExistingStores(Integer psellIdNbr, BigDecimal itemNbr, Date shipDt, List<Integer> storeNbrs);
}
