package com.delhaize.presell.dto;

import java.io.Serializable;
import java.util.Date;

import com.delhaize.presell.dto.serialization.JsonDateSerializer;

import com.delhaize.presell.annotation.QueryProjection;
import com.delhaize.presell.dto.serialization.WhiteSpaceRemovalSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class PresellReportDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer psellIdNbr;
	
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String psellDsc;
	
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String busUnitId;
	
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String psellLvlDsc;
	
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String psellStatCd;
	
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	@JsonSerialize(using = JsonDateSerializer.class)
	private Date psellDueDt;
	
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String plnDistFlg;
	
	@JsonSerialize(using = WhiteSpaceRemovalSerializer.class)
	private String presellAuthor;

	private String authorName = "author name";
}
