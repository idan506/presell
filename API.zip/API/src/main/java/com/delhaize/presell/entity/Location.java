package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TLOC001_LOCATION")
public class Location {


  @Id
  @Column(name="LOC_SID_NBR")
  private Integer locSidNbr;

  @Column(name="BUS_UNIT_ID")
  private String busUnitId;

  @Column(name="LOC_ORG_SID_NBR")
  private Integer locOrgSidNbr;

  @Column(name="GEO_REGN_CD")
  private String geoRegnCd;

  @Column(name="LOC_TYP_ID")
  private String locTypId;

  @Column(name="CO_LOC_ID")
  private String coLocId;

  @Column(name="GLN_NBR")
  private java.math.BigDecimal glnNbr;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    Location location = (Location) o;
    return locSidNbr != null && Objects.equals(locSidNbr, location.locSidNbr);
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }
}
