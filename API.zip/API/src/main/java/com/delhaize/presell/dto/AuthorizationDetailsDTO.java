package com.delhaize.presell.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
public class AuthorizationDetailsDTO {
	
	private ArrayList<Object> businessPhones = new ArrayList<>();
	private String displayName;
	private String givenName = null;
	private String jobTitle = null;
	private String mail;
	private String mobilePhone = null;
	private String officeLocation = null;
	private String preferredLanguage = null;
	private String surname = null;
	private String userPrincipalName;
	private String id;
	private Integer httpStatusCode;
	private String httpStatusMessage;
}
