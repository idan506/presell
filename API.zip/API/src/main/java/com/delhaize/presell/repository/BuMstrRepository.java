package com.delhaize.presell.repository;

import com.delhaize.presell.dto.BusUnitDTO;
import com.delhaize.presell.entity.BuMstr;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BuMstrRepository extends JpaRepository<BuMstr, String> {

    @Query("select new com.delhaize.presell.dto.BusUnitDTO(trim(parntBusUnitId) , trim(busUnitDsc)) from BuMstr where parntBusUnitFlg = 'Y'")
    List<BusUnitDTO> getBusUnits();

    @Query("select trim(busUnitDsc) from BuMstr where parntBusUnitFlg = 'Y' and parntBusUnitId=:busUnit ")
    String  getbusUnitDsc(@Param("busUnit") String busUnit);
}
