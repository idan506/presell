package com.delhaize.presell.repository;

import com.delhaize.presell.dto.LvlMappingDTO;
import com.delhaize.presell.dto.projection.StoreClassificationProjection;
import com.delhaize.presell.entity.LvlMapng;
import com.delhaize.presell.entity.LvlMapngPK;

import java.sql.Timestamp;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public interface LvlMapngRepository extends JpaRepository<LvlMapng, LvlMapngPK> {

	@Query(value = "SELECT " + "TPSL007.lvlMapngPk.psellLvlIdNbr as levelId, " + "TPSL007.psellClsIdNbr as classId "
			+ "FROM LvlMapng TPSL007 " + "WHERE TPSL007.lvlMapngPk.storeNbr = :storeNo ")
	List<LvlMappingDTO> getStorePresellLevelMapping(@Param("storeNo") Integer storeNo);

	@Query("select TPSL007.lvlMapngPk.storeNbr as storeNbr, TPSL007.psellClsIdNbr as classificationIdNbr from LvlMapng TPSL007 inner join LvlClass TPSL005 on TPSL007.psellClsIdNbr = TPSL005.psellClsIdNbr "
			+ "where TPSL005.lgclDelFlg <> 'Y' and TPSL007.lvlMapngPk.psellLvlIdNbr = :psellLvlIdNbr and TPSL007.lvlMapngPk.storeNbr in :storeNbrs")
	List<StoreClassificationProjection> getStoreClassificationNumber(Integer psellLvlIdNbr, List<Integer> storeNbrs);

	@Query("select min(TPSL007.psellClsIdNbr) from LvlMapng TPSL007")
	Integer fetchLowestClassificationIdNbr();

	@Transactional(rollbackFor = Exception.class)
	@Modifying
	@Query(value="DELETE from LvlMapng where lvlMapngPk.storeNbr=:storeNm  and lvlMapngPk.psellLvlIdNbr=:presellLevelNm")
	void deletePreselllevel(@Param ("storeNm") int storeNm,@Param("presellLevelNm") int presellLevelNm);
@Transactional(rollbackFor = Exception.class)
	@Modifying
   @Query(value ="UPDATE LvlMapng SET psellClsIdNbr=:psellClsNbr ,modUserId=:userId ,modTs=:modTs WHERE lvlMapngPk.storeNbr=:storeNbr AND lvlMapngPk.psellLvlIdNbr=:psellLvlNbr ")
   int updatelevelMapping(@Param("storeNbr") int storeNbr, @Param("psellLvlNbr") int psellLvlNbr,@Param("psellClsNbr") int psellClsNbr, @Param("userId")  String userId, @Param("modTs") Timestamp modTs);

@Query(value="SELECT lm.psellClsIdNbr FROM LvlMapng lm "
		+" WHERE lvlMapngPk.psellLvlIdNbr = :psellLvlId AND lvlMapngPk.storeNbr =:storeNbr ")
	Integer getClsId(@Param("psellLvlId")Integer psellLvlId,@Param("storeNbr")Integer storeNbr);
}
