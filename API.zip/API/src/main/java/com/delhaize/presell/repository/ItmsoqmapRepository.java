package com.delhaize.presell.repository;

import com.delhaize.presell.entity.Itmsoqmap;
import com.delhaize.presell.entity.ItmsoqmapPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

@Repository
public interface ItmsoqmapRepository extends JpaRepository<Itmsoqmap, ItmsoqmapPK> {

    @Modifying
    @Transactional
    @Query(value = "delete from Itmsoqmap where itmsoqmapPk.psellIdNbr in :psellId")
    void deletPreSellID(@Param("psellId") List<Integer> psellId);

    @Modifying
    @Query("delete from Itmsoqmap where itmsoqmapPk.psellIdNbr = :psellIdNbr and itmsoqmapPk.itemNbr = :itemNbr and itmsoqmapPk.shipDt = :shipDt")
    void deleteEntityByPk(Integer psellIdNbr, BigDecimal itemNbr, Date shipDt);
}
