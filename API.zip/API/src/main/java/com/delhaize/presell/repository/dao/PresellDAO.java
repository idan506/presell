package com.delhaize.presell.repository.dao;

import com.delhaize.presell.dto.PresellDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface PresellDAO {
    Page<PresellDTO> searchPresell(PresellSearchCriteria criteria, Pageable pageable);
}
