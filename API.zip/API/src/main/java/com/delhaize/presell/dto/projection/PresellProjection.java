package com.delhaize.presell.dto.projection;

import org.springframework.beans.factory.annotation.Value;

import java.sql.Timestamp;
import java.util.Date;

public interface PresellProjection {

    Integer getPsellIdNbr();

    Integer getpsellLvlIdNbr();
    @Value("#{target.busUnitId.trim()}")
    String getBusUnitId();
    @Value("#{target.psellDsc.trim()}")
   String getPsellDsc();

    Date getPsellDueDt();

   String getPlnDistFlg();

   Date getRmndrEmailDt();

    String getPsellCmtTxt();

   String getPsellStatCd ();

    String getAddUserId();

    Timestamp getAddTs();

   String getModUserId ();

    Timestamp getModTs();




}
