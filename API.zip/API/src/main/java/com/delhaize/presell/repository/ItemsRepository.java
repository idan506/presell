package com.delhaize.presell.repository;

import com.delhaize.presell.dto.AddItemsDTO;
import com.delhaize.presell.dto.DcDTO;
import com.delhaize.presell.dto.VendorInfoDTO;
import com.delhaize.presell.dto.projection.ItemProjection;
import com.delhaize.presell.entity.Items;
import com.delhaize.presell.entity.ItemsPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

@Repository
public interface ItemsRepository extends JpaRepository<Items, ItemsPK> {

    @Modifying
    @Transactional
    @Query("delete from Items where itemsPk.psellIdNbr in :psellId")
    void deletPreSellID(@Param("psellId") List<Integer> psellId);

    @Query(value = "SELECT TPSL004.storItemsPk.itemNbr AS itemNbr, " + "SUM(TPSL004.itemOrderQty) AS itemOrderQty, "
            + "TPSL002.itemDsc AS itemDsc, " + "TPSL002.itemsPk.shipDt AS shipDt, "
            + "TPSL002.itemCapCst AS itemCapCst, " + "TPSL002.itemSzCnt AS itemSzCnt, "
            + "TPSL002.itemSzCd AS itemSzCd, " + "TPSL002.itemPkQty AS itemPkQty, " + "TPSL002.rtlPrc AS rtlPrc, "
            + "TPSL002.psellGrmrgAmt AS psellGrmrgAmt, " + "TPSL002.psellItemCmtTxt AS psellItemCmtTxt, "
            + "TPSL002.itemImgUrl AS itemImgUrl " + "FROM StorItems TPSL004, " + "Items TPSL002 "
            + "WHERE TPSL004.storItemsPk.itemNbr = TPSL002.itemsPk.itemNbr "
            + "AND TPSL004.storItemsPk.psellIdNbr =  TPSL002.itemsPk.psellIdNbr "
            + "AND TPSL004.storItemsPk.shipDt = TPSL002.itemsPk.shipDt "
            + "AND TPSL004.storItemsPk.psellIdNbr = :psellIdNbr " + "GROUP BY TPSL004.storItemsPk.itemNbr, "
            + "TPSL002.itemDsc," + "TPSL002.itemsPk.shipDt, " + "TPSL002.itemCapCst," + "TPSL002.itemSzCnt,"
            + "TPSL002.itemSzCd," + "TPSL002.itemPkQty, " + "TPSL002.rtlPrc," + "TPSL002.psellGrmrgAmt,"
            + "TPSL002.psellItemCmtTxt," + "TPSL002.itemImgUrl " + "ORDER BY itemNbr, " + "itemOrderQty")
    List<ItemProjection> getListItem(@Param("psellIdNbr") Integer psellIdNbr);

    @Query(value = "SELECT TITM200.itemPkQty AS pack, TITM100.itemSzCnt AS size, "
            + "TITM100.itemSzCd AS sizeCode, TITM100.itemDsc AS description "
            + "FROM BaseItem TITM100, DistUnit TITM200 "
            + "WHERE TITM100.baseItemPk.itemNbr = TITM200.distUnitPk.itemNbr "
            + "AND TITM100.baseItemPk.itemSetNbr = TITM200.distUnitPk.itemSetNbr "
            + "AND TITM200.distUnitPk.itemSetNbr = 1 " + "AND TITM100.itemStatCd IN ('A','N','T') "
            + "AND TITM100.baseItemPk.itemNbr = :itemNbr ")
    AddItemsDTO getItemDetails(@Param("itemNbr") BigDecimal itemNbr);

    @Query(nativeQuery = true, value = "SELECT TLOC200.DC_ID AS dcId, TLOC200.DC_SID_NBR AS dcSidNbr "
            + "FROM {h-schema}TITM202_DU_DC_XREF TITM202 "
            + "INNER JOIN {h-schema}TLOC001_LOCATION TLOC001 ON (TLOC001.LOC_SID_NBR = TITM202.DC_SID_NBR) "
            + "INNER JOIN {h-schema}TLOC200_DC TLOC200 ON (TLOC200.DC_SID_NBR = TITM202.DC_SID_NBR) "
            + "WHERE TLOC001.BUS_UNIT_ID = :busUnit "
            + "AND TITM202.ITEM_SET_NBR  = 1 AND TITM202.ITEM_NBR = :itemNbr  WITH UR")
    List<DcDTO> getDCIds(@Param("busUnit") String busUnit, @Param("itemNbr") BigDecimal itemNbr);

    @Query(nativeQuery = true, value = "SELECT TITM202.MSTR_RPT_VEND_ID as vendorId, TVND100.VEND_NAM as vendorName "
            + "FROM {h-schema}TITM202_DU_DC_XREF TITM202 "
            + "INNER JOIN {h-schema}TVND100_VENDOR TVND100 ON (TVND100.VEND_ID = TITM202.MSTR_RPT_VEND_ID) "
            + "WHERE TITM202.ITEM_NBR = :itemNbr " + "AND TITM202.ITEM_SET_NBR = 1 "
            + "AND TITM202.DC_SID_NBR = :dcSidNbr " + "AND TITM202.DIST_ITEM_SEQ_NBR = 1 WITH UR ")
    List<VendorInfoDTO> getVendorId(@Param("itemNbr") BigDecimal itemNbr, @Param("dcSidNbr") Integer dcSidNbr);

    @Query(nativeQuery = true, value = "SELECT TLOC200.DC_SID_NBR, TLOC200.DC_ID, TGEO050O.BUS_UNIT_ID, "
            + "TGEO050O.ITEM_SET_NBR, TGEO050O.VEND_SET_NBR, TGEO050O.EFF_DT "
            + "FROM {h-schema}TGEO050_BU_SET_MST TGEO050O, {h-schema}TLOC200_DC TLOC200, {h-schema}TLOC001_LOCATION TLOC001 "
            + "WHERE TLOC001.LOC_SID_NBR = TLOC200.DC_SID_NBR " + "AND TLOC001.BUS_UNIT_ID = TGEO050O.BUS_UNIT_ID "
            + "AND TGEO050O.EFF_DT = (SELECT MAX(TGEO050I.EFF_DT) " + "FROM {h-schema}TGEO050_BU_SET_MST TGEO050I "
            + "WHERE TGEO050O.BUS_UNIT_ID = TGEO050I.BUS_UNIT_ID " + "AND TGEO050I.EFF_DT <= CURRENT DATE)"
            + "AND TLOC200.DC_ID = :dcId")
    List<String> fetchSidNumber(@Param("dcId") String dcId);

    @Query(value = "SELECT actCstMstrId AS actCstMstrId " + "FROM PuLocXrf TITM154 "
            + "WHERE TITM154.puLocXrfPk.itemNbr = :itemNbr " + "AND TITM154.puLocXrfPk.itemSetNbr = 1 "
            + "AND TITM154.puLocXrfPk.vendId = :vendorId " + "AND TITM154.puLocXrfPk.vendSetNbr = :vendorSetNbr "
            + "AND TITM154.puLocXrfPk.locSidNbr = :dcSidNbr ")
    List<String> fetchCostMstrId(@Param("itemNbr") BigDecimal itemNbr, @Param("vendorId") String vendorId,
                                 @Param("vendorSetNbr") Integer vendorSetNbr, @Param("dcSidNbr") Integer dcSidNbr);

    @Query(value = "SELECT TITM154.actCstMstrId AS actCstMstrId, " + "TITM202.mstrRptVendId AS mstrRptVendId "
            + "FROM PuLocXrf TITM154 "
            + "INNER JOIN DuDcXref TITM202 ON (TITM202.duDcXrefPk.itemSetNbr = TITM154.puLocXrfPk.itemSetNbr "
            + "AND TITM202.duDcXrefPk.itemNbr = TITM154.puLocXrfPk.itemNbr "
            + "AND TITM202.mstrRptVendId = TITM154.puLocXrfPk.vendId) " + "WHERE TITM202.duDcXrefPk.itemNbr = :itemNbr "
            + "AND TITM202.duDcXrefPk.itemSetNbr = 1 " + "AND TITM202.duDcXrefPk.dcSidNbr = :dcSidNbr "
            + "AND TITM154.puLocXrfPk.vendSetNbr = :vendorSetNbr " + "AND TITM202.duDcXrefPk.distItemSeqNbr = 1 ")
    List<String> fetchCostMstrIdForReportVendorId(@Param("itemNbr") BigDecimal itemNbr,
                                                  @Param("dcSidNbr") Integer dcSidNbr, @Param("vendorSetNbr") Integer vendorSetNbr);

    @Query(value = "SELECT TCST002A.brktNbr FROM Bracket TCST002A " + "WHERE TCST002A.estPerfLvlFlg = 'Y' "
            + "AND TCST002A.vendId = :vendorId " + "AND TCST002A.vendSetNbr = :vendorSetNbr "
            + "AND TCST002A.locSidNbr = :dcSidNbr " + "AND TCST002A.brktEffDt = (SELECT MAX(TCST002B.brktEffDt) "
            + "FROM Bracket TCST002B " + "WHERE TCST002B.brktEffDt <= :dateOfCost "
            + "AND TCST002A.vendId = TCST002B.vendId " + "AND TCST002B.locSidNbr = TCST002A.locSidNbr "
            + "AND TCST002A.vendSetNbr = TCST002B.vendSetNbr) ")
    List<String> fetchDefaultBracketNumber(@Param("vendorId") String vendorId,
                                           @Param("vendorSetNbr") Integer vendorSetNbr, @Param("dcSidNbr") Integer dcSidNbr,
                                           @Param("dateOfCost") Date dateOfCost);

    @Query(value = "SELECT TCST003.effDt, TCST003.cstAmt " + "FROM PurchCost TCST003 WHERE TCST003.itemNbr = :itemNbr "
            + "AND TCST003.itemSetNbr = 1 " + "AND TCST003.vendId = :vendorId "
            + "AND TCST003.vendSetNbr = :vendorSetNbr " + "AND TCST003.cstCmpntTypNbr = '01' "
            + "AND TCST003.alwTypNbr IS NULL " + "AND TCST003.xpirDt IS NULL " + "AND TCST003.brktNbr = :bracketNbr "
            + "AND TCST003.locSidNbr = :dcSidNbr " + "AND effDt = (SELECT MAX(effDt) FROM PurchCost TCST003A "
            + "WHERE TCST003.itemNbr = TCST003A.itemNbr " + "AND  TCST003.vendId = TCST003A.vendId "
            + "AND TCST003.itemSetNbr = TCST003A.itemSetNbr " + "AND TCST003.vendSetNbr = TCST003A.vendSetNbr "
            + "AND TCST003.cstCmpntTypNbr = TCST003A.cstCmpntTypNbr " + "AND TCST003.locSidNbr = TCST003A.locSidNbr "
            + "AND TCST003A.effDt <= :dateOfCost) " + "AND TCST003.cstMstrId IS NULL ")
    List<String> fetchItemCostDetails(@Param("itemNbr") BigDecimal itemNbr, @Param("vendorId") String vendorId,
                                      @Param("vendorSetNbr") Integer vendorSetNbr, @Param("bracketNbr") Integer bracketNbr,
                                      @Param("dcSidNbr") Integer dcSidNbr, @Param("dateOfCost") Date dateOfCost);

    @Query(nativeQuery = true, value = "SELECT TCST003.CST_AMT, TCST003.PUR_CST_SID_NBR, "
            + "TCST003.ALW_TYP_NBR, TCST003.TOT_SELL_ALW_AMT, TCST001.ALW_MLT "
            + "FROM {h-schema}TCST003_PURCH_COST TCST003 " + "INNER JOIN {h-schema}TCST001_ALW_MSTR TCST001 "
            + "ON (TCST003.ALW_TYP_NBR = TCST001.ALW_TYP_NBR) " + "WHERE TCST003.ITEM_NBR  = :itemNbr "
            + "AND TCST003.ITEM_SET_NBR = 1 " + "AND TCST003.VEND_ID = :vendorId "
            + "AND TCST003.VEND_SET_NBR = :vendorSetNbr " + "AND TCST003.EFF_DT <= CURRENT DATE "
            + "AND TCST003.XPIR_DT >= CURRENT DATE " + "AND TCST003.CST_CMPNT_TYP_NBR = '02' "
            + "AND TCST003.LOC_SID_NBR = :dcSidNbr " + "AND TCST003.CST_MSTR_ID IS NULL "
            + "ORDER BY TCST003.EFF_DT WITH UR ")
    List<String> fetchItemDealDetails(@Param("itemNbr") BigDecimal itemNbr, @Param("vendorId") String vendorId,
                                      @Param("vendorSetNbr") Integer vendorSetNbr, @Param("dcSidNbr") Integer dcSidNbr);

//    @Query(value = "SELECT TCST003.effDt, TCST003.cstAmt " 
//    		+ "FROM PurchCost TCST003 "
//            + "WHERE TCST003.cstMstrId = :cstMstrId " 
//    		+ "AND TCST003.vendId = :vendorId "
//            + "AND TCST003.vendSetNbr = :vendorSetNbr " 
//    		+ "AND TCST003.cstCmpntTypNbr = '01' "
//            + "AND TCST003.locSidNbr = :dcSidNbr " 
//    		+ "AND TCST003.alwTypNbr IS NULL " 
//            + "AND TCST003.xpirDt IS NULL "
//            + "AND TCST003.brktNbr = :bracketNbr " 
//            + "AND effDt = (SELECT MAX(effDt) "
//            + "FROM PurchCost TCST003A "
//            + "WHERE TCST003.vendId = TCST003A.vendId " 
//            + "AND TCST003.vendSetNbr = TCST003A.vendSetNbr "
//            + "AND TCST003.cstMstrId = TCST003A.cstMstrId " 
//            + "AND TCST003.cstCmpntTypNbr = TCST003A.cstCmpntTypNbr "
//            + "AND TCST003.locSidNbr = TCST003A.locSidNbr " 
//            + "AND TCST003A.effDt <= :dateOfCost) "
//            + "AND TCST003.itemNbr IS NULL ")
//    List<String> fetchCstmstrCostDetails(@Param("cstMstrId") String cstMstrId, @Param("vendorId") String vendorId,
//                                         @Param("vendorSetNbr") Integer vendorSetNbr, @Param("bracketNbr") Integer bracketNbr,
//                                         @Param("dcSidNbr") Integer dcSidNbr, @Param("dateOfCost") Date dateOfCost);
    
    @Query(nativeQuery = true, value = "SELECT TCST003.EFF_DT, TCST003.CST_AMT "
    		+ "FROM {h-schema}TCST003_PURCH_COST TCST003 "
    		+ "WHERE TCST003.CST_MSTR_ID = :cstMstrId "
    		+ "AND  TCST003.VEND_ID = :vendorId "
    		+ "AND TCST003.VEND_SET_NBR = :vendorSetNbr "
    		+ "AND TCST003.CST_CMPNT_TYP_NBR = '01' "
    		+ "AND TCST003.LOC_SID_NBR = :dcSidNbr "
    		+ "AND TCST003.ALW_TYP_NBR IS NULL "
    		+ "AND TCST003.XPIR_DT IS NULL "
    		+ "AND TCST003.BRKT_NBR = :bracketNbr "
    		+ "AND EFF_DT = ( SELECT MAX(EFF_DT) "
    		+ "FROM {h-schema}TCST003_PURCH_COST TCST003A "
    		+ "WHERE TCST003.VEND_ID = TCST003A.VEND_ID "
    		+ "AND TCST003.VEND_SET_NBR = TCST003A.VEND_SET_NBR "
    		+ "AND TCST003.CST_MSTR_ID = TCST003A.CST_MSTR_ID "
    		+ "AND TCST003.CST_CMPNT_TYP_NBR = TCST003A.CST_CMPNT_TYP_NBR "
    		+ "AND TCST003.LOC_SID_NBR = TCST003A.LOC_SID_NBR "
    		+ "AND TCST003A.EFF_DT <= CURRENT DATE) "
    		+ "AND TCST003.ITEM_NBR IS NULL "
    		+ "WITH UR")
    List<String> fetchCstmstrCostDetails(@Param("cstMstrId") String cstMstrId, @Param("vendorId") String vendorId,
                                         @Param("vendorSetNbr") Integer vendorSetNbr,
                                         @Param("dcSidNbr") Integer dcSidNbr,
                                         @Param("bracketNbr") Integer bracketNbr) throws SQLException;

    @Query(nativeQuery = true, value = "SELECT TCST003.CST_AMT, TCST003.TOT_SELL_ALW_AMT, TCST001.ALW_MLT "
            + "FROM {h-schema}TCST003_PURCH_COST TCST003 " + "INNER JOIN {h-schema}TCST001_ALW_MSTR TCST001 "
            + "ON (TCST001.ALW_TYP_NBR = TCST003.ALW_TYP_NBR) " + "WHERE TCST003.CST_MSTR_ID = :cstMstrId "
            + "AND TCST003.VEND_ID = :vendorId " + "AND TCST003.VEND_SET_NBR = :vendorSetNbr "
            + "AND TCST003.EFF_DT <= CURRENT DATE " + "AND TCST003.XPIR_DT >= CURRENT DATE "
            + "AND TCST003.LOC_SID_NBR = :dcSidNbr " + "AND TCST003.CST_CMPNT_TYP_NBR = '02' "
            + "AND TCST003.ITEM_NBR IS NULL " + "ORDER BY TCST003.EFF_DT WITH UR")
    List<String> fetchCstmstrDealDetails(@Param("cstMstrId") String cstMstrId, @Param("vendorId") String vendorId,
                                         @Param("vendorSetNbr") Integer vendorSetNbr, @Param("dcSidNbr") Integer dcSidNbr);

    @Query(value = "UPDATE Items " + "SET psellItemCmtTxt = :comment , " + "modUserId = :userId ,"
            + "modTs = :currentDate " + "WHERE itemsPk.psellIdNbr = :presellNumber " + "AND itemsPk.itemNbr = :itemNbr "
            + "AND itemsPk.shipDt = :dtShipDt ")
    void updateItemComment(@Param("comment") String comment, @Param("userId") String userId,
                           @Param("currentDate") Date currentDate, @Param("presellNumber") Integer presellNumber,
                           @Param("itemNbr") BigDecimal itemNbr, @Param("dtShipDt") Date dtShipDt);

    @Query("select min(itemsPk.itemNbr) from Items where itemsPk.psellIdNbr = ?1")
    BigDecimal getMinItemIdNbr(Integer psellIdNbr);

    @Query(value = " SELECT TPSL002.itemsPk.itemNbr as itemNbr,"
            + " TPSL002.itemsPk.shipDt as shipDt,"
            + " TPSL002.itemCst as itemCst ,"
            + " TPSL002.itemSzCnt as itemSzCnt,"
            + " TPSL002.itemSzCd as itemSzCd ,"
            + " TPSL002.itemPkQty as itemPkQty,"
            + " TPSL002.itemCapCst as itemCapCst,"
            + " TPSL002.rtlPrc as rtlPrc,"
            + " TPSL002.psellGrmrgAmt as psellGrmrgAmt,"
            + " TPSL002.itemDsc as itemDsc,"
            + " TPSL002.psellItemCmtTxt as psellItemCmtTxt,"
            + " TPSL002.itemImgUrl as itemImgUrl,"
            + " TPSL002.itemCntrbPct as itemCntrbPct,"
            + " TPSL008.itmsoqmapPk.psellClsIdNbr as psellClsIdNbr,"
            + " TPSL008.suggOrderQty as suggOrderQty,"
            + " TPSL005.psellLvlClsCd as psellLvlClsCd"
            + " FROM Items TPSL002,"
            + " Itmsoqmap TPSL008,"
            + " LvlClass TPSL005"
            + " WHERE TPSL002.itemsPk.itemNbr=TPSL008.itmsoqmapPk.itemNbr"
            + " AND TPSL002.itemsPk.shipDt=TPSL008.itmsoqmapPk.shipDt"
            + " AND TPSL002.itemsPk.psellIdNbr=TPSL008.itmsoqmapPk.psellIdNbr"
            + " AND TPSL008.itmsoqmapPk.psellClsIdNbr=TPSL005.psellClsIdNbr"
            + " AND TPSL002.itemsPk.psellIdNbr =:psellIdNbr AND TPSL005.lgclDelFlg='N'"
            + " ORDER BY"
            + " TPSL002.itemsPk.itemNbr,"
            + " TPSL002.itemsPk.shipDt,"
            + " TPSL005.psellLvlClsCd"

    )
    List<ItemProjection> getItemList(@Param("psellIdNbr") Integer psellIdNbr);

    @Query(value = " SELECT  "
            + "TPSL002.itemsPk.itemNbr as itemNbr,"
            + "TPSL002.itemsPk.shipDt as shipDt,"
            + "TPSL002.itemCst as itemCst,"
            + "TPSL002.itemSzCnt as itemSzCnt,"
            + "TPSL002.itemSzCd as itemSzCd,"
            + "TPSL002.itemPkQty as itemPkQty,"
            + "TPSL002.itemCapCst as itemCapCst,"
            + "TPSL002.rtlPrc as rtlPrc,"
            + "TPSL002.psellGrmrgAmt as psellGrmrgAmt,"
            + "TPSL002.itemDsc as itemDsc,"
            + "TPSL002.psellItemCmtTxt as psellItemCmtTxt,"
            + "TPSL002.itemImgUrl as itemImgUrl,"
            + "TPSL002.itemCntrbPct as itemCntrbPct,"
            + "TPSL008.itmsoqmapPk.psellClsIdNbr as psellClsIdNbr,"
            + "TPSL008.suggOrderQty as suggOrderQty,"
            + "TPSL004.itemOrderQty as itemOrderQty,"
            + "TPSL005.psellClsIdNbr as psellClsIdNbr,"
            + "TPSL005.psellLvlClsCd as psellLvlClsCd "
            + "FROM "
            + "Items TPSL002,"
            + "Itmsoqmap TPSL008,"
            + "LvlClass TPSL005,"
            + "StorItems TPSL004 "
            + "WHERE "
            + "TPSL002.itemsPk.itemNbr=TPSL008.itmsoqmapPk.itemNbr "
            + "AND TPSL002.itemsPk.itemNbr=TPSL004.storItemsPk.itemNbr "
            + "AND TPSL008.itmsoqmapPk.itemNbr=TPSL004.storItemsPk.itemNbr "
            + "AND TPSL002.itemsPk.shipDt=TPSL008.itmsoqmapPk.shipDt "
            + "AND TPSL002.itemsPk.shipDt=TPSL004.storItemsPk.shipDt "
            + "AND TPSL008.itmsoqmapPk.shipDt=TPSL004.storItemsPk.shipDt "
            + "AND TPSL002.itemsPk.psellIdNbr=TPSL008.itmsoqmapPk.psellIdNbr "
            + "AND TPSL002.itemsPk.psellIdNbr=TPSL004.storItemsPk.psellIdNbr "
            + "AND TPSL008.itmsoqmapPk.psellIdNbr=TPSL004.storItemsPk.psellIdNbr "
            + "AND TPSL008.itmsoqmapPk.psellClsIdNbr=TPSL005.psellClsIdNbr "
            + "AND TPSL002.itemsPk.psellIdNbr = :psellIdNbr "
            + "AND TPSL004.storItemsPk.storeNbr = :storeNm "
            + "ORDER BY TPSL002.itemsPk.itemNbr,TPSL002.itemsPk.shipDt ")
    List<ItemProjection> getListStoreItems(@Param("psellIdNbr") Integer psellIdNbr, @Param("storeNm") Integer storeNm);


}

