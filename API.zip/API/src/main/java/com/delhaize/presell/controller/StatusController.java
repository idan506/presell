package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.dto.StatusDTO;
import com.delhaize.presell.service.StatusService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
@Log4j2
@CrossOrigin
@RestController
@RequestMapping({"api/v1/status"})
@Tag(name = "status", description = "the status API")
public class StatusController {

    private final StatusService statusService;

    @Autowired
    public StatusController(StatusService statusService) {
        this.statusService = statusService;
    }

    @Operation(summary = "Get Status For PResell", tags = { "status" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = LinkedHashMap.class))),
            @ApiResponse(responseCode = "404", description = "Status not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/presell", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<StatusDTO>> getStatusForPresell() {
        log.info("getStatusForPresell");
        return ResponseEntity.ok(statusService.getStatusForPresell());
    }

    @Operation(summary = "Get Status For Store Order", tags = { "status" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = LinkedHashMap.class))),
            @ApiResponse(responseCode = "404", description = "Status not found", content = @Content)
    })
    @Secured
    @GetMapping(value = "/store-order", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<StatusDTO>> getStatusForStoreOrder(@RequestAttribute("user") UserSSOInfo user) {
        log.info("getStatusForStoreOrder");
        return ResponseEntity.ok(statusService.getStatusForStoreOrder(user.getRole()));
    }

    @Operation(summary = "Get Status For Presell Report", tags = { "status" })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = LinkedHashMap.class))),
            @ApiResponse(responseCode = "404", description = "Status not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/presell-report", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<StatusDTO>> getStatusForPresellReport() {
        log.info("getStatusForPresellReport");
        return ResponseEntity.ok(statusService.getStatusForPresellReport());
    }
}
