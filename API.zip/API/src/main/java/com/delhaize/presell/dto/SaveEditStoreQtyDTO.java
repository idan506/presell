package com.delhaize.presell.dto;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SaveEditStoreQtyDTO {
	@NotNull
    private PresellStoreDetailDTO presellDetail;
	@NotNull
    private String action;
    @NotNull
    private String userId;
    @NotNull
    private String userRole;
}
