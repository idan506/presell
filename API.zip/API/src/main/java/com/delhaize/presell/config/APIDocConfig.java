package com.delhaize.presell.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class APIDocConfig {

    private static final String LICENCE_TEXT = "License";
    private static final String TITLE = "Presell API";

    @Bean
    public OpenAPI customOpenAPI(@Value("${app.version}") String appVersion,
                                 @Value("${app.description}") String appDescription,
                                 @Value("${app.name}") String appName) {
        final String SECURITY_SCHEME_NAME = "bearerAuth";
        return new OpenAPI()
                .servers(List.of(new Server().url("/"),
                        new Server().url("/" + appName)))
                .components(new Components().addSecuritySchemes(SECURITY_SCHEME_NAME,
                        new SecurityScheme()
                                .type(SecurityScheme.Type.HTTP)
                                .name(SECURITY_SCHEME_NAME)
                                .scheme("bearer")
                                .bearerFormat("JWT")
                ))
                .info(new Info().title(TITLE).version(appVersion).description(
                                appDescription)
                        .license(new License().name(LICENCE_TEXT)))
                .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME_NAME));
    }
}
