package com.delhaize.presell.controller;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.authorization.UserSSOInfo;
import com.delhaize.presell.constant.SavePresellAction;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.PresellDTO;
import com.delhaize.presell.dto.PresellStoreDetailDTO;
import com.delhaize.presell.dto.request.PaginationAndSortDTO;
import com.delhaize.presell.dto.request.PresellSaveRequestDTO;
import com.delhaize.presell.dto.request.PresellSearchCriteria;
import com.delhaize.presell.exception.ExceptionHandlingHelper;
import com.delhaize.presell.exception.ResponseError;
import com.delhaize.presell.service.PresellService;
import com.delhaize.web.exception.GenericApiException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin
@Log4j2
@RestController
@RequestMapping({"api/v1/presell"})
@Tag(name = "presell", description = "the presell API")
public class PresellController {

    private PresellService presellService;

    @Autowired
    public PresellController(PresellService presellService) {
        this.presellService = presellService;
    }

    @Value("${app.version}")
    private String appVersion;

    @Operation(summary = "Returns current app version")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(type = "String")))
    })
    @GetMapping("/appVersion")
    public ResponseEntity<String> appVersion() {
        return ResponseEntity.ok(appVersion);
    }

    @Operation(summary = "Search Presell")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = PresellDTO.class))),
            @ApiResponse(responseCode = "404", description = "Presell not found", content = @Content)
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/search", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Page<PresellDTO>> searchPresell(PresellSearchCriteria criteria, PaginationAndSortDTO paginationAndSortDTO) {
        log.info("searchPresell");
        var rs = presellService.searchPresell(criteria, paginationAndSortDTO);
        return ResponseEntity.ok(rs);
    }

    @Operation(summary = "Download Presell List To XLS")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))
    })
    @Secured
    @GetMapping(value = "/download", produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    public ResponseEntity<Resource> downloadPresellToXLS(PresellSearchCriteria criteria) {
        log.info("downloadPresellToXLS");
        String fileName = String.format("Presell_List_%o.xls", System.currentTimeMillis());
        InputStreamResource file = new InputStreamResource(presellService.downloadPresellToXLS(criteria, fileName));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }

    @Operation(summary = "Delete Presell List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN})
    @DeleteMapping
    public ResponseEntity<String> deletePreselList(@RequestBody List<Integer> request) {
        log.info("deletePreselList");
        try {
            log.info("requestSize:" + request.size());
            var rs = presellService.deletePresellList(request);
            return ResponseEntity.ok(rs);
        } catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.DELETE_PRESELL_ERROR, e);
        }

    }

    @Operation(summary = "Save Presell")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @PostMapping
    public Integer savePresell(@RequestBody @Valid PresellSaveRequestDTO request,
                               @RequestAttribute("user") UserSSOInfo user) {
        log.info("savePresell");
        log.info("request by {}", user.getUserId());
        request.setUserId(user.getUserId());
        if (!user.getRole().equals(Secured.UserRole.ADMIN)) {
            request.getPresellDetail().setStoreDTOList(new ArrayList<>());
        }
        int presellId = 0;
        if (request.getAction().equals(SavePresellAction.SEND_TO_STORES) &&
                request.getPresellDetail().getPsellStatCd().equals(Status.SEND_TO_STORES)) {
            log.info("Send To Additional Store");
            try {
                presellService.sendToAdditionalStores(request);
            } catch (Exception e) {
                log.error(e);
                throw ExceptionHandlingHelper.newGenericException(ResponseError.SEND_TO_ADDTIONAL_STORE_ERROR, e);
            }
        } else {
            try {
                presellId = presellService.savePresell(request);
            } catch (Exception e) {
                log.error(e);
                throw new GenericApiException(HttpStatus.INTERNAL_SERVER_ERROR, String.format("Fail To Perform %s Action", request.getAction()), e);
            }
        }
        return presellId;
    }

    @Operation(summary = "Get Presell Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/{psellIdNbr}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<PresellStoreDetailDTO> getPresellDetails(@PathVariable Integer psellIdNbr) {
        log.info("getPresellDetails:{}",psellIdNbr);
        try {
            log.info("psellIdNbr:" + psellIdNbr);
            var rs  =presellService.getPresellDetails(psellIdNbr);
            return ResponseEntity.ok(rs);
        }  catch (Exception e) {
            log.error(e);
            throw ExceptionHandlingHelper.newGenericException(ResponseError.GET_PRESELL_DETAILS_ERROR, e);
        }
    }
    @Operation(summary = "Download To XLS Presell Details & Item List")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = Resource.class)))
    })
    @Secured(permitRoles = {Secured.UserRole.ADMIN, Secured.UserRole.MERCHUSER})
    @GetMapping(value = "/{psellIdNbr}/download", produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    public ResponseEntity<Resource> downloadItemList(@PathVariable Integer psellIdNbr) {
        log.info("downloadItemList:{}",psellIdNbr);
        String fileName = String.format("Presell_Item_%o.xls", System.currentTimeMillis());
        InputStreamResource file = new InputStreamResource(presellService.downloadItemList(psellIdNbr, fileName));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }
}
