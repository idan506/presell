package com.delhaize.presell.service;

import java.io.ByteArrayInputStream;
import java.util.List;

import com.delhaize.presell.dto.StorePresellLevelDTO;
import com.delhaize.presell.dto.StorePresellLevelMappingDTO;
import com.delhaize.presell.dto.request.StorePresellLevelMappingCriteria;

public interface PresellLevelMappingService {
	List<StorePresellLevelMappingDTO> searchStorePresellLevelMapping(StorePresellLevelMappingCriteria criteria);

	int saveStorePresellLevelMaping(StorePresellLevelDTO criteria);
	
	ByteArrayInputStream downloadStorePresellLevelMapping(String fileName);

}
