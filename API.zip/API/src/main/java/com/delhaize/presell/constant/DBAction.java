package com.delhaize.presell.constant;

public enum DBAction {
    INSERT,
    UPDATE,
    DELETE,
    INACTION
}
