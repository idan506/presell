package com.delhaize.presell.dto.request;

import com.delhaize.presell.constant.Status;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Getter
@Setter
public class PresellSearchCriteria {

    private String presellTitle;

    private Integer presellLevelId;

    private Status status;

    private String presellAuthor;

    private String businessUnit;

    @Schema(example = "01/20/2015")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date fromDueDate;

    @Schema(example = "01/20/2021")
    @DateTimeFormat(pattern = "MM/dd/yyyy")
    private Date toDueDate;

    private String plannedDis;
}
