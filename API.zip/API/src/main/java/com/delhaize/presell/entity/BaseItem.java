package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TITM100_BASE_ITEM")
public class BaseItem {

  @EmbeddedId
  private BaseItemPK baseItemPk;

  @Column(name="RPLC_ITEM_NBR")
  private java.math.BigDecimal rplcItemNbr;

  @Column(name="DIST_TYP_CD")
  private String distTypCd;

  @Column(name="PLU_NBR")
  private java.math.BigDecimal pluNbr;

  @Column(name="ITEM_EFF_DT")
  private java.sql.Date itemEffDt;

  @Column(name="RCV_XPIR_DT")
  private java.sql.Date rcvXpirDt;

  @Column(name="ITEM_XPIR_DT")
  private java.sql.Date itemXpirDt;

  @Column(name="ITEM_CRT_DT")
  private java.sql.Date itemCrtDt;

  @Column(name="ITEM_LAST_ACT_DT")
  private java.sql.Date itemLastActDt;

  @Column(name="ITEM_PK_QTY")
  private Integer itemPkQty;

  @Column(name="ITEM_SZ_CNT")
  private java.math.BigDecimal itemSzCnt;

  @Column(name="ITEM_SZ_CD")
  private String itemSzCd;

  @Column(name="ITEM_DSC")
  private String itemDsc;

  @Column(name="ITEM_CHK_DGT_NBR")
  private java.math.BigDecimal itemChkDgtNbr;

  @Column(name="ALT_UPC_NBR")
  private java.math.BigDecimal altUpcNbr;

  @Column(name="ITEM_SCAN_CD")
  private String itemScanCd;

  @Column(name="PHAR_DEA_SCHD_CD")
  private String pharDeaSchdCd;

  @Column(name="SUPLY_TRNSL_CD")
  private String suplyTrnslCd;

  @Column(name="PVT_LBL_CD")
  private String pvtLblCd;

  @Column(name="ITEM_HNDL_CD")
  private String itemHndlCd;

  @Column(name="ITEM_STAT_CD")
  private String itemStatCd;

  @Column(name="PRDT_RCOV_TYP_CD")
  private String prdtRcovTypCd;

  @Column(name="PRC_BK_CD")
  private String prcBkCd;

  @Column(name="UOM_CD")
  private String uomCd;

  @Column(name="ITEM_RTL_TYP_CD")
  private String itemRtlTypCd;

  @Column(name="TAX_CATG_MJR_ID")
  private String taxCatgMjrId;

  @Column(name="TAX_CATG_MNR_ID")
  private String taxCatgMnrId;

  @Column(name="NDC_CD")
  private String ndcCd;

  @Column(name="RTL_UNIT_PK_QTY")
  private java.math.BigDecimal rtlUnitPkQty;

  @Column(name="ITEM_PHYS_FORM_CD")
  private String itemPhysFormCd;

  @Column(name="MFR_DCNTU_DT")
  private java.sql.Date mfrDcntuDt;

  @Column(name="GPI_ID")
  private String gpiId;

  @Column(name="BRND_OWNER_NBR")
  private Integer brndOwnerNbr;

  @Column(name="BRND_NBR")
  private Integer brndNbr;

  @Column(name="ITEM_COLOR_DSC")
  private String itemColorDsc;

  @Column(name="SPCL_HNDL_INSTR_CD")
  private String spclHndlInstrCd;

  @Column(name="FRT_DENS_CLS_CD")
  private java.math.BigDecimal frtDensClsCd;

  @Column(name="PEND_DCNTU_STAT_CD")
  private String pendDcntuStatCd;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="PRC_MSTR_TYP_ID")
  private String prcMstrTypId;

  @Column(name="PRC_MSTR_ID")
  private String prcMstrId;

  @Column(name="PRC_UNIT_OBSLT_DT")
  private java.sql.Date prcUnitObsltDt;

  @Column(name="PVT_BRND_CD")
  private String pvtBrndCd;

  @Column(name="SIGN_DSC")
  private String signDsc;

  @Column(name="OVRLN_DSC")
  private String ovrlnDsc;

  @Column(name="AVG_UNIT_WGT")
  private java.math.BigDecimal avgUnitWgt;

  @Column(name="MSA_PROMO_CD")
  private String msaPromoCd;

  @Column(name="MSA_CATG_CD")
  private String msaCatgCd;

  @Column(name="MSA_CTN_STICK_CNT")
  private Integer msaCtnStickCnt;

  @Column(name="FDLN_SIGN_DSC")
  private String fdlnSignDsc;

  @Column(name="FDLN_OVRLN_DSC")
  private String fdlnOvrlnDsc;

  @Column(name="ONLINE_CDS")
  private String onlineCds;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    BaseItem baseItem = (BaseItem) o;
    return baseItemPk != null && Objects.equals(baseItemPk, baseItem.baseItemPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(baseItemPk);
  }
}
