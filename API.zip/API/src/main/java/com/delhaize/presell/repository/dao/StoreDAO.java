package com.delhaize.presell.repository.dao;

import com.delhaize.presell.dto.StoresDTO;
import com.delhaize.presell.dto.request.StoreSearchCriteria;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface StoreDAO {
    List<StoresDTO> searchStore(StoreSearchCriteria criteria);

}
