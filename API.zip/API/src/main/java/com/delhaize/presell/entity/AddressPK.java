package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class AddressPK implements Serializable {


  @Column(name="LOC_SID_NBR")
  private Integer locSidNbr;

  @Column(name="CNTCT_TYP_CD")
  private String cntctTypCd;

  @Column(name="ADR_TYP_CD")
  private String adrTypCd;
}
