package com.delhaize.presell.service;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.dto.StatusDTO;

import java.util.List;

public interface StatusService {
    List<StatusDTO> getStatusForPresell();

    List<StatusDTO> getStatusForStoreOrder(Secured.UserRole role);

    List<StatusDTO> getStatusForPresellReport();
}
