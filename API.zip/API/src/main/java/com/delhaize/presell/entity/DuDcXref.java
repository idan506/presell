package com.delhaize.presell.entity;

import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="TITM202_DU_DC_XREF")
public class DuDcXref {

  @EmbeddedId
  private DuDcXrefPK duDcXrefPk;

  @Column(name="DCITM_STAT_CD")
  private String dcitmStatCd;

  @Column(name="DCITM_DCNTU_DT")
  private java.sql.Date dcitmDcntuDt;

  @Column(name="SLCT_SLOT_ID")
  private String slctSlotId;

  @Column(name="DC_PLLT_TI_CNT")
  private Integer dcPlltTiCnt;

  @Column(name="DC_PLLT_HI_CNT")
  private Integer dcPlltHiCnt;

  @Column(name="AUTO_ORDER_CD")
  private String autoOrderCd;

  @Column(name="XDOCK_CD")
  private String xdockCd;

  @Column(name="DCITM_SLCT_MTHD_CD")
  private String dcitmSlctMthdCd;

  @Column(name="WHSE_ORDER_TYP_CD")
  private String whseOrderTypCd;

  @Column(name="CYCL_CNT_CD")
  private String cyclCntCd;

  @Column(name="MAX_STORE_ORD_QTY")
  private Integer maxStoreOrdQty;

  @Column(name="ORDER_TYP_ID")
  private String orderTypId;

  @Column(name="MSTR_RPT_VEND_ID")
  private String mstrRptVendId;

  @Column(name="INF_VEND_ID")
  private String infVendId;

  @Column(name="INF_PROF_TAG_ID")
  private String infProfTagId;

  @Column(name="INF_ORDER_MLT")
  private Integer infOrderMlt;

  @Column(name="CMPR_ITEM_NBR")
  private java.math.BigDecimal cmprItemNbr;

  @Column(name="AVG_WK_SLS_AMT")
  private java.math.BigDecimal avgWkSlsAmt;

  @Column(name="DC_SVC_LVL_CD")
  private String dcSvcLvlCd;

  @Column(name="INF_ORD_STRAT_DUR")
  private java.math.BigDecimal infOrdStratDur;

  @Column(name="INF_LDTM_DAYS_DUR")
  private Integer infLdtmDaysDur;

  @Column(name="SNL_EMER_CTRL_CD")
  private String snlEmerCtrlCd;

  @Column(name="INF_MIN_ORDER_QTY")
  private Integer infMinOrderQty;

  @Column(name="MAX_PFCST_ORD_QTY")
  private Integer maxPfcstOrdQty;

  @Column(name="SFTY_STK_QTY")
  private java.math.BigDecimal sftyStkQty;

  @Column(name="SFTY_STK_TYP_CD")
  private String sftyStkTypCd;

  @Column(name="FBUY_WK_CNT")
  private Integer fbuyWkCnt;

  @Column(name="SEL_WHSE_ID")
  private Integer selWhseId;

  @Column(name="SUBS_ITEM_NBR")
  private java.math.BigDecimal subsItemNbr;

  @Column(name="RPLC_ITEM_NBR")
  private java.math.BigDecimal rplcItemNbr;

  @Column(name="BILL_DEPT_ID")
  private String billDeptId;

  @Column(name="DCITM_FRCE_OUT_QTY")
  private Integer dcitmFrceOutQty;

  @Column(name="MIN_WHSE_SHLF_DUR")
  private Integer minWhseShlfDur;

  @Column(name="INV_GRP_CD")
  private String invGrpCd;

  @Column(name="DCITM_EFF_DT")
  private java.sql.Date dcitmEffDt;

  @Column(name="DCITM_CRT_DT")
  private java.sql.Date dcitmCrtDt;

  @Column(name="CATCH_WGT_CD")
  private String catchWgtCd;

  @Column(name="ASSC_RO_SID_NBR")
  private Integer asscRoSidNbr;

  @Column(name="PEND_DCNTU_STAT_CD")
  private String pendDcntuStatCd;

  @Column(name="PEND_DCNTU_STAT_DT")
  private java.sql.Date pendDcntuStatDt;

  @Column(name="RND_BY_QTY")
  private Integer rndByQty;

  @Column(name="RND_BY_PCT")
  private Integer rndByPct;

  @Column(name="RND_TO_QTY")
  private Integer rndToQty;

  @Column(name="RND_TO_PLLT_QTY")
  private Integer rndToPlltQty;

  @Column(name="RND_FLG")
  private String rndFlg;

  @Column(name="SVC_LVL_TGT_TYP_CD")
  private String svcLvlTgtTypCd;

  @Column(name="INIT_NSNL_DMND_QTY")
  private java.math.BigDecimal initNsnlDmndQty;

  @Column(name="MOD_USER_ID")
  private String modUserId;

  @Column(name="MOD_PGM_ID")
  private String modPgmId;

  @Column(name="MOD_TS")
  private java.sql.Timestamp modTs;

  @Column(name="MC_DC_SID_NBR")
  private Integer mcDcSidNbr;

  @Column(name="MC_VEND_ID")
  private String mcVendId;

  @Column(name="MC_INF_ORDER_MLT")
  private Integer mcInfOrderMlt;

  @Column(name="RDC_MIN_ORDER_QTY")
  private Integer rdcMinOrderQty;

  @Column(name="RDC_SFTY_STK_QTY")
  private java.math.BigDecimal rdcSftyStkQty;

  @Column(name="RDC_SFTYSTK_TYP_CD")
  private String rdcSftystkTypCd;

  @Column(name="ORD_MIN_ORDER_QTY")
  private Integer ordMinOrderQty;

  @Column(name="PROD_TYP_CD")
  private String prodTypCd;

  @Column(name="WH_ORD_TYP_CD")
  private String whOrdTypCd;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    DuDcXref duDcXref = (DuDcXref) o;
    return duDcXrefPk != null && Objects.equals(duDcXrefPk, duDcXref.duDcXrefPk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(duDcXrefPk);
  }
}
