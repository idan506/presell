package com.delhaize.presell.repository;

import com.delhaize.presell.dto.projection.PresellLogProjection;
import com.delhaize.presell.entity.PreselLog;
import com.delhaize.presell.entity.PreselLogPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface PreselLogRepository extends JpaRepository<PreselLog, PreselLogPK> {

    @Modifying
    @Transactional
    @Query("delete from PreselLog where preselLogPk.psellIdNbr in :psellId")
    void deletPreSellID(@Param("psellId") List<Integer> psellId);

    @Query("SELECT "
            + " preselLogPk.audLogTs as audLogTs, "
            + " preselLogPk.addUserId as addUserId, "
            + " logStatCd as logStatCd, "
            + " logCmtTxt as logCmtTxt "
            + " FROM "
            + " PreselLog "
            + " WHERE "
            + " preselLogPk.psellIdNbr = :presellID "
            + " AND preselLogPk.storeNbr = :storeNum "
            + " AND logStatCd !='LOC' ")
    List<PresellLogProjection> getLogData(@Param("presellID") int presellID, @Param("storeNum") int storeNum);

    @Query("SELECT "
            + " preselLogPk.audLogTs as audLogTs, "
            + " preselLogPk.addUserId as addUserId, "
            + " logStatCd as logStatCd, "
            + " logCmtTxt as logCmtTxt "
            + " FROM "
            + " PreselLog "
            + " WHERE "
            + " preselLogPk.psellIdNbr = :presellID "
            + " AND preselLogPk.storeNbr in(:storeNum)"
            + " AND logStatCd !='LOC' ")
    List<PresellLogProjection> getLogDetails(@Param("presellID") int presellID, @Param("storeNum") List<Integer> storeNum);
}



