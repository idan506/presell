package com.delhaize.presell.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;

@Getter
@Setter
@Embeddable
public class ItemClsPK implements Serializable {


  @Column(name="PRDT_CLS_TYP_NBR")
  private Integer prdtClsTypNbr;

  @Column(name="ITEM_SET_NBR")
  private Integer itemSetNbr;

  @Column(name="ITEM_NBR")
  private java.math.BigDecimal itemNbr;
}
