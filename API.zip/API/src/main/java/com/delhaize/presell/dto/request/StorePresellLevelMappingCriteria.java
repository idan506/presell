package com.delhaize.presell.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StorePresellLevelMappingCriteria {
	
	private String storeNo;

	private String storeType;
}
