package com.delhaize.presell.service.impl;

import com.delhaize.presell.authorization.Secured;
import com.delhaize.presell.constant.Status;
import com.delhaize.presell.dto.StatusDTO;
import com.delhaize.presell.service.StatusService;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@Service
public class StatusServiceImpl implements StatusService {

	@Override
	public List<StatusDTO> getStatusForPresell() {
		log.info("----Get Status For Presell Screen-----");
		return mapStatusEnumToDTO(Status.getForPresell());
	}

	@Override
	public List<StatusDTO> getStatusForStoreOrder(Secured.UserRole role) {
		log.info("----Get Status For Store Order Screen-----");
		List<Status> status;
		if (role.equals(Secured.UserRole.ADMIN) || role.equals(Secured.UserRole.MERCHUSER)) {
			status = Status.getForStoreOrder();
		} else {
			status = Status.getForStoreOrderByRetail();
		}
		return mapStatusEnumToDTO(status);
	}

	@Override
	public List<StatusDTO> getStatusForPresellReport() {
		log.info("----Get Status For Presell Report Screen-----");
		return mapStatusEnumToDTO(Status.getForPresellReport());
	}

	private List<StatusDTO> mapStatusEnumToDTO(List<Status> status) {
		log.info("-----Map status enum to DTO-----");
		return status.stream().map(e -> {
			var state = new StatusDTO();
			state.setId(e.name());
			state.setDescription(e.getStatusDsc());
			return state;
		}).collect(Collectors.toList());
	}
}
