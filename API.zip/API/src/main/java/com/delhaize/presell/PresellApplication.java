package com.delhaize.presell;

import com.delhaize.web.config.ExceptionHandlingConfig;
import com.delhaize.web.exception.handler.RestExceptionHandler;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import javax.annotation.PostConstruct;
import java.util.TimeZone;

@SpringBootApplication
@Import({ExceptionHandlingConfig.class, RestExceptionHandler.class})
public class PresellApplication {

    public static void main(String[] args) {
        SpringApplication.run(PresellApplication.class, args);
    }

    @PostConstruct
    void started() {
        TimeZone.setDefault(TimeZone.getTimeZone("Etc/UTC"));
    }

}
