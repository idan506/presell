package com.delhaize.presell.dto;

import com.delhaize.presell.annotation.QueryProjection;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@QueryProjection
public class DcDTO implements Serializable {
    private String dcId;
    private String dcSidNbr;
}
