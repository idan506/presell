package com.delhaize.presell.constant;

public enum SavePresellAction {
    SAVE_AS_DRAFT,
    SEND_TO_STORES,
    CREATE_AUTO_ORDER,
    CLOSED,
}
